UGC Video Creator — Chrome Extension

Load unpacked:
1. Extract this ZIP.
2. Open chrome://extensions.
3. Enable Developer mode.
4. Click Load unpacked.
5. Select this folder — the folder containing manifest.json.
6. Open the extension and click Open studio.

The extension works locally with its built-in storyboard planner and Canvas/WebM renderer.
For optional server-side LLM planning, ElevenLabs voice generation, and MP4 transcoding,
run the project gateway from the original project repository with `npm run dev` and configure
server-side provider keys in `.env`. Provider secrets must never be placed in this folder.
