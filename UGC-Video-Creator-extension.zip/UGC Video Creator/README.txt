UGC Video Creator — Chrome Extension + optional local gateway

LOAD THE EXTENSION
1. Extract this ZIP.
2. Open chrome://extensions.
3. Enable Developer mode.
4. Click Load unpacked.
5. Select this folder — the folder containing manifest.json.
6. Open the extension and click Open studio.

The extension works immediately with:
- 9:16 Instagram Reel workflow and six-beat retention template
- User-uploaded female/model creator image support
- Automatic built-in UGC-style female creator fallback when no model image is supplied
- Product image upload and scene assignment
- Product-only script generation from the product brief/images
- Natural browser voice preview, editable captions, music, transitions and Canvas video rendering
- WebM export; MP4 is enabled when FFmpeg is available in the gateway

OPTIONAL AI / AUDIO / MP4 GATEWAY
The same folder includes a secure Node gateway. From this extracted folder run:
  npm run dev
Then configure server-side keys in .env if you want an OpenAI-compatible LLM/image provider,
ElevenLabs narration, and FFmpeg MP4 transcoding. Do not put provider secrets in extension storage.
The extension communicates with the gateway at http://localhost:8787/api.
