import{g as y,S as ue,a as pe,t as me,e as u,c as he,m as x,b as T,d as w,s as z,f as ae,h as C,i as h,j as F,P as ve,n as W,k as be,l as fe,o as ye,p as K,q as U,u as Y,r as Q,v as G,w as se,x as j,F as ge,y as S,z as we,A as $e,B as Se,I as q,C as ke,D as Ee}from"./label-view-DkV-Hn28.js";const ne=typeof chrome<"u"&&!!chrome.identity?.launchWebAuthFlow;let L=null;const qe=()=>ne&&!!y().clientId;function de(){return qe()?M(!1).then(()=>!0).catch(()=>!1):Promise.resolve(!1)}async function Le(){if(!ne)throw new Error("Chrome identity API is not available.");await M(!0)}async function Ne(){L&&fetch("https://oauth2.googleapis.com/revoke?token="+encodeURIComponent(L.token)).catch(()=>{}),L=null}function V(t,a){return"https://accounts.google.com/o/oauth2/v2/auth?"+new URLSearchParams({client_id:t,response_type:"token",redirect_uri:chrome.identity.getRedirectURL(),scope:ue,prompt:a}).toString()}function Z(t,a){return new Promise((e,r)=>{chrome.identity.launchWebAuthFlow({url:t,interactive:!0},d=>{const n=chrome.runtime.lastError,s=o=>r(new Error(a?"silent-fail":o));if(n||!d)return s("Google sign-in failed or was cancelled.");try{const o=new URLSearchParams(new URL(d).hash.replace(/^#/,"")),i=o.get("access_token"),l=Number(o.get("expires_in")||"3600");if(!i)return s("Google sign-in failed.");L={token:i,exp:Date.now()+Math.max(60,l-120)*1e3},e(i)}catch{s("Google sign-in failed.")}})})}async function M(t){if(L&&L.exp>Date.now())return L.token;const a=y().clientId;if(!a)throw new Error("Google Sheets is not set up yet. Add your OAuth Client ID in Settings.");try{return await Z(V(a,"none"),!0)}catch{if(!t)throw new Error("Not signed in to Google.");return Z(V(a,"select_account"),!1)}}async function R(t,a){let e="";try{e=(await t.json())?.error?.message||""}catch{}return t.status===401||t.status===403?new Error(`Google access was rejected while ${a}. Try reconnecting your account in Settings.`):t.status===404?new Error(`Spreadsheet or worksheet not found while ${a}. Check the connection in Settings.`):t.status>=500?new Error(`Google Sheets is temporarily unavailable while ${a}. Please try again.`):new Error(e||`Google Sheets request failed while ${a} (error ${t.status}).`)}async function D(t,a,e=!0){let r;try{r=await M(e)}catch(n){throw new Error(n instanceof Error&&n.message!=="silent-fail"?n.message:"Not signed in to Google. Connect your account in Settings.")}let d=await fetch(t,{...a,headers:{...a?.headers||{},Authorization:"Bearer "+r}});return d.status===401&&(L=null,r=await M(e),d=await fetch(t,{...a,headers:{...a?.headers||{},Authorization:"Bearer "+r}})),d}async function xe(t){let a;try{a=await D(`https://sheets.googleapis.com/v4/spreadsheets/${t}?fields=sheets.properties.title`)}catch{throw new Error("Network problem while opening the spreadsheet. Check your internet connection.")}if(!a.ok)throw await R(a,"opening the spreadsheet");return{sheets:((await a.json()).sheets||[]).map(r=>r.properties.title)}}async function re(t,a){const e=await D(`https://sheets.googleapis.com/v4/spreadsheets/${t}/values/${encodeURIComponent(a)}!1:1`);if(!e.ok)throw await R(e,"reading headers");return((await e.json()).values?.[0]||[]).map(d=>String(d).trim())}async function Ce(t,a,e,r){const d=e.map(s=>s.trim().toLowerCase()),n=r.filter(s=>!d.includes(s.trim().toLowerCase()));if(n.length>0){const s=`${a}!${H(e.length)}1:${H(e.length+n.length-1)}1`,o=await D(`https://sheets.googleapis.com/v4/spreadsheets/${t}/values/${encodeURIComponent(s)}?valueInputOption=RAW`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({values:[n]})});if(!o.ok)throw await R(o,"creating columns")}return[...e,...n]}async function ie(t,a,e,r){const d=await D(`https://sheets.googleapis.com/v4/spreadsheets/${t}/values/${encodeURIComponent(a)}!${e}:${e}`);if(!d.ok)throw await R(d,"looking up the order number");const s=(await d.json()).values||[],o=r.trim().toLowerCase();for(let i=0;i<s.length;i++)if(String(s[i][0]||"").trim().toLowerCase()===o)return{row:i+1,last:s.length};return{row:0,last:s.length}}async function Ae(t,a,e,r){if(e>0){const o=`${a}!A${e}:${H(r.length-1)}${e}`,i=await D(`https://sheets.googleapis.com/v4/spreadsheets/${t}/values/${encodeURIComponent(o)}?valueInputOption=USER_ENTERED`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({values:[r]})});if(!i.ok)throw await R(i,"updating the order row");return e}const d=await D(`https://sheets.googleapis.com/v4/spreadsheets/${t}/values/${encodeURIComponent(a+"!A:A")}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({values:[r]})});if(!d.ok)throw await R(d,"adding the order row");const n=await d.json(),s=/![A-Z]+(\d+)/.exec(String(n.updates?.updatedRange||""));return s?Number(s[1]):0}function H(t){let a="",e=t+1;for(;e>0;){const r=(e-1)%26;a=String.fromCharCode(65+r)+a,e=Math.floor((e-1)/26)}return a}function Ie(t){const a=pe(),e=me(),r=s=>a.filter(s).length,d=[["Today's Orders",r(s=>s.createdAt.slice(0,10)===e)],["Pending Labels",r(s=>!s.labelPrinted)],["Paid Orders",r(s=>s.paymentStatus==="Paid")],["COD Orders",r(s=>s.paymentStatus==="COD")]],n=a.slice(0,5);return{html:`<div class="page-head">
        <div><h2 class="page-title">Dashboard</h2><div class="page-sub">Overview of your orders</div></div>
        <div class="head-actions">
          <button class="btn primary" data-act="new">+ New Order</button>
          <button class="btn" data-act="orders">Orders</button>
          <button class="btn" data-act="settings">Settings</button>
        </div>
      </div>
      <div class="stats">${d.map(([s,o])=>`<div class="stat"><div class="v">${o}</div><div class="l">${s}</div></div>`).join("")}</div>
      <div class="card">
        <div class="card-title">Recent Orders</div>
        ${n.length===0?'<div class="empty">No orders yet.<br><button class="btn primary" data-act="new">+ New Order</button></div>':`<div class="tblwrap" style="border:0"><table class="tbl"><thead><tr><th>Order</th><th>Customer</th><th class="num">Amount</th><th>Payment</th><th></th></tr></thead><tbody>${n.map(s=>`<tr>
                    <td class="strong nowrap">${u(s.orderNumber)}</td>
                    <td class="ellip">${u(he(s))}</td>
                    <td class="num strong nowrap">${x(s.total)}</td>
                    <td><span class="badge ${s.paymentStatus}">${s.paymentStatus}</span></td>
                    <td class="num"><button class="btn small" data-label="${s.id}">Label</button></td>
                  </tr>`).join("")}</tbody></table></div>`}
      </div>`,bind(s){s.querySelector('[data-act="new"]')?.addEventListener("click",()=>t.go("new")),s.querySelector('[data-act="orders"]')?.addEventListener("click",()=>t.go("orders")),s.querySelector('[data-act="settings"]')?.addEventListener("click",()=>t.go("settings")),s.querySelectorAll("[data-label]").forEach(o=>o.addEventListener("click",()=>t.go("label",o.dataset.label)))}}}const oe=["Order Number","Order Date","Payment Status","Amount"];function le(t,a){const r=a.map(d=>d.trim().toLowerCase()).indexOf(t.trim().toLowerCase());return r>=0?a[r]:""}function Oe(t,a,e,r){return r[t]||le(a,e)}function ce(t){return le("Order Number",t)}async function J(t,a){const e=y();let r=T();r.length===0&&(r=await re(t,a));const d=r.map(o=>o.trim().toLowerCase()),n=[];for(const o of oe)d.includes(o.toLowerCase())||n.push(o);for(const o of w())e.customMap?.[o.id]||d.includes(o.name.trim().toLowerCase())||n.push(o.name);const s=n.length>0?await Ce(t,a,r,n):r;return(s!==r||T().length===0)&&z(s),s}function Pe(t,a,e={}){const r=a.map(s=>s.trim().toLowerCase()),d=new Array(a.length).fill(""),n=(s,o)=>{if(!s)return;const i=r.indexOf(s.trim().toLowerCase());i>=0&&(d[i]=o)};n("Order Number",t.orderNumber),n("Order Date",t.createdAt.slice(0,10)),n("Payment Status",t.paymentStatus),n("Amount",String(t.total)),n("Products",t.items.map(s=>s.qty>1?`${s.name} x ${s.qty}`:s.name).join(", ")),n("Quantity",String(t.items.reduce((s,o)=>s+o.qty,0))),n("SKU",t.items.map(s=>s.sku).filter(Boolean).join(", "));for(const s of w())n(Oe(s.id,s.name,a,e),t.customerData[s.id]||"");return d}async function Re(t){const a=y();if(!a.sheetId||!a.sheetName)return 0;const e=await J(a.sheetId,a.sheetName),r=a.customMap||{};let d=t.sheetRow||0;if(d===0){const o=ce(e);o&&(d=(await ie(a.sheetId,a.sheetName,o,t.orderNumber)).row)}const n=Pe(t,e,r),s=await Ae(a.sheetId,a.sheetName,d,n);return t.sheetRow=s||d,t.sheetRow}async function De(t){const a=y();if(!a.sheetId||!a.sheetName)return!1;const e=T().length>0?T():await re(a.sheetId,a.sheetName),r=ce(e);return r?(await ie(a.sheetId,a.sheetName,r,t)).row>0:!1}function je(t){const a=t.trim();if(!a)return"";const e=/docs\.google\.com\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/.exec(a);return e?e[1]:a}let k=null,P=null;function X(){return{id:null,orderNumber:W(),customerData:{},items:[],paymentStatus:"COD"}}function Te(t,a){const e=t.required?' <span class="req">*</span>':"",r=u(t.id);switch(t.type){case"textarea":return`<div class="field span2"><label class="f">${u(t.name)}${e}</label><textarea rows="2" data-fid="${r}">${u(a)}</textarea></div>`;case"dropdown":{const d=(t.options||[]).map(n=>`<option ${n===a?"selected":""}>${u(n)}</option>`).join("");return`<div class="field"><label class="f">${u(t.name)}${e}</label><select data-fid="${r}"><option value=""></option>${d}</select></div>`}case"checkbox":return`<div class="field"><label class="f">${u(t.name)}${e}</label><label class="checkrow" style="padding:6px 0 0"><input type="checkbox" data-fid="${r}" ${a==="Yes"?"checked":""}> Yes</label></div>`;default:{const d=t.type==="number"?"number":t.type==="phone"?"tel":t.type==="email"?"email":t.type==="date"?"date":"text";return`<div class="field"><label class="f">${u(t.name)}${e}</label><input type="${d}" data-fid="${r}" value="${u(a)}"${t.type==="number"?' step="any"':""}></div>`}}}function Fe(t){if(!k||P!==t.id){if(t.id){const n=ae(t.id);k=n?{id:n.id,orderNumber:n.orderNumber,customerData:{...n.customerData},items:n.items.map(s=>({...s})),paymentStatus:n.paymentStatus,sheetRow:n.sheetRow,createdAt:n.createdAt,labelPrinted:n.labelPrinted}:X()}else k=X();P=t.id}const a=k,e=w(),r=a.items.reduce((n,s)=>n+s.price*s.qty,0),d=a.items.map((n,s)=>`<tr>
        <td><div class="strong">${u(n.name)}</div>${n.sku?`<div class="muted" style="font-size:11px">${u(n.sku)}</div>`:""}</td>
        <td class="num"><input class="price-input" type="number" step="any" min="0" data-price="${s}" value="${n.price}"></td>
        <td class="num"><input class="qty-input" type="number" min="1" step="1" data-qty="${s}" value="${n.qty}"></td>
        <td class="num strong" data-line="${s}">${x(n.price*n.qty)}</td>
        <td class="num"><button class="btn small ghost-danger" data-rm="${s}" title="Remove">✕</button></td>
      </tr>`).join("");return{html:`<div class="page-head">
        <div>
          <h2 class="page-title">${a.id?"Edit Order":"New Order"}</h2>
          <div class="page-sub">Order <span class="ordnum">${u(a.orderNumber)}</span>${a.sheetRow?` · updates spreadsheet row ${a.sheetRow}`:""}</div>
        </div>
        <div class="head-actions"><div><label class="f">Order Number</label><input type="text" class="mini-input" data-onum value="${u(a.orderNumber)}" title="You can set a manual order number"></div></div>
      </div>
      <div class="card">
        <div class="card-title">Customer Details</div>
        ${e.length===0?'<div class="muted">No custom fields yet — create them in <b>Custom Fields</b>. They become your spreadsheet columns.</div>':`<div class="fgrid">${e.map(n=>Te(n,a.customerData[n.id]||"")).join("")}</div>`}
      </div>
      <div class="card">
        <div class="card-title">Products</div>
        ${a.items.length===0?'<div class="muted" style="margin-bottom:10px">No products added yet.</div>':`<div class="tblwrap" style="border:0;margin-bottom:10px"><table class="tbl items-tbl"><thead><tr><th>Product</th><th class="num">Price (₹)</th><th class="num">Qty</th><th class="num">Total</th><th></th></tr></thead><tbody>${d}</tbody></table></div>`}
        <button class="btn" data-act="addprod">+ Add Product</button>
      </div>
      <div class="card">
        <div class="savebar">
          <div class="paywrap">Payment
            <select data-pay style="width:150px">${ve.map(n=>`<option ${n===a.paymentStatus?"selected":""}>${n}</option>`).join("")}</select>
          </div>
          <div class="spacer"></div>
          <div class="totline">Total&nbsp; <b data-total>${x(r)}</b></div>
        </div>
      </div>
      <div class="form-foot">
        <button class="btn" data-act="cancel">Cancel</button>
        <button class="btn primary" data-act="save">${a.id?"Update Order":"Save Order"}</button>
      </div>`,bind(n){const s=k;n.querySelectorAll("[data-fid]").forEach(i=>{const l=i.dataset.fid,c=i.tagName==="SELECT"||i.type==="checkbox"?"change":"input";i.addEventListener(c,()=>{const p=i;s.customerData[l]=p.type==="checkbox"?p.checked?"Yes":"":p.value,p.classList.remove("invalid")})}),n.querySelector("[data-onum]")?.addEventListener("input",i=>{s.orderNumber=i.target.value,n.querySelector(".ordnum").textContent=s.orderNumber}),n.querySelector("[data-pay]")?.addEventListener("change",i=>{s.paymentStatus=i.target.value});const o=i=>{const l=s.items[i],c=n.querySelector(`[data-line="${i}"]`);c&&(c.textContent=x(l.price*l.qty));const p=n.querySelector("[data-total]");p&&(p.textContent=x(s.items.reduce((b,$)=>b+$.price*$.qty,0)))};n.querySelectorAll("[data-qty]").forEach(i=>i.addEventListener("input",()=>{const l=Number(i.dataset.qty);s.items[l].qty=Math.max(1,Math.floor(Number(i.value)||1)),o(l)})),n.querySelectorAll("[data-price]").forEach(i=>i.addEventListener("input",()=>{const l=Number(i.dataset.price);s.items[l].price=Math.max(0,Number(i.value)||0),o(l)})),n.querySelectorAll("[data-rm]").forEach(i=>i.addEventListener("click",()=>{s.items.splice(Number(i.dataset.rm),1),t.rerender()})),n.querySelector('[data-act="addprod"]')?.addEventListener("click",()=>{const i=C().filter(l=>l.active);if(i.length===0){h("No active products. Add some in the Products page first.","err");return}F(`<h3>Add Product</h3>
           <input type="text" placeholder="Search products…" data-search style="margin-bottom:8px">
           <div class="plist" data-list></div>
           <div class="row"><button class="btn" data-close>Close</button></div>`,(l,c)=>{const p=l.querySelector("[data-list]"),b=l.querySelector("[data-search]"),$=()=>{const m=b.value.trim().toLowerCase(),v=i.filter(f=>!m||f.name.toLowerCase().includes(m)||f.sku.toLowerCase().includes(m));p.innerHTML=v.length===0?'<div class="muted" style="padding:10px">No products found.</div>':v.map(f=>{const g=s.items.some(I=>I.productId===f.id);return`<button data-pid="${f.id}" ${g?"disabled":""}><span class="strong">${u(f.name)}</span><span class="muted">${u(f.sku)}</span><span class="p-price">${x(f.price)}</span></button>`}).join("")};$(),b.addEventListener("input",$),b.focus(),p.addEventListener("click",m=>{const v=m.target.closest("[data-pid]");if(!v||v.hasAttribute("disabled"))return;const f=i.find(g=>g.id===v.dataset.pid);s.items.push({productId:f.id,name:f.name,sku:f.sku,price:f.price,qty:1}),c(),t.rerender()}),l.querySelector("[data-close]").addEventListener("click",c)})}),n.querySelector('[data-act="cancel"]')?.addEventListener("click",()=>{k=null,P=null,t.go("orders")}),n.querySelector('[data-act="save"]')?.addEventListener("click",()=>void Ue(t,n))}}}async function Ue(t,a){const e=k,r=w(),d=[];e.orderNumber.trim()||d.push("Order number is required.");for(const c of r){const p=(e.customerData[c.id]||"").trim(),b=a.querySelector(`[data-fid="${c.id}"]`);c.required&&!p?(d.push(`${c.name} is required.`),b?.classList.add("invalid")):p&&c.type==="phone"&&!be(p)?(d.push(`${c.name}: enter a valid phone number.`),b?.classList.add("invalid")):p&&c.type==="email"&&!fe(p)?(d.push(`${c.name}: enter a valid email address.`),b?.classList.add("invalid")):p&&c.type==="number"&&Number.isNaN(Number(p))&&(d.push(`${c.name} must be a number.`),b?.classList.add("invalid"))}e.items.length===0&&d.push("Add at least one product.");for(const c of e.items)(!(c.qty>=1)||!Number.isInteger(c.qty))&&d.push(`Quantity for ${c.name} must be a whole number (at least 1).`),c.price>=0||d.push(`Price for ${c.name} is invalid.`);if(d.length>0){h(d[0],"err");return}const n=ye(e.orderNumber);if(n&&n.id!==e.id){F(`<h3>Order already exists.</h3>
       <p class="muted" style="margin:0"><b>${u(e.orderNumber)}</b> already exists on this device.</p>
       <div class="row" style="justify-content:flex-start">
         <button class="btn" data-open>Open Order</button>
         <button class="btn" data-edit>Edit Order</button>
         <button class="btn" data-x>Cancel</button>
       </div>`,(c,p)=>{c.querySelector("[data-open]").addEventListener("click",()=>{k=null,P=null,p(),t.go("label",n.id)}),c.querySelector("[data-edit]").addEventListener("click",()=>{k=null,P=null,p(),t.go("new",n.id)}),c.querySelector("[data-x]").addEventListener("click",p)});return}if(!e.id&&y().sheetId)try{if(await De(e.orderNumber.trim())){F(`<h3>Order already exists.</h3>
           <p class="muted" style="margin:0"><b>${u(e.orderNumber)}</b> is already used in your spreadsheet.</p>
           <div class="row" style="justify-content:flex-start">
             <button class="btn primary" data-next>Use Next Number</button>
             <button class="btn" data-x>Cancel</button>
           </div>`,(c,p)=>{c.querySelector("[data-next]").addEventListener("click",async()=>{p(),await K(),e.orderNumber=W();const b=a.querySelector("[data-onum]");b&&(b.value=e.orderNumber);const $=a.querySelector(".ordnum");$&&($.textContent=e.orderNumber),h(`Switched to ${e.orderNumber}.`)}),c.querySelector("[data-x]").addEventListener("click",p)});return}}catch(c){h(U(c),"err");return}const s=new Date().toISOString(),o={id:e.id||Y("o_"),orderNumber:e.orderNumber.trim(),customerData:{...e.customerData},items:e.items.map(c=>({...c})),paymentStatus:e.paymentStatus,total:e.items.reduce((c,p)=>c+p.price*p.qty,0),createdAt:e.createdAt||s,updatedAt:s,labelPrinted:e.labelPrinted||!1,sheetRow:e.sheetRow},i=!e.id;await Q(o);let l="";if(y().sheetId)try{o.sheetRow=await Re(o),await Q(o)}catch(c){l=U(c)}i&&e.orderNumber===W()&&await K(),k=null,P=null,h(i?"Order saved successfully.":"Order updated successfully.","ok"),l&&h("Saved on this device. Google Sheets: "+l,"err"),t.go("orders")}function Ge(t){const a=C();return{html:`<div class="page-head">
        <div><h2 class="page-title">Products</h2><div class="page-sub">Select these while creating an order</div></div>
        <div class="head-actions"><button class="btn primary" data-act="add">+ Add Product</button></div>
      </div>
      ${a.length===0?'<div class="card"><div class="empty">No products yet.<br><button class="btn primary" data-act="add">+ Add Product</button></div></div>':`<div class="tblwrap"><table class="tbl">
        <thead><tr><th>Name</th><th>SKU</th><th class="num">Price</th><th>Active</th><th></th></tr></thead>
        <tbody>${a.map(e=>`<tr>
          <td class="strong">${u(e.name)}</td>
          <td class="muted">${u(e.sku)}</td>
          <td class="num strong nowrap">${x(e.price)}</td>
          <td><label class="switch"><input type="checkbox" data-toggle="${e.id}" ${e.active?"checked":""}><i></i></label></td>
          <td><div class="rowbtns">
            <button class="btn small" data-edit="${e.id}">Edit</button>
            <button class="btn small ghost-danger" data-del="${e.id}">Delete</button>
          </div></td>
        </tr>`).join("")}</tbody></table></div>`}`,bind(e){e.querySelectorAll('[data-act="add"]').forEach(r=>r.addEventListener("click",()=>void ee(null,t))),e.querySelectorAll("[data-toggle]").forEach(r=>r.addEventListener("change",async()=>{const d=r.dataset.toggle,n=r.checked;await G(C().map(s=>s.id===d?{...s,active:n}:s))})),e.querySelectorAll("[data-edit]").forEach(r=>r.addEventListener("click",()=>{const d=C().find(n=>n.id===r.dataset.edit);d&&ee(d,t)})),e.querySelectorAll("[data-del]").forEach(r=>r.addEventListener("click",async()=>{const d=C().find(s=>s.id===r.dataset.del);!d||!await se("Delete product?",`<b>${u(d.name)}</b> will be removed from the product list. Existing orders are not affected.`,"Delete")||(await G(C().filter(s=>s.id!==d.id)),h("Product deleted."),t.rerender())}))}}}async function ee(t,a){F(`<h3>${t?"Edit Product":"Add Product"}</h3>
     <div class="fgrid">
       <div class="field span2"><label class="f">Name <span class="req">*</span></label><input type="text" data-n value="${u(t?.name||"")}"></div>
       <div class="field"><label class="f">SKU</label><input type="text" data-s value="${u(t?.sku||"")}"></div>
       <div class="field"><label class="f">Price (₹)</label><input type="number" step="any" min="0" data-p value="${t?.price??0}"></div>
     </div>
     <label class="checkrow"><input type="checkbox" data-a ${t?.active??!0?"checked":""}> Active (selectable in orders)</label>
     <div class="row"><button class="btn" data-x>Cancel</button><button class="btn primary" data-save>Save</button></div>`,(e,r)=>{e.querySelector("[data-x]").addEventListener("click",r),e.querySelector("[data-save]").addEventListener("click",async()=>{const d=e.querySelector("[data-n]").value.trim(),n=e.querySelector("[data-s]").value.trim(),s=Math.max(0,Number(e.querySelector("[data-p]").value)||0),o=e.querySelector("[data-a]").checked;if(!d){e.querySelector("[data-n]").classList.add("invalid"),h("Product name is required.","err");return}const i=C();t?await G(i.map(l=>l.id===t.id?{...l,name:d,sku:n,price:s,active:o}:l)):await G([...i,{id:Y("p_"),name:d,sku:n,price:s,active:o}]),r(),h("Product saved.","ok"),a.rerender()})})}function Me(t){const a=w();return{html:`<div class="page-head">
        <div><h2 class="page-title">Custom Fields</h2><div class="page-sub">Each field becomes a spreadsheet column — every order fills one row</div></div>
        <div class="head-actions"><button class="btn primary" data-act="add">+ Add Field</button></div>
      </div>
      <div class="card">
        ${a.length===0?'<div class="empty">No fields yet. Add fields like Customer Name, Phone, Address, City…<br><button class="btn primary" data-act="add">+ Add Field</button></div>':`<div>${a.map((e,r)=>`<div class="list-row">
              <span class="muted nowrap" style="font-size:11px">${r+1}.</span>
              <div class="grow"><span class="name">${u(e.name)}</span>${e.required?' <span class="req" style="color:var(--danger);font-weight:800">*</span>':""}</div>
              <span class="type-badge">${e.type}</span>
              <label class="switch" title="Required"><input type="checkbox" data-req="${e.id}" ${e.required?"checked":""}><i></i></label>
              <button class="btn small icon" data-up="${e.id}" ${r===0?"disabled":""} title="Move up">↑</button>
              <button class="btn small icon" data-down="${e.id}" ${r===a.length-1?"disabled":""} title="Move down">↓</button>
              <button class="btn small" data-edit="${e.id}">Edit</button>
              <button class="btn small ghost-danger" data-del="${e.id}">Delete</button>
            </div>`).join("")}</div>`}
        <div class="hint">Reorder with ↑ ↓ — the order here is the order in the order form and on the label.</div>
      </div>`,bind(e){e.querySelector('[data-act="add"]')?.addEventListener("click",()=>void te(null,t)),e.querySelectorAll("[data-req]").forEach(d=>d.addEventListener("change",async()=>{const n=d.dataset.req,s=d.checked;await j(w().map(o=>o.id===n?{...o,required:s}:o))}));const r=async(d,n)=>{const s=w(),o=s.findIndex(l=>l.id===d),i=o+n;o<0||i<0||i>=s.length||([s[o],s[i]]=[s[i],s[o]],await j(s.map((l,c)=>({...l,order:c}))),t.rerender())};e.querySelectorAll("[data-up]").forEach(d=>d.addEventListener("click",()=>void r(d.dataset.up,-1))),e.querySelectorAll("[data-down]").forEach(d=>d.addEventListener("click",()=>void r(d.dataset.down,1))),e.querySelectorAll("[data-edit]").forEach(d=>d.addEventListener("click",()=>{const n=w().find(s=>s.id===d.dataset.edit);n&&te(n,t)})),e.querySelectorAll("[data-del]").forEach(d=>d.addEventListener("click",async()=>{const n=w().find(i=>i.id===d.dataset.del);if(!n||!await se("Delete field?",`<b>${u(n.name)}</b> will be removed from the order form. Existing orders keep their data, and the spreadsheet column is never deleted.`,"Delete"))return;const o=w().filter(i=>i.id!==n.id);await j(o.map((i,l)=>({...i,order:l}))),h("Field deleted."),t.rerender()}))}}}async function te(t,a){F(`<h3>${t?"Edit Field":"Add Field"}</h3>
     <div class="fgrid">
       <div class="field span2"><label class="f">Field name <span class="req">*</span></label><input type="text" data-n value="${u(t?.name||"")}" placeholder="e.g. Customer Name"></div>
       <div class="field"><label class="f">Type</label><select data-t>${ge.map(([e,r])=>`<option value="${e}" ${t?.type===e?"selected":""}>${r}</option>`).join("")}</select></div>
       <div class="field"><label class="f">Required</label><label class="checkrow" style="padding:6px 0 0"><input type="checkbox" data-r ${t?.required?"checked":""}> Must be filled</label></div>
       <div class="field span2" data-optwrap style="display:${t?.type==="dropdown"?"block":"none"}"><label class="f">Dropdown options <span class="muted">(one per line)</span></label><textarea rows="3" data-o>${u((t?.options||[]).join(`
`))}</textarea></div>
     </div>
     <div class="hint">Field names become spreadsheet column headers. Existing orders are never affected by changes here.</div>
     <div class="row"><button class="btn" data-x>Cancel</button><button class="btn primary" data-save>Save Field</button></div>`,(e,r)=>{const d=e.querySelector("[data-t]");d.addEventListener("change",()=>{e.querySelector("[data-optwrap]").style.display=d.value==="dropdown"?"block":"none"}),e.querySelector("[data-x]").addEventListener("click",r),e.querySelector("[data-save]").addEventListener("click",async()=>{const n=e.querySelector("[data-n]"),s=n.value.trim(),o=d.value,i=e.querySelector("[data-r]").checked,l=e.querySelector("[data-o]").value.split(`
`).map(b=>b.trim()).filter(Boolean);if(!s){n.classList.add("invalid"),h("Field name is required.","err");return}if(o==="dropdown"&&l.length===0){h("Add at least one dropdown option.","err");return}if(w().find(b=>b.name.trim().toLowerCase()===s.toLowerCase()&&b.id!==t?.id)){n.classList.add("invalid"),h("A field with this name already exists.","err");return}const p=w();t?await j(p.map(b=>b.id===t.id?{...b,name:s,type:o,required:i,options:o==="dropdown"?l:void 0}:b)):await j([...p,{id:Y("f_"),name:s,type:o,required:i,options:o==="dropdown"?l:void 0,order:p.length}]),r(),h("Field saved.","ok"),a.rerender()})})}const O={signedIn:!1};function Be(t){const a=y(),e=w(),r=T(),d=!!a.sheetId,n=e.map(l=>`<label class="checkrow"><input type="checkbox" data-lf="${l.id}" ${a.labelFields.includes(l.id)?"checked":""}> ${u(l.name)}</label>`).join(""),o=[["orderNumber","Order Number"],["products","Products"],["quantity","Quantity"],["payment","Payment Status"],["amount","Amount"],["gst","Business GST"],["barcode","Barcode"]].map(([l,c])=>`<label class="checkrow"><input type="checkbox" data-ex="${l}" ${a.labelExtras[l]?"checked":""}> ${c}</label>`).join(""),i=d?`<div class="card-sub" style="margin-top:12px">Column mapping — fields reuse matching columns automatically. Map a field to a different existing column if needed.</div>
       ${e.length===0?'<div class="muted" style="font-size:12px">No custom fields to map.</div>':e.map(l=>{const c=a.customMap[l.id]||"";return`<div class="map-row"><div class="strong">${u(l.name)}</div><select data-map="${l.id}"><option value="">Auto${c?"":" (matched)"}</option>${r.map(p=>`<option value="${u(p)}" ${c===p?"selected":""}>${u(p)}</option>`).join("")}</select></div>`}).join("")}`:"";return{html:`<div class="page-head">
        <div><h2 class="page-title">Settings</h2><div class="page-sub">Changes are saved automatically</div></div>
      </div>

      <div class="card">
        <div class="card-title">Business</div>
        <div class="set-grid">
          <div class="field"><label class="f">Business Name</label><input type="text" data-k="businessName" value="${u(a.businessName)}"></div>
          <div class="field"><label class="f">Phone</label><input type="text" data-k="phone" value="${u(a.phone)}"></div>
          <div class="field"><label class="f">Website</label><input type="text" data-k="website" value="${u(a.website)}"></div>
          <div class="field"><label class="f">GST</label><input type="text" data-k="gst" value="${u(a.gst)}"></div>
          <div class="field span2"><label class="f">Address</label><textarea rows="2" data-k="address">${u(a.address)}</textarea></div>
          <div class="field span2"><label class="f">Label Footer</label><input type="text" data-k="footer" value="${u(a.footer)}" placeholder="Thank you for your order!"></div>
          <div class="field span2"><label class="f">Logo</label>
            <div class="logo-row">
              ${a.logo?`<img src="${a.logo}" alt="logo">`:""}
              <button class="btn small" data-act="logo">${a.logo?"Change Logo":"Upload Logo"}</button>
              ${a.logo?'<button class="btn small ghost-danger" data-act="logorm">Remove</button>':""}
              <input type="file" accept="image/*" data-logo hidden>
            </div>
            <div class="hint">Shown on the shipping label. PNG/JPG, up to ~300 KB.</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Google Sheets</div>
        <div class="toolbar" style="margin-bottom:8px">
          <span class="dot ${O.signedIn?"on":""}" data-gdot></span>
          <span class="count" data-gstatus>${d?`Spreadsheet connected: ${a.sheetName||"…"}`:O.signedIn?"Google account connected":"Not connected"}</span>
          <span class="spacer"></span>
          <button class="btn small" data-act="gdisconnect" ${O.signedIn||d?"":"disabled"}>Disconnect</button>
        </div>
        <div class="set-grid">
          <div class="field span2"><label class="f">Spreadsheet URL or ID</label><input type="text" data-sheetref value="${u(a.sheetId)}" placeholder="https://docs.google.com/spreadsheets/d/…"></div>
          <div class="field"><label class="f">Worksheet</label><select data-ws ${d?"":"disabled"}><option value="${u(a.sheetName)}">${u(a.sheetName||"—")}</option></select></div>
          <div class="field"><label class="f">&nbsp;</label><button class="btn" data-act="use" style="width:100%">${d?"Re-read Connection":"Connect Spreadsheet"}</button></div>
        </div>
        <div class="field" style="margin-top:4px"><label class="f">Google OAuth Client ID</label><input type="text" data-k="clientId" value="${u(a.clientId)}" placeholder="xxxxxxxx.apps.googleusercontent.com"></div>
        <details class="help">
          <summary>One-time setup: how to get a Client ID (free, ~2 minutes)</summary>
          <ol>
            <li>Open <b>console.cloud.google.com</b> → create/select a project.</li>
            <li><b>APIs &amp; Services → Library</b> → enable <b>Google Sheets API</b>.</li>
            <li><b>OAuth consent screen</b> → External → add yourself as a <b>test user</b>.</li>
            <li><b>Credentials → Create credentials → OAuth client ID</b> → type <b>Web application</b>.</li>
            <li>Add this <b>Authorized redirect URI</b>: <code>${u(chrome?.identity?.getRedirectURL?chrome.identity.getRedirectURL():"chrome-extension://EXTENSION_ID.chromiumapp.org/")}</code></li>
            <li>Copy the <b>Client ID</b> and paste it above, then click <b>Connect Spreadsheet</b>.</li>
          </ol>
        </details>
        ${i}
      </div>

      <div class="card">
        <div class="card-title">Orders</div>
        <div class="set-grid">
          <div class="field"><label class="f">Order Prefix</label><input type="text" data-k="orderPrefix" value="${u(a.orderPrefix)}"></div>
          <div class="field"><label class="f">Starting Number</label><input type="number" min="1" step="1" data-k="nextNumber" value="${a.nextNumber}"></div>
        </div>
        <div class="hint">New orders get <b>${u(a.orderPrefix)}${a.nextNumber}</b>. You can always type a manual order number.</div>
      </div>

      <div class="card">
        <div class="card-title">Label</div>
        <div class="set-grid">
          <div class="field"><label class="f">Label Size</label>
            <select data-k="labelSize">
              <option value="4x6" ${a.labelSize==="4x6"?"selected":""}>4 × 6 inch (default)</option>
              <option value="a6" ${a.labelSize==="a6"?"selected":""}>A6 (105 × 148 mm)</option>
            </select>
          </div>
        </div>
        <div class="card-sub" style="margin-top:12px">Customer fields shown on the label</div>
        ${e.length===0?'<div class="muted" style="font-size:12px">No custom fields yet.</div>':`<div style="columns:2;gap:24px">${n}</div>`}
        <div class="card-sub" style="margin-top:12px">Label sections</div>
        <div style="columns:2;gap:24px">${o}</div>
      </div>

      <div class="card">
        <div class="card-title">Backup</div>
        <div class="toolbar">
          <button class="btn" data-act="export">Export Orders</button>
          <button class="btn" data-act="import">Import Settings</button>
          <span class="count">Exports include orders, fields, products and settings as JSON.</span>
        </div>
        <input type="file" accept="application/json" data-importfile hidden>
      </div>`,async bind(l){const c=y();l.querySelectorAll("[data-k]").forEach(m=>{const v=m.dataset.k;m.addEventListener("change",async()=>{let g=m.value;v==="nextNumber"&&(g=Math.max(1,Math.floor(Number(g)||1))),await S({...y(),[v]:g}),h("Saved.")})});const p=l.querySelector("[data-logo]");l.querySelector('[data-act="logo"]')?.addEventListener("click",()=>p.click()),p?.addEventListener("change",()=>{const m=p.files?.[0];if(!m)return;if(m.size>400*1024){h("Logo is too large — please use an image under 400 KB.","err"),p.value="";return}const v=new FileReader;v.onload=async()=>{await S({...y(),logo:String(v.result)}),h("Logo saved.","ok"),t.rerender()},v.readAsDataURL(m)}),l.querySelector('[data-act="logorm"]')?.addEventListener("click",async()=>{await S({...y(),logo:""}),t.rerender()}),de().then(m=>{O.signedIn=m;const v=l.querySelector("[data-gdot]"),f=l.querySelector("[data-gstatus]");v&&(v.className="dot "+(m?"on":"")),f&&!y().sheetId&&(f.textContent=m?"Google account connected":"Not connected")}).catch(()=>{}),l.querySelector('[data-act="use"]')?.addEventListener("click",()=>void _e(t,l)),l.querySelector('[data-act="gdisconnect"]')?.addEventListener("click",()=>void We(t));const b=l.querySelector("[data-ws]");b?.addEventListener("change",()=>void ze(t,b.value)),l.querySelectorAll("[data-map]").forEach(m=>m.addEventListener("change",async()=>{const v=m.dataset.map,f=m.value,g={...y().customMap};f?g[v]=f:delete g[v],await S({...y(),customMap:g}),h("Column mapping saved.","ok")})),l.querySelectorAll("[data-lf]").forEach(m=>m.addEventListener("change",async()=>{const v=m.dataset.lf,f=m.checked,g=w().filter(I=>I.id===v?f:c.labelFields.includes(I.id)).map(I=>I.id);await S({...y(),labelFields:g})})),l.querySelectorAll("[data-ex]").forEach(m=>m.addEventListener("change",async()=>{const v=m.dataset.ex,f=m.checked,g={...y().labelExtras,[v]:f};await S({...y(),labelExtras:g})})),l.querySelector('[data-act="export"]')?.addEventListener("click",()=>{we(),h("Backup exported.","ok")});const $=l.querySelector("[data-importfile]");l.querySelector('[data-act="import"]')?.addEventListener("click",()=>$.click()),$?.addEventListener("change",()=>{const m=$.files?.[0];m&&$e(m).then(()=>{h("Settings imported.","ok"),t.rerender()}).catch(v=>h("Import failed: "+(v instanceof Error?v.message:"invalid file"),"err"))})}}}async function _e(t,a){const e=y(),r=a.querySelector("[data-sheetref]"),d=r.value.trim();if(!e.clientId.trim()){h("Add your Google OAuth Client ID first (see the steps below the field).","err");return}if(!d){r.classList.add("invalid"),h("Paste your Google Sheets link or spreadsheet ID.","err");return}const n=je(d);try{await S({...y(),clientId:e.clientId.trim()}),await Le();const s=await xe(n);if(s.sheets.length===0)throw new Error("This spreadsheet has no worksheets.");const o=s.sheets[0],i=await J(n,o);await S({...y(),sheetId:n,sheetName:o}),z(i),O.signedIn=!0,h(`Connected. ${i.length} columns ready (${oe.length} standard + your fields).`,"ok"),t.rerender()}catch(s){h(U(s),"err")}}async function ze(t,a){const e=y();if(!(!e.sheetId||!a))try{const r=await J(e.sheetId,a);await S({...y(),sheetName:a}),z(r),h(`Worksheet switched to "${a}".`,"ok"),t.rerender()}catch(r){h(U(r),"err")}}async function We(t){try{await Ne()}catch{}await S({...y(),sheetId:"",sheetName:""}),z([]),O.signedIn=!1,h("Disconnected from Google Sheets."),t.rerender()}const N=document.getElementById("app"),He=[["dashboard","Dashboard",q.dash],["new","New Order",q.plus],["orders","Orders",q.list],["products","Products",q.box],["fields","Custom Fields",q.sliders],["settings","Settings",q.gear]];let A="dashboard",E=null;const B={get route(){return A},get id(){return E},go(t,a=null){A=t,E=a??null;const e=t==="new"?E?`#edit=${E}`:"#new":t==="label"&&E?`#label=${E}`:"";try{history.replaceState(null,"",e||location.pathname)}catch{}_()},rerender(){_()}},Ye={dashboard:Ie,new:Fe,orders:t=>Ee(t,!1),products:Ge,fields:Me,settings:Be};function Je(){if(A==="label"){const t=E?ae(E):void 0;if(t)return ke(t,()=>B.go("orders"),()=>_());A="orders",E=null}return Ye[A](B)}function _(){const t=Je();N.innerHTML=`
    <header class="top">
      <div class="brand">${q.tag} Order Label Manager</div>
      <div class="spacer"></div>
      <button class="conn" data-conn title="Google Sheets connection status — click to open Settings"><span class="dot" data-gdot></span><span data-gtxt>Google</span></button>
      <button class="btn small" data-opentab title="Open all orders in a full browser tab">Orders ${q.external}</button>
    </header>
    <nav class="tabs">${He.map(([e,r,d])=>`<button data-route="${e}" class="${A===e?"active":""}">${d} ${r}</button>`).join("")}</nav>
    <main class="content"></main>`;const a=N.querySelector("main.content");a.innerHTML=t.html,N.querySelectorAll("[data-route]").forEach(e=>e.addEventListener("click",()=>B.go(e.dataset.route))),N.querySelector("[data-opentab]")?.addEventListener("click",()=>window.open(chrome.runtime.getURL("orders.html"))),N.querySelector("[data-conn]")?.addEventListener("click",()=>B.go("settings")),de().then(e=>{const r=N.querySelector("[data-gdot]"),d=N.querySelector("[data-gtxt]");r&&(r.className="dot "+(e?"on":"")),d&&(d.textContent=e?"Google connected":"Google")}).catch(()=>{}),t.bind?.(a)}function Ke(){const t=location.hash.replace(/^#/,""),[a,e]=t.split("=");return a==="edit"&&e?{route:"new",id:e}:a==="label"&&e?{route:"label",id:e}:a==="new"?{route:"new",id:null}:{route:"dashboard",id:null}}function Qe(){return new Promise(t=>{try{chrome.windows.getCurrent(a=>t(a.type==="normal"))}catch{t(!1)}})}async function Ve(){await Se();const t=Ke();A=t.route,E=t.id,document.documentElement.classList.toggle("as-page",await Qe()),_()}Ve();
