import{g as f,S as he,a as ve,t as be,e as c,c as fe,m as C,b as F,d as g,s as W,f as de,h as A,i as b,j as T,P as ye,n as Y,k as ge,l as we,o as $e,p as Z,q as G,u as K,r as X,v as M,w as re,x as j,F as Se,y as S,z as ke,A as Ee,B as qe,I as L,C as Le,D as Ne}from"./label-view-BlIO_JCj.js";const ie=typeof chrome<"u"&&!!chrome.identity?.launchWebAuthFlow;let N=null;const xe=()=>ie&&!!f().clientId;function oe(){return xe()?B(!1).then(()=>!0).catch(()=>!1):Promise.resolve(!1)}async function Ce(){if(!ie)throw new Error("Chrome identity API is not available.");await B(!0)}async function Ae(){N&&fetch("https://oauth2.googleapis.com/revoke?token="+encodeURIComponent(N.token)).catch(()=>{}),N=null}function ee(a,t){return"https://accounts.google.com/o/oauth2/v2/auth?"+new URLSearchParams({client_id:a,response_type:"token",redirect_uri:chrome.identity.getRedirectURL(),scope:he,prompt:t}).toString()}function te(a,t){return new Promise((e,r)=>{chrome.identity.launchWebAuthFlow({url:a,interactive:!t},d=>{const n=chrome.runtime.lastError,s=l=>r(new Error(t?"silent-fail":l));if(n||!d)return s("Google sign-in failed or was cancelled.");try{const l=new URLSearchParams(new URL(d).hash.replace(/^#/,"")),o=l.get("access_token"),p=Number(l.get("expires_in")||"3600");if(!o)return s("Google sign-in failed.");N={token:o,exp:Date.now()+Math.max(60,p-120)*1e3},e(o)}catch{s("Google sign-in failed.")}})})}async function B(a){if(N&&N.exp>Date.now())return N.token;const t=f().clientId;if(!t)throw new Error("Google Sheets is not set up yet. Add your OAuth Client ID in Settings.");try{return await te(ee(t,"none"),!0)}catch{if(!a)throw new Error("Not signed in to Google.");return te(ee(t,"select_account"),!1)}}async function R(a,t){let e="";try{e=(await a.json())?.error?.message||""}catch{}return a.status===401||a.status===403?new Error(`Google access was rejected while ${t}. Try reconnecting your account in Settings.`):a.status===404?new Error(`Spreadsheet or worksheet not found while ${t}. Check the connection in Settings.`):a.status>=500?new Error(`Google Sheets is temporarily unavailable while ${t}. Please try again.`):new Error(e||`Google Sheets request failed while ${t} (error ${a.status}).`)}async function D(a,t,e=!0){let r;try{r=await B(e)}catch(n){throw new Error(n instanceof Error&&n.message!=="silent-fail"?n.message:"Not signed in to Google. Connect your account in Settings.")}let d=await fetch(a,{...t,headers:{...t?.headers||{},Authorization:"Bearer "+r}});return d.status===401&&(N=null,r=await B(e),d=await fetch(a,{...t,headers:{...t?.headers||{},Authorization:"Bearer "+r}})),d}async function Ie(a){let t;try{t=await D(`https://sheets.googleapis.com/v4/spreadsheets/${a}?fields=sheets.properties.title`)}catch{throw new Error("Network problem while opening the spreadsheet. Check your internet connection.")}if(!t.ok)throw await R(t,"opening the spreadsheet");return{sheets:((await t.json()).sheets||[]).map(r=>r.properties.title)}}async function le(a,t){const e=await D(`https://sheets.googleapis.com/v4/spreadsheets/${a}/values/${encodeURIComponent(U(t,"1:1"))}`);if(!e.ok)throw await R(e,"reading headers");return((await e.json()).values?.[0]||[]).map(d=>String(d).trim())}async function Oe(a,t,e,r){const d=e.map(s=>s.trim().toLowerCase()),n=r.filter(s=>!d.includes(s.trim().toLowerCase()));if(n.length>0){const s=U(t,`${J(e.length)}1:${J(e.length+n.length-1)}1`),l=await D(`https://sheets.googleapis.com/v4/spreadsheets/${a}/values/${encodeURIComponent(s)}?valueInputOption=RAW`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({values:[n]})});if(!l.ok)throw await R(l,"creating columns")}return[...e,...n]}async function ce(a,t,e,r){const d=await D(`https://sheets.googleapis.com/v4/spreadsheets/${a}/values/${encodeURIComponent(U(t,`${e}:${e}`))}`);if(!d.ok)throw await R(d,"looking up the order number");const s=(await d.json()).values||[],l=r.trim().toLowerCase();for(let o=0;o<s.length;o++)if(String(s[o][0]||"").trim().toLowerCase()===l)return{row:o+1,last:s.length};return{row:0,last:s.length}}async function Pe(a,t,e,r){if(e>0){const l=U(t,`A${e}:${J(r.length-1)}${e}`),o=await D(`https://sheets.googleapis.com/v4/spreadsheets/${a}/values/${encodeURIComponent(l)}?valueInputOption=USER_ENTERED`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({values:[r]})});if(!o.ok)throw await R(o,"updating the order row");return e}const d=await D(`https://sheets.googleapis.com/v4/spreadsheets/${a}/values/${encodeURIComponent(U(t,"A:A"))}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({values:[r]})});if(!d.ok)throw await R(d,"adding the order row");const n=await d.json(),s=/![A-Z]+(\d+)/.exec(String(n.updates?.updatedRange||""));return s?Number(s[1]):0}function U(a,t){return"'"+a.replace(/'/g,"''")+"'!"+t}function J(a){let t="",e=a+1;for(;e>0;){const r=(e-1)%26;t=String.fromCharCode(65+r)+t,e=Math.floor((e-1)/26)}return t}function Re(a){const t=ve(),e=be(),r=s=>t.filter(s).length,d=[["Today's Orders",r(s=>s.createdAt.slice(0,10)===e)],["Pending Labels",r(s=>!s.labelPrinted)],["Paid Orders",r(s=>s.paymentStatus==="Paid")],["COD Orders",r(s=>s.paymentStatus==="COD")]],n=t.slice(0,5);return{html:`<div class="page-head">
        <div><h2 class="page-title">Dashboard</h2><div class="page-sub">Overview of your orders</div></div>
        <div class="head-actions">
          <button class="btn primary" data-act="new">+ New Order</button>
          <button class="btn" data-act="orders">Orders</button>
          <button class="btn" data-act="settings">Settings</button>
        </div>
      </div>
      <div class="stats">${d.map(([s,l])=>`<div class="stat"><div class="v">${l}</div><div class="l">${s}</div></div>`).join("")}</div>
      <div class="card">
        <div class="card-title">Recent Orders</div>
        ${n.length===0?'<div class="empty">No orders yet.<br><button class="btn primary" data-act="new">+ New Order</button></div>':`<div class="tblwrap" style="border:0"><table class="tbl"><thead><tr><th>Order</th><th>Customer</th><th class="num">Amount</th><th>Payment</th><th></th></tr></thead><tbody>${n.map(s=>`<tr>
                    <td class="strong nowrap">${c(s.orderNumber)}</td>
                    <td class="ellip">${c(fe(s))}</td>
                    <td class="num strong nowrap">${C(s.total)}</td>
                    <td><span class="badge ${s.paymentStatus}">${s.paymentStatus}</span></td>
                    <td class="num"><button class="btn small" data-label="${s.id}">Label</button></td>
                  </tr>`).join("")}</tbody></table></div>`}
      </div>`,bind(s){s.querySelector('[data-act="new"]')?.addEventListener("click",()=>a.go("new")),s.querySelector('[data-act="orders"]')?.addEventListener("click",()=>a.go("orders")),s.querySelector('[data-act="settings"]')?.addEventListener("click",()=>a.go("settings")),s.querySelectorAll("[data-label]").forEach(l=>l.addEventListener("click",()=>a.go("label",l.dataset.label)))}}}const ue=["Order Number","Order Date","Payment Status","Amount"];function pe(a,t){const r=t.map(d=>d.trim().toLowerCase()).indexOf(a.trim().toLowerCase());return r>=0?t[r]:""}function De(a,t,e,r){return r[a]||pe(t,e)}function me(a){return pe("Order Number",a)}async function Q(a,t){const e=f();let r=F();r.length===0&&(r=await le(a,t));const d=r.map(l=>l.trim().toLowerCase()),n=[];for(const l of ue)d.includes(l.toLowerCase())||n.push(l);for(const l of g())e.customMap?.[l.id]||d.includes(l.name.trim().toLowerCase())||n.push(l.name);const s=n.length>0?await Oe(a,t,r,n):r;return(s!==r||F().length===0)&&W(s),s}function je(a,t,e={}){const r=t.map(s=>s.trim().toLowerCase()),d=new Array(t.length).fill(""),n=(s,l)=>{if(!s)return;const o=r.indexOf(s.trim().toLowerCase());o>=0&&(d[o]=l)};n("Order Number",a.orderNumber),n("Order Date",a.createdAt.slice(0,10)),n("Payment Status",a.paymentStatus),n("Amount",String(a.total)),n("Products",a.items.map(s=>s.qty>1?`${s.name} x ${s.qty}`:s.name).join(", ")),n("Quantity",String(a.items.reduce((s,l)=>s+l.qty,0))),n("SKU",a.items.map(s=>s.sku).filter(Boolean).join(", "));for(const s of g())n(De(s.id,s.name,t,e),a.customerData[s.id]||"");return d}async function Fe(a){const t=f();if(!t.sheetId||!t.sheetName)return 0;const e=await Q(t.sheetId,t.sheetName),r=t.customMap||{};let d=a.sheetRow||0;if(d===0){const l=me(e);l&&(d=(await ce(t.sheetId,t.sheetName,l,a.orderNumber)).row)}const n=je(a,e,r),s=await Pe(t.sheetId,t.sheetName,d,n);return a.sheetRow=s||d,a.sheetRow}async function Te(a){const t=f();if(!t.sheetId||!t.sheetName)return!1;const e=F().length>0?F():await le(t.sheetId,t.sheetName),r=me(e);return r?(await ce(t.sheetId,t.sheetName,r,a)).row>0:!1}function Ue(a){const t=a.trim();if(!t)return"";const e=/docs\.google\.com\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/.exec(t);return e?e[1]:t}let k=null,P=null;function ae(){return{id:null,orderNumber:Y(),customerData:{},items:[],paymentStatus:"COD"}}function Ge(a,t){const e=a.required?' <span class="req">*</span>':"",r=c(a.id);switch(a.type){case"textarea":return`<div class="field span2"><label class="f">${c(a.name)}${e}</label><textarea rows="2" data-fid="${r}">${c(t)}</textarea></div>`;case"dropdown":{const d=(a.options||[]).map(n=>`<option ${n===t?"selected":""}>${c(n)}</option>`).join("");return`<div class="field"><label class="f">${c(a.name)}${e}</label><select data-fid="${r}"><option value=""></option>${d}</select></div>`}case"checkbox":return`<div class="field"><label class="f">${c(a.name)}${e}</label><label class="checkrow" style="padding:6px 0 0"><input type="checkbox" data-fid="${r}" ${t==="Yes"?"checked":""}> Yes</label></div>`;default:{const d=a.type==="number"?"number":a.type==="phone"?"tel":a.type==="email"?"email":a.type==="date"?"date":"text";return`<div class="field"><label class="f">${c(a.name)}${e}</label><input type="${d}" data-fid="${r}" value="${c(t)}"${a.type==="number"?' step="any"':""}></div>`}}}function Me(a){if(!k||P!==a.id){if(a.id){const n=de(a.id);k=n?{id:n.id,orderNumber:n.orderNumber,customerData:{...n.customerData},items:n.items.map(s=>({...s})),paymentStatus:n.paymentStatus,sheetRow:n.sheetRow,createdAt:n.createdAt,labelPrinted:n.labelPrinted}:ae()}else k=ae();P=a.id}const t=k,e=g(),r=t.items.reduce((n,s)=>n+s.price*s.qty,0),d=t.items.map((n,s)=>`<tr>
        <td><div class="strong">${c(n.name)}</div>${n.sku?`<div class="muted" style="font-size:11px">${c(n.sku)}</div>`:""}</td>
        <td class="num"><input class="price-input" type="number" step="any" min="0" data-price="${s}" value="${n.price}"></td>
        <td class="num"><input class="qty-input" type="number" min="1" step="1" data-qty="${s}" value="${n.qty}"></td>
        <td class="num strong" data-line="${s}">${C(n.price*n.qty)}</td>
        <td class="num"><button class="btn small ghost-danger" data-rm="${s}" title="Remove">✕</button></td>
      </tr>`).join("");return{html:`<div class="page-head">
        <div>
          <h2 class="page-title">${t.id?"Edit Order":"New Order"}</h2>
          <div class="page-sub">Order <span class="ordnum">${c(t.orderNumber)}</span>${t.sheetRow?` · updates spreadsheet row ${t.sheetRow}`:""}</div>
        </div>
        <div class="head-actions"><div><label class="f">Order Number</label><input type="text" class="mini-input" data-onum value="${c(t.orderNumber)}" title="You can set a manual order number"></div></div>
      </div>
      <div class="card">
        <div class="card-title">Customer Details</div>
        ${e.length===0?'<div class="muted">No custom fields yet — create them in <b>Custom Fields</b>. They become your spreadsheet columns.</div>':`<div class="fgrid">${e.map(n=>Ge(n,t.customerData[n.id]||"")).join("")}</div>`}
      </div>
      <div class="card">
        <div class="card-title">Products</div>
        ${t.items.length===0?'<div class="muted" style="margin-bottom:10px">No products added yet.</div>':`<div class="tblwrap" style="border:0;margin-bottom:10px"><table class="tbl items-tbl"><thead><tr><th>Product</th><th class="num">Price (₹)</th><th class="num">Qty</th><th class="num">Total</th><th></th></tr></thead><tbody>${d}</tbody></table></div>`}
        <button class="btn" data-act="addprod">+ Add Product</button>
      </div>
      <div class="card">
        <div class="savebar">
          <div class="paywrap">Payment
            <select data-pay style="width:150px">${ye.map(n=>`<option ${n===t.paymentStatus?"selected":""}>${n}</option>`).join("")}</select>
          </div>
          <div class="spacer"></div>
          <div class="totline">Total&nbsp; <b data-total>${C(r)}</b></div>
        </div>
      </div>
      <div class="form-foot">
        <button class="btn" data-act="cancel">Cancel</button>
        <button class="btn primary" data-act="save">${t.id?"Update Order":"Save Order"}</button>
      </div>`,bind(n){const s=k;n.querySelectorAll("[data-fid]").forEach(o=>{const p=o.dataset.fid,i=o.tagName==="SELECT"||o.type==="checkbox"?"change":"input";o.addEventListener(i,()=>{const u=o;s.customerData[p]=u.type==="checkbox"?u.checked?"Yes":"":u.value,u.classList.remove("invalid")})}),n.querySelector("[data-onum]")?.addEventListener("input",o=>{s.orderNumber=o.target.value,n.querySelector(".ordnum").textContent=s.orderNumber}),n.querySelector("[data-pay]")?.addEventListener("change",o=>{s.paymentStatus=o.target.value});const l=o=>{const p=s.items[o],i=n.querySelector(`[data-line="${o}"]`);i&&(i.textContent=C(p.price*p.qty));const u=n.querySelector("[data-total]");u&&(u.textContent=C(s.items.reduce((v,$)=>v+$.price*$.qty,0)))};n.querySelectorAll("[data-qty]").forEach(o=>o.addEventListener("input",()=>{const p=Number(o.dataset.qty);s.items[p].qty=Math.max(1,Math.floor(Number(o.value)||1)),l(p)})),n.querySelectorAll("[data-price]").forEach(o=>o.addEventListener("input",()=>{const p=Number(o.dataset.price);s.items[p].price=Math.max(0,Number(o.value)||0),l(p)})),n.querySelectorAll("[data-rm]").forEach(o=>o.addEventListener("click",()=>{s.items.splice(Number(o.dataset.rm),1),a.rerender()})),n.querySelector('[data-act="addprod"]')?.addEventListener("click",()=>{const o=A().filter(p=>p.active);if(o.length===0){b("No active products. Add some in the Products page first.","err");return}T(`<h3>Add Product</h3>
           <input type="text" placeholder="Search products…" data-search style="margin-bottom:8px">
           <div class="plist" data-list></div>
           <div class="row"><button class="btn" data-close>Close</button></div>`,(p,i)=>{const u=p.querySelector("[data-list]"),v=p.querySelector("[data-search]"),$=()=>{const q=v.value.trim().toLowerCase(),h=o.filter(m=>!q||m.name.toLowerCase().includes(q)||m.sku.toLowerCase().includes(q));u.innerHTML=h.length===0?'<div class="muted" style="padding:10px">No products found.</div>':h.map(m=>{const y=s.items.some(w=>w.productId===m.id);return`<button data-pid="${m.id}" ${y?"disabled":""}><span class="strong">${c(m.name)}</span><span class="muted">${c(m.sku)}</span><span class="p-price">${C(m.price)}</span></button>`}).join("")};$(),v.addEventListener("input",$),v.focus(),u.addEventListener("click",q=>{const h=q.target.closest("[data-pid]");if(!h||h.hasAttribute("disabled"))return;const m=o.find(y=>y.id===h.dataset.pid);s.items.push({productId:m.id,name:m.name,sku:m.sku,price:m.price,qty:1}),i(),a.rerender()}),p.querySelector("[data-close]").addEventListener("click",i)})}),n.querySelector('[data-act="cancel"]')?.addEventListener("click",()=>{k=null,P=null,a.go("orders")}),n.querySelector('[data-act="save"]')?.addEventListener("click",()=>void Be(a,n))}}}async function Be(a,t){const e=k,r=g(),d=[];e.orderNumber.trim()||d.push("Order number is required.");for(const i of r){const u=(e.customerData[i.id]||"").trim(),v=t.querySelector(`[data-fid="${i.id}"]`);i.required&&!u?(d.push(`${i.name} is required.`),v?.classList.add("invalid")):u&&i.type==="phone"&&!ge(u)?(d.push(`${i.name}: enter a valid phone number.`),v?.classList.add("invalid")):u&&i.type==="email"&&!we(u)?(d.push(`${i.name}: enter a valid email address.`),v?.classList.add("invalid")):u&&i.type==="number"&&Number.isNaN(Number(u))&&(d.push(`${i.name} must be a number.`),v?.classList.add("invalid"))}e.items.length===0&&d.push("Add at least one product.");for(const i of e.items)(!(i.qty>=1)||!Number.isInteger(i.qty))&&d.push(`Quantity for ${i.name} must be a whole number (at least 1).`),i.price>=0||d.push(`Price for ${i.name} is invalid.`);if(d.length>0){b(d[0],"err");return}const n=$e(e.orderNumber);if(n&&n.id!==e.id){T(`<h3>Order already exists.</h3>
       <p class="muted" style="margin:0"><b>${c(e.orderNumber)}</b> already exists on this device.</p>
       <div class="row" style="justify-content:flex-start">
         <button class="btn" data-open>Open Order</button>
         <button class="btn" data-edit>Edit Order</button>
         <button class="btn" data-x>Cancel</button>
       </div>`,(i,u)=>{i.querySelector("[data-open]").addEventListener("click",()=>{k=null,P=null,u(),a.go("label",n.id)}),i.querySelector("[data-edit]").addEventListener("click",()=>{k=null,P=null,u(),a.go("new",n.id)}),i.querySelector("[data-x]").addEventListener("click",u)});return}if(!e.id&&f().sheetId)try{if(await Te(e.orderNumber.trim())){T(`<h3>Order already exists.</h3>
           <p class="muted" style="margin:0"><b>${c(e.orderNumber)}</b> is already used in your spreadsheet.</p>
           <div class="row" style="justify-content:flex-start">
             <button class="btn primary" data-next>Use Next Number</button>
             <button class="btn" data-x>Cancel</button>
           </div>`,(i,u)=>{i.querySelector("[data-next]").addEventListener("click",async()=>{u(),await Z(),e.orderNumber=Y();const v=t.querySelector("[data-onum]");v&&(v.value=e.orderNumber);const $=t.querySelector(".ordnum");$&&($.textContent=e.orderNumber),b(`Switched to ${e.orderNumber}.`)}),i.querySelector("[data-x]").addEventListener("click",u)});return}}catch(i){b(G(i),"err");return}const s=new Date().toISOString(),l={id:e.id||K("o_"),orderNumber:e.orderNumber.trim(),customerData:{...e.customerData},items:e.items.map(i=>({...i})),paymentStatus:e.paymentStatus,total:e.items.reduce((i,u)=>i+u.price*u.qty,0),createdAt:e.createdAt||s,updatedAt:s,labelPrinted:e.labelPrinted||!1,sheetRow:e.sheetRow},o=!e.id;await X(l);let p="";if(f().sheetId)try{l.sheetRow=await Fe(l),await X(l)}catch(i){p=G(i)}o&&e.orderNumber===Y()&&await Z(),k=null,P=null,b(o?"Order saved successfully.":"Order updated successfully.","ok"),p&&b("Saved on this device. Google Sheets: "+p,"err"),a.go("orders")}function _e(a){const t=A();return{html:`<div class="page-head">
        <div><h2 class="page-title">Products</h2><div class="page-sub">Select these while creating an order</div></div>
        <div class="head-actions"><button class="btn primary" data-act="add">+ Add Product</button></div>
      </div>
      ${t.length===0?'<div class="card"><div class="empty">No products yet.<br><button class="btn primary" data-act="add">+ Add Product</button></div></div>':`<div class="tblwrap"><table class="tbl">
        <thead><tr><th>Name</th><th>SKU</th><th class="num">Price</th><th>Active</th><th></th></tr></thead>
        <tbody>${t.map(e=>`<tr>
          <td class="strong">${c(e.name)}</td>
          <td class="muted">${c(e.sku)}</td>
          <td class="num strong nowrap">${C(e.price)}</td>
          <td><label class="switch"><input type="checkbox" data-toggle="${e.id}" ${e.active?"checked":""}><i></i></label></td>
          <td><div class="rowbtns">
            <button class="btn small" data-edit="${e.id}">Edit</button>
            <button class="btn small ghost-danger" data-del="${e.id}">Delete</button>
          </div></td>
        </tr>`).join("")}</tbody></table></div>`}`,bind(e){e.querySelectorAll('[data-act="add"]').forEach(r=>r.addEventListener("click",()=>void se(null,a))),e.querySelectorAll("[data-toggle]").forEach(r=>r.addEventListener("change",async()=>{const d=r.dataset.toggle,n=r.checked;await M(A().map(s=>s.id===d?{...s,active:n}:s))})),e.querySelectorAll("[data-edit]").forEach(r=>r.addEventListener("click",()=>{const d=A().find(n=>n.id===r.dataset.edit);d&&se(d,a)})),e.querySelectorAll("[data-del]").forEach(r=>r.addEventListener("click",async()=>{const d=A().find(s=>s.id===r.dataset.del);!d||!await re("Delete product?",`<b>${c(d.name)}</b> will be removed from the product list. Existing orders are not affected.`,"Delete")||(await M(A().filter(s=>s.id!==d.id)),b("Product deleted."),a.rerender())}))}}}async function se(a,t){T(`<h3>${a?"Edit Product":"Add Product"}</h3>
     <div class="fgrid">
       <div class="field span2"><label class="f">Name <span class="req">*</span></label><input type="text" data-n value="${c(a?.name||"")}"></div>
       <div class="field"><label class="f">SKU</label><input type="text" data-s value="${c(a?.sku||"")}"></div>
       <div class="field"><label class="f">Price (₹)</label><input type="number" step="any" min="0" data-p value="${a?.price??0}"></div>
     </div>
     <label class="checkrow"><input type="checkbox" data-a ${a?.active??!0?"checked":""}> Active (selectable in orders)</label>
     <div class="row"><button class="btn" data-x>Cancel</button><button class="btn primary" data-save>Save</button></div>`,(e,r)=>{e.querySelector("[data-x]").addEventListener("click",r),e.querySelector("[data-save]").addEventListener("click",async()=>{const d=e.querySelector("[data-n]").value.trim(),n=e.querySelector("[data-s]").value.trim(),s=Math.max(0,Number(e.querySelector("[data-p]").value)||0),l=e.querySelector("[data-a]").checked;if(!d){e.querySelector("[data-n]").classList.add("invalid"),b("Product name is required.","err");return}const o=A();a?await M(o.map(p=>p.id===a.id?{...p,name:d,sku:n,price:s,active:l}:p)):await M([...o,{id:K("p_"),name:d,sku:n,price:s,active:l}]),r(),b("Product saved.","ok"),t.rerender()})})}function ze(a){const t=g();return{html:`<div class="page-head">
        <div><h2 class="page-title">Custom Fields</h2><div class="page-sub">Each field becomes a spreadsheet column — every order fills one row</div></div>
        <div class="head-actions"><button class="btn primary" data-act="add">+ Add Field</button></div>
      </div>
      <div class="card">
        ${t.length===0?'<div class="empty">No fields yet. Add fields like Customer Name, Phone, Address, City…<br><button class="btn primary" data-act="add">+ Add Field</button></div>':`<div>${t.map((e,r)=>`<div class="list-row">
              <span class="muted nowrap" style="font-size:11px">${r+1}.</span>
              <div class="grow"><span class="name">${c(e.name)}</span>${e.required?' <span class="req" style="color:var(--danger);font-weight:800">*</span>':""}</div>
              <span class="type-badge">${e.type}</span>
              <label class="switch" title="Required"><input type="checkbox" data-req="${e.id}" ${e.required?"checked":""}><i></i></label>
              <button class="btn small icon" data-up="${e.id}" ${r===0?"disabled":""} title="Move up">↑</button>
              <button class="btn small icon" data-down="${e.id}" ${r===t.length-1?"disabled":""} title="Move down">↓</button>
              <button class="btn small" data-edit="${e.id}">Edit</button>
              <button class="btn small ghost-danger" data-del="${e.id}">Delete</button>
            </div>`).join("")}</div>`}
        <div class="hint">Reorder with ↑ ↓ — the order here is the order in the order form and on the label.</div>
      </div>`,bind(e){e.querySelector('[data-act="add"]')?.addEventListener("click",()=>void ne(null,a)),e.querySelectorAll("[data-req]").forEach(d=>d.addEventListener("change",async()=>{const n=d.dataset.req,s=d.checked;await j(g().map(l=>l.id===n?{...l,required:s}:l))}));const r=async(d,n)=>{const s=g(),l=s.findIndex(p=>p.id===d),o=l+n;l<0||o<0||o>=s.length||([s[l],s[o]]=[s[o],s[l]],await j(s.map((p,i)=>({...p,order:i}))),a.rerender())};e.querySelectorAll("[data-up]").forEach(d=>d.addEventListener("click",()=>void r(d.dataset.up,-1))),e.querySelectorAll("[data-down]").forEach(d=>d.addEventListener("click",()=>void r(d.dataset.down,1))),e.querySelectorAll("[data-edit]").forEach(d=>d.addEventListener("click",()=>{const n=g().find(s=>s.id===d.dataset.edit);n&&ne(n,a)})),e.querySelectorAll("[data-del]").forEach(d=>d.addEventListener("click",async()=>{const n=g().find(o=>o.id===d.dataset.del);if(!n||!await re("Delete field?",`<b>${c(n.name)}</b> will be removed from the order form. Existing orders keep their data, and the spreadsheet column is never deleted.`,"Delete"))return;const l=g().filter(o=>o.id!==n.id);await j(l.map((o,p)=>({...o,order:p}))),b("Field deleted."),a.rerender()}))}}}async function ne(a,t){T(`<h3>${a?"Edit Field":"Add Field"}</h3>
     <div class="fgrid">
       <div class="field span2"><label class="f">Field name <span class="req">*</span></label><input type="text" data-n value="${c(a?.name||"")}" placeholder="e.g. Customer Name"></div>
       <div class="field"><label class="f">Type</label><select data-t>${Se.map(([e,r])=>`<option value="${e}" ${a?.type===e?"selected":""}>${r}</option>`).join("")}</select></div>
       <div class="field"><label class="f">Required</label><label class="checkrow" style="padding:6px 0 0"><input type="checkbox" data-r ${a?.required?"checked":""}> Must be filled</label></div>
       <div class="field span2" data-optwrap style="display:${a?.type==="dropdown"?"block":"none"}"><label class="f">Dropdown options <span class="muted">(one per line)</span></label><textarea rows="3" data-o>${c((a?.options||[]).join(`
`))}</textarea></div>
     </div>
     <div class="hint">Field names become spreadsheet column headers. Existing orders are never affected by changes here.</div>
     <div class="row"><button class="btn" data-x>Cancel</button><button class="btn primary" data-save>Save Field</button></div>`,(e,r)=>{const d=e.querySelector("[data-t]");d.addEventListener("change",()=>{e.querySelector("[data-optwrap]").style.display=d.value==="dropdown"?"block":"none"}),e.querySelector("[data-x]").addEventListener("click",r),e.querySelector("[data-save]").addEventListener("click",async()=>{const n=e.querySelector("[data-n]"),s=n.value.trim(),l=d.value,o=e.querySelector("[data-r]").checked,p=e.querySelector("[data-o]").value.split(`
`).map(v=>v.trim()).filter(Boolean);if(!s){n.classList.add("invalid"),b("Field name is required.","err");return}if(l==="dropdown"&&p.length===0){b("Add at least one dropdown option.","err");return}if(g().find(v=>v.name.trim().toLowerCase()===s.toLowerCase()&&v.id!==a?.id)){n.classList.add("invalid"),b("A field with this name already exists.","err");return}const u=g();a?await j(u.map(v=>v.id===a.id?{...v,name:s,type:l,required:o,options:l==="dropdown"?p:void 0}:v)):await j([...u,{id:K("f_"),name:s,type:l,required:o,options:l==="dropdown"?p:void 0,order:u.length}]),r(),b("Field saved.","ok"),t.rerender()})})}const O={signedIn:!1};function We(a){const t=f(),e=g(),r=F(),d=!!t.sheetId,n=i=>t.labelFields===null?!0:t.labelFields.includes(i),s=e.map(i=>`<label class="checkrow"><input type="checkbox" data-lf="${i.id}" ${n(i.id)?"checked":""}> ${c(i.name)}</label>`).join(""),o=[["orderNumber","Order Number"],["products","Products"],["quantity","Quantity"],["payment","Payment Status"],["amount","Amount"],["gst","Business GST"],["barcode","Barcode"]].map(([i,u])=>`<label class="checkrow"><input type="checkbox" data-ex="${i}" ${t.labelExtras[i]?"checked":""}> ${u}</label>`).join(""),p=d?`<div class="card-sub" style="margin-top:12px">Column mapping — fields reuse matching columns automatically. Map a field to a different existing column if needed.</div>
       ${e.length===0?'<div class="muted" style="font-size:12px">No custom fields to map.</div>':e.map(i=>{const u=t.customMap[i.id]||"";return`<div class="map-row"><div class="strong">${c(i.name)}</div><select data-map="${i.id}"><option value="">Auto${u?"":" (matched)"}</option>${r.map(v=>`<option value="${c(v)}" ${u===v?"selected":""}>${c(v)}</option>`).join("")}</select></div>`}).join("")}`:"";return{html:`<div class="page-head">
        <div><h2 class="page-title">Settings</h2><div class="page-sub">Changes are saved automatically</div></div>
      </div>

      <div class="card">
        <div class="card-title">Business</div>
        <div class="set-grid">
          <div class="field"><label class="f">Business Name</label><input type="text" data-k="businessName" value="${c(t.businessName)}"></div>
          <div class="field"><label class="f">Phone</label><input type="text" data-k="phone" value="${c(t.phone)}"></div>
          <div class="field"><label class="f">Website</label><input type="text" data-k="website" value="${c(t.website)}"></div>
          <div class="field"><label class="f">GST</label><input type="text" data-k="gst" value="${c(t.gst)}"></div>
          <div class="field span2"><label class="f">Address</label><textarea rows="2" data-k="address">${c(t.address)}</textarea></div>
          <div class="field span2"><label class="f">Label Footer</label><input type="text" data-k="footer" value="${c(t.footer)}" placeholder="Thank you for your order!"></div>
          <div class="field span2"><label class="f">Logo</label>
            <div class="logo-row">
              ${t.logo?`<img src="${t.logo}" alt="logo">`:""}
              <button class="btn small" data-act="logo">${t.logo?"Change Logo":"Upload Logo"}</button>
              ${t.logo?'<button class="btn small ghost-danger" data-act="logorm">Remove</button>':""}
              <input type="file" accept="image/*" data-logo hidden>
            </div>
            <div class="hint">Shown on the shipping label. PNG/JPG, up to ~300 KB.</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Google Sheets</div>
        <div class="toolbar" style="margin-bottom:8px">
          <span class="dot ${O.signedIn?"on":""}" data-gdot></span>
          <span class="count" data-gstatus>${d?`Spreadsheet connected: ${t.sheetName||"…"}`:O.signedIn?"Google account connected":"Not connected"}</span>
          <span class="spacer"></span>
          <button class="btn small" data-act="gdisconnect" ${O.signedIn||d?"":"disabled"}>Disconnect</button>
        </div>
        <div class="set-grid">
          <div class="field span2"><label class="f">Spreadsheet URL or ID</label><input type="text" data-sheetref value="${c(t.sheetId)}" placeholder="https://docs.google.com/spreadsheets/d/…"></div>
          <div class="field"><label class="f">Worksheet</label><select data-ws ${d?"":"disabled"}><option value="${c(t.sheetName)}">${c(t.sheetName||"—")}</option></select></div>
          <div class="field"><label class="f">&nbsp;</label><button class="btn" data-act="use" style="width:100%">${d?"Re-read Connection":"Connect Spreadsheet"}</button></div>
        </div>
        <div class="field" style="margin-top:4px"><label class="f">Google OAuth Client ID</label><input type="text" data-k="clientId" value="${c(t.clientId)}" placeholder="xxxxxxxx.apps.googleusercontent.com"></div>
        <details class="help">
          <summary>One-time setup: how to get a Client ID (free, ~2 minutes)</summary>
          <ol>
            <li>Open <b>console.cloud.google.com</b> → create/select a project.</li>
            <li><b>APIs &amp; Services → Library</b> → enable <b>Google Sheets API</b>.</li>
            <li><b>OAuth consent screen</b> → External → add yourself as a <b>test user</b>.</li>
            <li><b>Credentials → Create credentials → OAuth client ID</b> → type <b>Web application</b>.</li>
            <li>Add this <b>Authorized redirect URI</b>: <code>${c(chrome?.identity?.getRedirectURL?chrome.identity.getRedirectURL():"chrome-extension://EXTENSION_ID.chromiumapp.org/")}</code></li>
            <li>Copy the <b>Client ID</b> and paste it above, then click <b>Connect Spreadsheet</b>.</li>
          </ol>
        </details>
        ${p}
      </div>

      <div class="card">
        <div class="card-title">Orders</div>
        <div class="set-grid">
          <div class="field"><label class="f">Order Prefix</label><input type="text" data-k="orderPrefix" value="${c(t.orderPrefix)}"></div>
          <div class="field"><label class="f">Starting Number</label><input type="number" min="1" step="1" data-k="nextNumber" value="${t.nextNumber}"></div>
        </div>
        <div class="hint">New orders get <b>${c(t.orderPrefix)}${t.nextNumber}</b>. You can always type a manual order number.</div>
      </div>

      <div class="card">
        <div class="card-title">Label</div>
        <div class="set-grid">
          <div class="field"><label class="f">Label Size</label>
            <select data-k="labelSize">
              <option value="4x6" ${t.labelSize==="4x6"?"selected":""}>4 × 6 inch (default)</option>
              <option value="a6" ${t.labelSize==="a6"?"selected":""}>A6 (105 × 148 mm)</option>
            </select>
          </div>
        </div>
        <div class="card-sub" style="margin-top:12px">Customer fields shown on the label</div>
        ${e.length===0?'<div class="muted" style="font-size:12px">No custom fields yet.</div>':`<div style="columns:2;gap:24px">${s}</div>`}
        <div class="card-sub" style="margin-top:12px">Label sections</div>
        <div style="columns:2;gap:24px">${o}</div>
      </div>

      <div class="card">
        <div class="card-title">Backup</div>
        <div class="toolbar">
          <button class="btn" data-act="export">Export Orders</button>
          <button class="btn" data-act="import">Import Settings</button>
          <span class="count">Exports include orders, fields, products and settings as JSON.</span>
        </div>
        <input type="file" accept="application/json" data-importfile hidden>
      </div>`,async bind(i){const u=f();i.querySelectorAll("[data-k]").forEach(h=>{const m=h.dataset.k;h.addEventListener("change",async()=>{let w=h.value;m==="nextNumber"&&(w=Math.max(1,Math.floor(Number(w)||1))),await S({...f(),[m]:w}),b("Saved.")})});const v=i.querySelector("[data-logo]");i.querySelector('[data-act="logo"]')?.addEventListener("click",()=>v.click()),v?.addEventListener("change",()=>{const h=v.files?.[0];if(!h)return;if(h.size>400*1024){b("Logo is too large — please use an image under 400 KB.","err"),v.value="";return}const m=new FileReader;m.onload=async()=>{await S({...f(),logo:String(m.result)}),b("Logo saved.","ok"),a.rerender()},m.readAsDataURL(h)}),i.querySelector('[data-act="logorm"]')?.addEventListener("click",async()=>{await S({...f(),logo:""}),a.rerender()}),oe().then(h=>{O.signedIn=h;const m=i.querySelector("[data-gdot]"),y=i.querySelector("[data-gstatus]");m&&(m.className="dot "+(h?"on":"")),y&&!f().sheetId&&(y.textContent=h?"Google account connected":"Not connected")}).catch(()=>{}),i.querySelector('[data-act="use"]')?.addEventListener("click",()=>void He(a,i)),i.querySelector('[data-act="gdisconnect"]')?.addEventListener("click",()=>void Je(a));const $=i.querySelector("[data-ws]");$?.addEventListener("change",()=>void Ye(a,$.value)),i.querySelectorAll("[data-map]").forEach(h=>h.addEventListener("change",async()=>{const m=h.dataset.map,y=h.value,w={...f().customMap};y?w[m]=y:delete w[m],await S({...f(),customMap:w}),b("Column mapping saved.","ok")})),i.querySelectorAll("[data-lf]").forEach(h=>h.addEventListener("change",async()=>{const m=h.dataset.lf,y=h.checked,w=g().map(H=>H.id),V=(u.labelFields===null?[...w]:[...u.labelFields]).filter(H=>H!==m);y&&V.push(m),await S({...f(),labelFields:V})})),i.querySelectorAll("[data-ex]").forEach(h=>h.addEventListener("change",async()=>{const m=h.dataset.ex,y=h.checked,w={...f().labelExtras,[m]:y};await S({...f(),labelExtras:w})})),i.querySelector('[data-act="export"]')?.addEventListener("click",()=>{ke(),b("Backup exported.","ok")});const q=i.querySelector("[data-importfile]");i.querySelector('[data-act="import"]')?.addEventListener("click",()=>q.click()),q?.addEventListener("change",()=>{const h=q.files?.[0];h&&Ee(h).then(()=>{b("Settings imported.","ok"),a.rerender()}).catch(m=>b("Import failed: "+(m instanceof Error?m.message:"invalid file"),"err"))})}}}async function He(a,t){const e=f(),r=t.querySelector("[data-sheetref]"),d=r.value.trim();if(!e.clientId.trim()){b("Add your Google OAuth Client ID first (see the steps below the field).","err");return}if(!d){r.classList.add("invalid"),b("Paste your Google Sheets link or spreadsheet ID.","err");return}const n=Ue(d);try{await S({...f(),clientId:e.clientId.trim()}),await Ce();const s=await Ie(n);if(s.sheets.length===0)throw new Error("This spreadsheet has no worksheets.");const l=s.sheets[0],o=await Q(n,l);await S({...f(),sheetId:n,sheetName:l}),W(o),O.signedIn=!0,b(`Connected. ${o.length} columns ready (${ue.length} standard + your fields).`,"ok"),a.rerender()}catch(s){b(G(s),"err")}}async function Ye(a,t){const e=f();if(!(!e.sheetId||!t))try{const r=await Q(e.sheetId,t);await S({...f(),sheetName:t}),W(r),b(`Worksheet switched to "${t}".`,"ok"),a.rerender()}catch(r){b(G(r),"err")}}async function Je(a){try{await Ae()}catch{}await S({...f(),sheetId:"",sheetName:""}),W([]),O.signedIn=!1,b("Disconnected from Google Sheets."),a.rerender()}const x=document.getElementById("app"),Ke=[["dashboard","Dashboard",L.dash],["new","New Order",L.plus],["orders","Orders",L.list],["products","Products",L.box],["fields","Custom Fields",L.sliders],["settings","Settings",L.gear]];let I="dashboard",E=null;const _={get route(){return I},get id(){return E},go(a,t=null){I=a,E=t??null;const e=a==="new"?E?`#edit=${E}`:"#new":a==="label"&&E?`#label=${E}`:"";try{history.replaceState(null,"",e||location.pathname)}catch{}z()},rerender(){z()}},Qe={dashboard:Re,new:Me,orders:a=>Ne(a,!1),products:_e,fields:ze,settings:We};function Ve(){if(I==="label"){const a=E?de(E):void 0;if(a)return Le(a,()=>_.go("orders"),()=>z());I="orders",E=null}return Qe[I](_)}function z(){const a=Ve();x.innerHTML=`
    <header class="top">
      <div class="brand">${L.tag} Order Label Manager</div>
      <div class="spacer"></div>
      <button class="conn" data-conn title="Google Sheets connection status — click to open Settings"><span class="dot" data-gdot></span><span data-gtxt>Google</span></button>
      <button class="btn small" data-opentab title="Open all orders in a full browser tab">Orders ${L.external}</button>
    </header>
    <nav class="tabs">${Ke.map(([e,r,d])=>`<button data-route="${e}" class="${I===e?"active":""}">${d} ${r}</button>`).join("")}</nav>
    <main class="content"></main>`;const t=x.querySelector("main.content");t.innerHTML=a.html,x.querySelectorAll("[data-route]").forEach(e=>e.addEventListener("click",()=>_.go(e.dataset.route))),x.querySelector("[data-opentab]")?.addEventListener("click",()=>window.open(chrome.runtime.getURL("orders.html"))),x.querySelector("[data-conn]")?.addEventListener("click",()=>_.go("settings")),oe().then(e=>{const r=x.querySelector("[data-gdot]"),d=x.querySelector("[data-gtxt]");r&&(r.className="dot "+(e?"on":"")),d&&(d.textContent=e?"Google connected":"Google")}).catch(()=>{}),a.bind?.(t)}function Ze(){const a=location.hash.replace(/^#/,""),[t,e]=a.split("=");return t==="edit"&&e?{route:"new",id:e}:t==="label"&&e?{route:"label",id:e}:t==="new"?{route:"new",id:null}:{route:"dashboard",id:null}}function Xe(){return new Promise(a=>{try{chrome.windows.getCurrent(t=>a(t.type==="normal"))}catch{a(!1)}})}async function et(){await qe();const a=Ze();I=a.route,E=a.id,document.documentElement.classList.toggle("as-page",await Xe()),z()}et();
