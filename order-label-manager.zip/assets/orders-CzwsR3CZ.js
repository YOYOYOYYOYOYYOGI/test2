import{K as i,g as s,M as o,N as d,L as c}from"./label-view-CbfgsESy.js";const l=document.getElementById("app");let n=null;const u={route:"orders",id:null,go(e,t=null){e==="label"&&(n=t??null,a())},rerender(){a()}};function a(){let e=null;if(n){const r=s(n);r?e=o(r,()=>{n=null,a()},a):n=null}e||(e=d(u,!0)),l.innerHTML=`
    <header class="top">
      <div class="brand">${c.tag} Order Label Manager — Orders</div>
      <div class="spacer"></div>
      <button class="btn small primary" data-new>+ New Order</button>
    </header>
    <main class="content"></main>`;const t=l.querySelector("main.content");t.innerHTML=e.html,l.querySelector("[data-new]")?.addEventListener("click",()=>window.open(chrome.runtime.getURL("index.html")+"#new")),e.bind?.(t)}async function m(){await i();const e=location.hash.replace(/^#/,"");e.startsWith("label=")&&(n=e.split("=")[1]||null),a()}m();
