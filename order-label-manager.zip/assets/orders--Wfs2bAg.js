import{B as i,h as s,C as o,D as d,I as c}from"./label-view-B8U55yxF.js";const l=document.getElementById("app");let n=null;const u={route:"orders",id:null,go(e,a=null){e==="label"&&(n=a??null,t())},rerender(){t()}};function t(){let e=null;if(n){const r=s(n);r?e=o(r,()=>{n=null,t()},t):n=null}e||(e=d(u,!0)),l.innerHTML=`
    <header class="top">
      <div class="brand">${c.tag} Order Label Manager — Orders</div>
      <div class="spacer"></div>
      <button class="btn small primary" data-new>+ New Order</button>
    </header>
    <main class="content"></main>`;const a=l.querySelector("main.content");a.innerHTML=e.html,l.querySelector("[data-new]")?.addEventListener("click",()=>window.open(chrome.runtime.getURL("index.html")+"#new")),e.bind?.(a)}async function m(){await i();const e=location.hash.replace(/^#/,"");e.startsWith("label=")&&(n=e.split("=")[1]||null),t()}m();
