(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))i(s);new MutationObserver(s=>{for(const n of s)if(n.type==="childList")for(const r of n.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&i(r)}).observe(document,{childList:!0,subtree:!0});function a(s){const n={};return s.integrity&&(n.integrity=s.integrity),s.referrerPolicy&&(n.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?n.credentials="include":s.crossOrigin==="anonymous"?n.credentials="omit":n.credentials="same-origin",n}function i(s){if(s.ep)return;s.ep=!0;const n=a(s);fetch(s.href,n)}})();const Te={businessName:"My Business",logo:"",phone:"",address:"",website:"",gst:"",footer:"",orderPrefix:"ORD-",nextNumber:1001,labelSize:"4x6",labelFields:[],labelExtras:{orderNumber:!0,products:!0,quantity:!0,payment:!0,amount:!0,gst:!1,barcode:!0},clientId:"",sheetId:"",sheetName:"",customMap:{}},Fe=[["text","Text"],["number","Number"],["phone","Phone"],["email","Email"],["textarea","Textarea"],["date","Date"],["dropdown","Dropdown"],["checkbox","Checkbox"]],Ue=["Paid","COD","Pending","Failed"],ze="https://www.googleapis.com/auth/spreadsheets";let Be=0;const oe=(e="")=>e+Date.now().toString(36)+(Be++).toString(36)+Math.random().toString(36).slice(2,8),C=e=>"₹"+e.toLocaleString("en-IN"),Ge=()=>{const e=new Date;return e.getFullYear()+"-"+String(e.getMonth()+1).padStart(2,"0")+"-"+String(e.getDate()).padStart(2,"0")},_e=e=>e?e.slice(0,10):"",Ve=e=>/^[+\d][\d\s-]{5,19}$/.test(e.trim()),He=e=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e.trim()),u=e=>e.replace(/[&<>"']/g,t=>`&#${t.charCodeAt(0)};`),K=new Map;let ee=null;const we=typeof chrome<"u"&&!!chrome.storage?.local;function Ye(e){return we?(ee||(ee=new Promise(t=>chrome.storage.local.get(null,a=>{for(const[i,s]of Object.entries(a||{}))K.set(i,s);t()}))),ee):Promise.resolve()}function j(e,t){return K.has(e)?K.get(e):t}async function T(e,t){K.set(e,t),we&&await chrome.storage.local.set({[e]:t})}async function Ke(e,t,a){const i=t(j(e,a));return await T(e,i),i}const L={fields:"fields",products:"products",orders:"orders",settings:"settings",headers:"sheetHeaders"},$=()=>j(L.fields,[]).slice().sort((e,t)=>e.order-t.order),P=()=>j(L.products,[]),z=()=>j(L.orders,[]),y=()=>({...Te,...j(L.settings,{})}),Y=()=>j(L.headers,[]),M=e=>T(L.fields,e),B=e=>T(L.products,e),S=e=>T(L.settings,e),Z=e=>T(L.headers,e);async function ae(e){await Ke(L.orders,t=>{const a=t.findIndex(i=>i.id===e.id);return a>=0?t[a]=e:t.unshift(e),t},[])}function $e(e){return z().find(t=>t.id===e)}function Je(e){const t=e.trim().toLowerCase();return z().find(a=>a.orderNumber.trim().toLowerCase()===t)}function ne(){const e=y();return e.orderPrefix+e.nextNumber}async function pe(){const e=y();e.nextNumber=Math.max(e.nextNumber+1,1),await S(e)}function se(e){const t=$().find(a=>/name/i.test(a.name));return t&&e.customerData[t.id]||""}function me(e){const t=$().find(a=>a.type==="phone"||/phone|mobile|whatsapp/i.test(a.name));return t&&e.customerData[t.id]||""}async function Qe(){await Ye(),!j("seeded",!1)&&(await T("seeded",!0),$().length===0&&await M([{id:"f_name",name:"Customer Name",type:"text",required:!0,order:0},{id:"f_phone",name:"Phone",type:"phone",required:!0,order:1},{id:"f_address",name:"Address",type:"textarea",required:!1,order:2},{id:"f_city",name:"City",type:"text",required:!1,order:3},{id:"f_state",name:"State",type:"text",required:!1,order:4},{id:"f_pincode",name:"Pincode",type:"number",required:!1,order:5}]),P().length===0&&await B([{id:"p_night",name:"Night Cream",sku:"NC-01",price:499,active:!0},{id:"p_serum",name:"Face Serum",sku:"FS-02",price:699,active:!0},{id:"p_day",name:"Day Cream",sku:"DC-03",price:599,active:!0}]))}function Xe(){const e={exportedAt:new Date().toISOString(),fields:$(),products:P(),orders:z(),settings:y()},t=URL.createObjectURL(new Blob([JSON.stringify(e,null,2)],{type:"application/json"})),a=document.createElement("a");a.href=t,a.download="order-label-manager-backup.json",a.click(),setTimeout(()=>URL.revokeObjectURL(t),5e3)}function Ze(e){return e.text().then(async t=>{const a=JSON.parse(t);Array.isArray(a.fields)&&await M(a.fields),Array.isArray(a.products)&&await B(a.products),Array.isArray(a.orders)&&await T(L.orders,a.orders),a.settings&&await S({...y(),...a.settings})})}const xe=typeof chrome<"u"&&!!chrome.identity?.launchWebAuthFlow;let O=null;const et=()=>xe&&!!y().clientId;function Se(){return et()?J(!1).then(()=>!0).catch(()=>!1):Promise.resolve(!1)}async function tt(){if(!xe)throw new Error("Chrome identity API is not available.");await J(!0)}async function at(){O&&fetch("https://oauth2.googleapis.com/revoke?token="+encodeURIComponent(O.token)).catch(()=>{}),O=null}function he(e,t){return"https://accounts.google.com/o/oauth2/v2/auth?"+new URLSearchParams({client_id:e,response_type:"token",redirect_uri:chrome.identity.getRedirectURL(),scope:ze,prompt:t}).toString()}function be(e,t){return new Promise((a,i)=>{chrome.identity.launchWebAuthFlow({url:e,interactive:!0},s=>{const n=chrome.runtime.lastError,r=o=>i(new Error(t?"silent-fail":o));if(n||!s)return r("Google sign-in failed or was cancelled.");try{const o=new URLSearchParams(new URL(s).hash.replace(/^#/,"")),d=o.get("access_token"),l=Number(o.get("expires_in")||"3600");if(!d)return r("Google sign-in failed.");O={token:d,exp:Date.now()+Math.max(60,l-120)*1e3},a(d)}catch{r("Google sign-in failed.")}})})}async function J(e){if(O&&O.exp>Date.now())return O.token;const t=y().clientId;if(!t)throw new Error("Google Sheets is not set up yet. Add your OAuth Client ID in Settings.");try{return await be(he(t,"none"),!0)}catch{if(!e)throw new Error("Not signed in to Google.");return be(he(t,"select_account"),!1)}}async function G(e,t){let a="";try{a=(await e.json())?.error?.message||""}catch{}return e.status===401||e.status===403?new Error(`Google access was rejected while ${t}. Try reconnecting your account in Settings.`):e.status===404?new Error(`Spreadsheet or worksheet not found while ${t}. Check the connection in Settings.`):e.status>=500?new Error(`Google Sheets is temporarily unavailable while ${t}. Please try again.`):new Error(a||`Google Sheets request failed while ${t} (error ${e.status}).`)}async function _(e,t,a=!0){let i;try{i=await J(a)}catch(n){throw new Error(n instanceof Error&&n.message!=="silent-fail"?n.message:"Not signed in to Google. Connect your account in Settings.")}let s=await fetch(e,{...t,headers:{...t?.headers||{},Authorization:"Bearer "+i}});return s.status===401&&(O=null,i=await J(a),s=await fetch(e,{...t,headers:{...t?.headers||{},Authorization:"Bearer "+i}})),s}async function nt(e){let t;try{t=await _(`https://sheets.googleapis.com/v4/spreadsheets/${e}?fields=sheets.properties.title`)}catch{throw new Error("Network problem while opening the spreadsheet. Check your internet connection.")}if(!t.ok)throw await G(t,"opening the spreadsheet");return{sheets:((await t.json()).sheets||[]).map(i=>i.properties.title)}}async function ke(e,t){const a=await _(`https://sheets.googleapis.com/v4/spreadsheets/${e}/values/${encodeURIComponent(t)}!1:1`);if(!a.ok)throw await G(a,"reading headers");return((await a.json()).values?.[0]||[]).map(s=>String(s).trim())}async function st(e,t,a,i){const s=a.map(r=>r.trim().toLowerCase()),n=i.filter(r=>!s.includes(r.trim().toLowerCase()));if(n.length>0){const r=`${t}!${re(a.length)}1:${re(a.length+n.length-1)}1`,o=await _(`https://sheets.googleapis.com/v4/spreadsheets/${e}/values/${encodeURIComponent(r)}?valueInputOption=RAW`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({values:[n]})});if(!o.ok)throw await G(o,"creating columns")}return[...a,...n]}async function Le(e,t,a,i){const s=await _(`https://sheets.googleapis.com/v4/spreadsheets/${e}/values/${encodeURIComponent(t)}!${a}:${a}`);if(!s.ok)throw await G(s,"looking up the order number");const r=(await s.json()).values||[],o=i.trim().toLowerCase();for(let d=0;d<r.length;d++)if(String(r[d][0]||"").trim().toLowerCase()===o)return{row:d+1,last:r.length};return{row:0,last:r.length}}async function rt(e,t,a,i){if(a>0){const o=`${t}!A${a}:${re(i.length-1)}${a}`,d=await _(`https://sheets.googleapis.com/v4/spreadsheets/${e}/values/${encodeURIComponent(o)}?valueInputOption=USER_ENTERED`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({values:[i]})});if(!d.ok)throw await G(d,"updating the order row");return a}const s=await _(`https://sheets.googleapis.com/v4/spreadsheets/${e}/values/${encodeURIComponent(t+"!A:A")}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({values:[i]})});if(!s.ok)throw await G(s,"adding the order row");const n=await s.json(),r=/![A-Z]+(\d+)/.exec(String(n.updates?.updatedRange||""));return r?Number(r[1]):0}function re(e){let t="",a=e+1;for(;a>0;){const i=(a-1)%26;t=String.fromCharCode(65+i)+t,a=Math.floor((a-1)/26)}return t}const N=e=>`<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${e}</svg>`,k={tag:'<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.41 11.58l-9-9A2 2 0 0 0 11 2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 .59 1.42l9 9a2 2 0 0 0 2.82 0l7-7a2 2 0 0 0 0-2.84zM7.5 9.5A1.75 1.75 0 1 1 9.25 7.75 1.75 1.75 0 0 1 7.5 9.5z"/></svg>',dash:N('<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>'),plus:N('<path d="M12 5v14M5 12h14"/>'),list:N('<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>'),box:N('<path d="M21 8l-9-5-9 5v8l9 5 9-5V8z"/><path d="M3 8l9 5 9-5M12 13v8"/>'),sliders:N('<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>'),gear:N('<circle cx="12" cy="12" r="3.2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1"/>'),print:N('<path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8" rx="1"/>'),download:N('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>'),edit:N('<path d="M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/>'),external:N('<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"/>')};function it(e){const t=z(),a=Ge(),i=r=>t.filter(r).length,s=[["Today's Orders",i(r=>r.createdAt.slice(0,10)===a)],["Pending Labels",i(r=>!r.labelPrinted)],["Paid Orders",i(r=>r.paymentStatus==="Paid")],["COD Orders",i(r=>r.paymentStatus==="COD")]],n=t.slice(0,5);return{html:`<div class="page-head">
        <div><h2 class="page-title">Dashboard</h2><div class="page-sub">Overview of your orders</div></div>
        <div class="head-actions">
          <button class="btn primary" data-act="new">+ New Order</button>
          <button class="btn" data-act="orders">Orders</button>
          <button class="btn" data-act="settings">Settings</button>
        </div>
      </div>
      <div class="stats">${s.map(([r,o])=>`<div class="stat"><div class="v">${o}</div><div class="l">${r}</div></div>`).join("")}</div>
      <div class="card">
        <div class="card-title">Recent Orders</div>
        ${n.length===0?'<div class="empty">No orders yet.<br><button class="btn primary" data-act="new">+ New Order</button></div>':`<div class="tblwrap" style="border:0"><table class="tbl"><thead><tr><th>Order</th><th>Customer</th><th class="num">Amount</th><th>Payment</th><th></th></tr></thead><tbody>${n.map(r=>`<tr>
                    <td class="strong nowrap">${u(r.orderNumber)}</td>
                    <td class="ellip">${u(se(r))}</td>
                    <td class="num strong nowrap">${C(r.total)}</td>
                    <td><span class="badge ${r.paymentStatus}">${r.paymentStatus}</span></td>
                    <td class="num"><button class="btn small" data-label="${r.id}">Label</button></td>
                  </tr>`).join("")}</tbody></table></div>`}
      </div>`,bind(r){r.querySelector('[data-act="new"]')?.addEventListener("click",()=>e.go("new")),r.querySelector('[data-act="orders"]')?.addEventListener("click",()=>e.go("orders")),r.querySelector('[data-act="settings"]')?.addEventListener("click",()=>e.go("settings")),r.querySelectorAll("[data-label]").forEach(o=>o.addEventListener("click",()=>e.go("label",o.dataset.label)))}}}const Ee=["Order Number","Order Date","Payment Status","Amount"];function Ne(e,t){const i=t.map(s=>s.trim().toLowerCase()).indexOf(e.trim().toLowerCase());return i>=0?t[i]:""}function ot(e,t,a,i){return i[e]||Ne(t,a)}function We(e){return Ne("Order Number",e)}async function de(e,t){const a=y();let i=Y();i.length===0&&(i=await ke(e,t));const s=i.map(o=>o.trim().toLowerCase()),n=[];for(const o of Ee)s.includes(o.toLowerCase())||n.push(o);for(const o of $())a.customMap?.[o.id]||s.includes(o.name.trim().toLowerCase())||n.push(o.name);const r=n.length>0?await st(e,t,i,n):i;return(r!==i||Y().length===0)&&Z(r),r}function dt(e,t,a={}){const i=t.map(r=>r.trim().toLowerCase()),s=new Array(t.length).fill(""),n=(r,o)=>{if(!r)return;const d=i.indexOf(r.trim().toLowerCase());d>=0&&(s[d]=o)};n("Order Number",e.orderNumber),n("Order Date",e.createdAt.slice(0,10)),n("Payment Status",e.paymentStatus),n("Amount",String(e.total)),n("Products",e.items.map(r=>r.qty>1?`${r.name} x ${r.qty}`:r.name).join(", ")),n("Quantity",String(e.items.reduce((r,o)=>r+o.qty,0))),n("SKU",e.items.map(r=>r.sku).filter(Boolean).join(", "));for(const r of $())n(ot(r.id,r.name,t,a),e.customerData[r.id]||"");return s}async function lt(e){const t=y();if(!t.sheetId||!t.sheetName)return 0;const a=await de(t.sheetId,t.sheetName),i=t.customMap||{};let s=e.sheetRow||0;if(s===0){const o=We(a);o&&(s=(await Le(t.sheetId,t.sheetName,o,e.orderNumber)).row)}const n=dt(e,a,i),r=await rt(t.sheetId,t.sheetName,s,n);return e.sheetRow=r||s,e.sheetRow}async function ct(e){const t=y();if(!t.sheetId||!t.sheetName)return!1;const a=Y().length>0?Y():await ke(t.sheetId,t.sheetName),i=We(a);return i?(await Le(t.sheetId,t.sheetName,i,e)).row>0:!1}function ut(e){const t=e.trim();if(!t)return"";const a=/docs\.google\.com\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/.exec(t);return a?a[1]:t}const D=e=>e instanceof Error?e.message:String(e);function v(e,t=""){let a=document.getElementById("toasts");a||(a=document.createElement("div"),a.id="toasts",document.body.appendChild(a));const i=document.createElement("div");i.className="toast "+t,i.textContent=e,a.appendChild(i),setTimeout(()=>{i.style.transition="opacity .25s",i.style.opacity="0",setTimeout(()=>i.remove(),260)},t==="err"?5200:2600)}function V(e,t){const a=document.createElement("div");a.className="modal-wrap",a.innerHTML=`<div class="modal">${e}</div>`;const i=()=>a.remove();a.addEventListener("mousedown",n=>{n.target===a&&i()}),document.body.appendChild(a);const s=a.querySelector(".modal");return t?.(s,i),{close:i,el:s}}function qe(e,t,a,i=!0){return new Promise(s=>{V(`<h3>${e}</h3><p class="muted" style="margin:0 0 4px">${t}</p>
       <div class="row"><button class="btn" data-x>Cancel</button><button class="btn ${i?"danger":"primary"}" data-ok>${a}</button></div>`,(n,r)=>{n.querySelector("[data-x]").addEventListener("click",()=>{r(),s(!1)}),n.querySelector("[data-ok]").addEventListener("click",()=>{r(),s(!0)})})})}let W=null,U=null;function fe(){return{id:null,orderNumber:ne(),customerData:{},items:[],paymentStatus:"COD"}}function pt(e,t){const a=e.required?' <span class="req">*</span>':"",i=u(e.id);switch(e.type){case"textarea":return`<div class="field span2"><label class="f">${u(e.name)}${a}</label><textarea rows="2" data-fid="${i}">${u(t)}</textarea></div>`;case"dropdown":{const s=(e.options||[]).map(n=>`<option ${n===t?"selected":""}>${u(n)}</option>`).join("");return`<div class="field"><label class="f">${u(e.name)}${a}</label><select data-fid="${i}"><option value=""></option>${s}</select></div>`}case"checkbox":return`<div class="field"><label class="f">${u(e.name)}${a}</label><label class="checkrow" style="padding:6px 0 0"><input type="checkbox" data-fid="${i}" ${t==="Yes"?"checked":""}> Yes</label></div>`;default:{const s=e.type==="number"?"number":e.type==="phone"?"tel":e.type==="email"?"email":e.type==="date"?"date":"text";return`<div class="field"><label class="f">${u(e.name)}${a}</label><input type="${s}" data-fid="${i}" value="${u(t)}"${e.type==="number"?' step="any"':""}></div>`}}}function mt(e){if(!W||U!==e.id){if(e.id){const n=$e(e.id);W=n?{id:n.id,orderNumber:n.orderNumber,customerData:{...n.customerData},items:n.items.map(r=>({...r})),paymentStatus:n.paymentStatus,sheetRow:n.sheetRow,createdAt:n.createdAt,labelPrinted:n.labelPrinted}:fe()}else W=fe();U=e.id}const t=W,a=$(),i=t.items.reduce((n,r)=>n+r.price*r.qty,0),s=t.items.map((n,r)=>`<tr>
        <td><div class="strong">${u(n.name)}</div>${n.sku?`<div class="muted" style="font-size:11px">${u(n.sku)}</div>`:""}</td>
        <td class="num"><input class="price-input" type="number" step="any" min="0" data-price="${r}" value="${n.price}"></td>
        <td class="num"><input class="qty-input" type="number" min="1" step="1" data-qty="${r}" value="${n.qty}"></td>
        <td class="num strong" data-line="${r}">${C(n.price*n.qty)}</td>
        <td class="num"><button class="btn small ghost-danger" data-rm="${r}" title="Remove">✕</button></td>
      </tr>`).join("");return{html:`<div class="page-head">
        <div>
          <h2 class="page-title">${t.id?"Edit Order":"New Order"}</h2>
          <div class="page-sub">Order <span class="ordnum">${u(t.orderNumber)}</span>${t.sheetRow?` · updates spreadsheet row ${t.sheetRow}`:""}</div>
        </div>
        <div class="head-actions"><div><label class="f">Order Number</label><input type="text" class="mini-input" data-onum value="${u(t.orderNumber)}" title="You can set a manual order number"></div></div>
      </div>
      <div class="card">
        <div class="card-title">Customer Details</div>
        ${a.length===0?'<div class="muted">No custom fields yet — create them in <b>Custom Fields</b>. They become your spreadsheet columns.</div>':`<div class="fgrid">${a.map(n=>pt(n,t.customerData[n.id]||"")).join("")}</div>`}
      </div>
      <div class="card">
        <div class="card-title">Products</div>
        ${t.items.length===0?'<div class="muted" style="margin-bottom:10px">No products added yet.</div>':`<div class="tblwrap" style="border:0;margin-bottom:10px"><table class="tbl items-tbl"><thead><tr><th>Product</th><th class="num">Price (₹)</th><th class="num">Qty</th><th class="num">Total</th><th></th></tr></thead><tbody>${s}</tbody></table></div>`}
        <button class="btn" data-act="addprod">+ Add Product</button>
      </div>
      <div class="card">
        <div class="savebar">
          <div class="paywrap">Payment
            <select data-pay style="width:150px">${Ue.map(n=>`<option ${n===t.paymentStatus?"selected":""}>${n}</option>`).join("")}</select>
          </div>
          <div class="spacer"></div>
          <div class="totline">Total&nbsp; <b data-total>${C(i)}</b></div>
        </div>
      </div>
      <div class="form-foot">
        <button class="btn" data-act="cancel">Cancel</button>
        <button class="btn primary" data-act="save">${t.id?"Update Order":"Save Order"}</button>
      </div>`,bind(n){const r=W;n.querySelectorAll("[data-fid]").forEach(d=>{const l=d.dataset.fid,c=d.tagName==="SELECT"||d.type==="checkbox"?"change":"input";d.addEventListener(c,()=>{const p=d;r.customerData[l]=p.type==="checkbox"?p.checked?"Yes":"":p.value,p.classList.remove("invalid")})}),n.querySelector("[data-onum]")?.addEventListener("input",d=>{r.orderNumber=d.target.value,n.querySelector(".ordnum").textContent=r.orderNumber}),n.querySelector("[data-pay]")?.addEventListener("change",d=>{r.paymentStatus=d.target.value});const o=d=>{const l=r.items[d],c=n.querySelector(`[data-line="${d}"]`);c&&(c.textContent=C(l.price*l.qty));const p=n.querySelector("[data-total]");p&&(p.textContent=C(r.items.reduce((h,w)=>h+w.price*w.qty,0)))};n.querySelectorAll("[data-qty]").forEach(d=>d.addEventListener("input",()=>{const l=Number(d.dataset.qty);r.items[l].qty=Math.max(1,Math.floor(Number(d.value)||1)),o(l)})),n.querySelectorAll("[data-price]").forEach(d=>d.addEventListener("input",()=>{const l=Number(d.dataset.price);r.items[l].price=Math.max(0,Number(d.value)||0),o(l)})),n.querySelectorAll("[data-rm]").forEach(d=>d.addEventListener("click",()=>{r.items.splice(Number(d.dataset.rm),1),e.rerender()})),n.querySelector('[data-act="addprod"]')?.addEventListener("click",()=>{const d=P().filter(l=>l.active);if(d.length===0){v("No active products. Add some in the Products page first.","err");return}V(`<h3>Add Product</h3>
           <input type="text" placeholder="Search products…" data-search style="margin-bottom:8px">
           <div class="plist" data-list></div>
           <div class="row"><button class="btn" data-close>Close</button></div>`,(l,c)=>{const p=l.querySelector("[data-list]"),h=l.querySelector("[data-search]"),w=()=>{const m=h.value.trim().toLowerCase(),g=d.filter(f=>!m||f.name.toLowerCase().includes(m)||f.sku.toLowerCase().includes(m));p.innerHTML=g.length===0?'<div class="muted" style="padding:10px">No products found.</div>':g.map(f=>{const x=r.items.some(A=>A.productId===f.id);return`<button data-pid="${f.id}" ${x?"disabled":""}><span class="strong">${u(f.name)}</span><span class="muted">${u(f.sku)}</span><span class="p-price">${C(f.price)}</span></button>`}).join("")};w(),h.addEventListener("input",w),h.focus(),p.addEventListener("click",m=>{const g=m.target.closest("[data-pid]");if(!g||g.hasAttribute("disabled"))return;const f=d.find(x=>x.id===g.dataset.pid);r.items.push({productId:f.id,name:f.name,sku:f.sku,price:f.price,qty:1}),c(),e.rerender()}),l.querySelector("[data-close]").addEventListener("click",c)})}),n.querySelector('[data-act="cancel"]')?.addEventListener("click",()=>{W=null,U=null,e.go("orders")}),n.querySelector('[data-act="save"]')?.addEventListener("click",()=>void ht(e,n))}}}async function ht(e,t){const a=W,i=$(),s=[];a.orderNumber.trim()||s.push("Order number is required.");for(const c of i){const p=(a.customerData[c.id]||"").trim(),h=t.querySelector(`[data-fid="${c.id}"]`);c.required&&!p?(s.push(`${c.name} is required.`),h?.classList.add("invalid")):p&&c.type==="phone"&&!Ve(p)?(s.push(`${c.name}: enter a valid phone number.`),h?.classList.add("invalid")):p&&c.type==="email"&&!He(p)?(s.push(`${c.name}: enter a valid email address.`),h?.classList.add("invalid")):p&&c.type==="number"&&Number.isNaN(Number(p))&&(s.push(`${c.name} must be a number.`),h?.classList.add("invalid"))}a.items.length===0&&s.push("Add at least one product.");for(const c of a.items)(!(c.qty>=1)||!Number.isInteger(c.qty))&&s.push(`Quantity for ${c.name} must be a whole number (at least 1).`),c.price>=0||s.push(`Price for ${c.name} is invalid.`);if(s.length>0){v(s[0],"err");return}const n=Je(a.orderNumber);if(n&&n.id!==a.id){V(`<h3>Order already exists.</h3>
       <p class="muted" style="margin:0"><b>${u(a.orderNumber)}</b> already exists on this device.</p>
       <div class="row" style="justify-content:flex-start">
         <button class="btn" data-open>Open Order</button>
         <button class="btn" data-edit>Edit Order</button>
         <button class="btn" data-x>Cancel</button>
       </div>`,(c,p)=>{c.querySelector("[data-open]").addEventListener("click",()=>{W=null,U=null,p(),e.go("label",n.id)}),c.querySelector("[data-edit]").addEventListener("click",()=>{W=null,U=null,p(),e.go("new",n.id)}),c.querySelector("[data-x]").addEventListener("click",p)});return}if(!a.id&&y().sheetId)try{if(await ct(a.orderNumber.trim())){V(`<h3>Order already exists.</h3>
           <p class="muted" style="margin:0"><b>${u(a.orderNumber)}</b> is already used in your spreadsheet.</p>
           <div class="row" style="justify-content:flex-start">
             <button class="btn primary" data-next>Use Next Number</button>
             <button class="btn" data-x>Cancel</button>
           </div>`,(c,p)=>{c.querySelector("[data-next]").addEventListener("click",async()=>{p(),await pe(),a.orderNumber=ne();const h=t.querySelector("[data-onum]");h&&(h.value=a.orderNumber);const w=t.querySelector(".ordnum");w&&(w.textContent=a.orderNumber),v(`Switched to ${a.orderNumber}.`)}),c.querySelector("[data-x]").addEventListener("click",p)});return}}catch(c){v(D(c),"err");return}const r=new Date().toISOString(),o={id:a.id||oe("o_"),orderNumber:a.orderNumber.trim(),customerData:{...a.customerData},items:a.items.map(c=>({...c})),paymentStatus:a.paymentStatus,total:a.items.reduce((c,p)=>c+p.price*p.qty,0),createdAt:a.createdAt||r,updatedAt:r,labelPrinted:a.labelPrinted||!1,sheetRow:a.sheetRow},d=!a.id;await ae(o);let l="";if(y().sheetId)try{o.sheetRow=await lt(o),await ae(o)}catch(c){l=D(c)}d&&a.orderNumber===ne()&&await pe(),W=null,U=null,v(d?"Order saved successfully.":"Order updated successfully.","ok"),l&&v("Saved on this device. Google Sheets: "+l,"err"),e.go("orders")}const bt={0:"nnnWnWnnW",1:"WnnWnnnnW",2:"nnWWnnnnW",3:"WnWWnnnnn",4:"nnnWWnnnW",5:"WnnWWnnnn",6:"nnWWWnnnn",7:"nnnWnnWWn",8:"WnnWnnWnn",9:"nnWWnnWnn",A:"WnnnnWnnW",B:"nnWnnWnnW",C:"WnWnnWnnn",D:"nnnnWWnnW",E:"WnnnWWnnn",F:"nnWnWWnnn",G:"nnnnnWWnW",H:"WnnnnWWnn",I:"nnWnnWWnn",J:"nnnnWWnWn",K:"WnnnnnnWW",L:"nnWnnnnWW",M:"WnWnnnnWn",N:"nnnnWnnWW",O:"WnnnWnnWn",P:"nnWnWnnWn",Q:"nnnnnnWWW",R:"WnnnnnWWn",S:"nnWnnnWWn",T:"nnnnnWWWn",U:"WWnnnnnnW",V:"nWWnnnnnW",W:"WWWnnnnnn",X:"nWnnWnnnW",Y:"WWnnWnnnn",Z:"nWWWnnnnn","-":"nWnnnnWnW",".":"WWnnnnWnn"," ":"nWWnnnWnn",$:"nWnWnWnnn","/":"nWnWnnnWn","+":"nWnnnWnWn","%":"nnnWnWnWn","*":"nWnnnWnWn"};function ft(e,t=40,a=2,i=4){const s=e.toUpperCase().replace(/[^0-9A-Z\-. $/+%]/g,"");if(!s)return"";let n=0,r="";const o="*"+s+"*";for(let l=0;l<o.length;l++){const c=bt[o[l]];if(c){for(let p=0;p<9;p++){const w=c[p]==="W"?a*3:a;p%2===0&&(r+=`<rect x="${n}" y="0" width="${w}" height="${t}" fill="#000"/>`),n+=w}n+=i}}const d=a*3;return r+=`<rect x="${n}" y="0" width="${d}" height="${t}" fill="#000"/>`,n+=d,`<svg class="barcode" viewBox="0 0 ${n} ${t}" width="${n}" height="${t}" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="barcode ${vt(s)}">${r}</svg>`}function vt(e){return e.replace(/[&<>"]/g,t=>`&#${t.charCodeAt(0)};`)}const le=`
.label{width:384px;height:576px;background:#fff;color:#0F172A;padding:20px 22px;display:flex;flex-direction:column;box-sizing:border-box;overflow:hidden;font-family:InterVariable,Inter,system-ui,-apple-system,sans-serif}
.label.a6{width:397px;height:559px;padding:16px 18px}
.l-top{display:flex;justify-content:space-between;align-items:flex-start;gap:8px}
.l-brand{display:flex;gap:9px;align-items:center;min-width:0}
.l-logo{width:42px;height:42px;object-fit:contain;border-radius:8px;flex:none}
.l-biz{font-size:16.5px;font-weight:800;letter-spacing:-.01em;line-height:1.15;word-break:break-word}
.l-sub{font-size:9.5px;color:#5a6b85;margin-top:2px}
.l-onum{text-align:right;flex:none}
.l-on{font-size:15px;font-weight:800;color:#F66916;white-space:nowrap}
.l-od{font-size:9.5px;color:#5a6b85;margin-top:2px}
.l-rule{height:2.5px;background:#0F172A;border-radius:2px;margin:10px 0}
.l-chip{display:inline-block;font-size:8.5px;font-weight:800;letter-spacing:.12em;background:#F1F5F9;color:#334155;padding:3px 8px;border-radius:4px}
.l-addr{margin-top:7px;font-size:11.5px;line-height:1.5}
.l-cname{font-size:16px;font-weight:800;margin-bottom:2px}
.l-lab{color:#5a6b85;font-weight:600}
.l-items{width:100%;border-collapse:collapse;margin-top:12px}
.l-items th{font-size:8.5px;text-transform:uppercase;letter-spacing:.08em;color:#5a6b85;text-align:left;padding:4px 0;border-bottom:1px solid #e3e9f2;font-weight:700}
.l-items td{font-size:11px;padding:5px 0;border-bottom:1px solid #eef2f7}
.l-items .r,.l-items th.r{text-align:right}
.l-bottom{margin-top:auto}
.l-totrow{display:flex;justify-content:space-between;align-items:center;gap:10px;padding-top:10px}
.l-pay{display:inline-block;font-size:10px;font-weight:800;letter-spacing:.06em;border:1.5px solid currentColor;border-radius:5px;padding:2px 8px}
.l-pay.b-paid{color:#15803d}.l-pay.b-cod{color:#c2540a}.l-pay.b-pending{color:#a16207}.l-pay.b-failed{color:#b91c1c}
.l-amt{font-size:12px;color:#334155}.l-amt b{font-size:14.5px;color:#0F172A}
.l-gst{font-size:9.5px;color:#5a6b85;margin-top:6px}
.l-bar{margin-top:10px;display:flex;flex-direction:column;align-items:center;gap:3px}
.barcode{max-width:272px;height:36px}
.label.a6 .barcode{height:30px}
.l-bct{font-size:10px;letter-spacing:.18em;font-weight:600}
.l-foot{margin-top:10px;border-top:1px solid #e3e9f2;padding-top:7px;font-size:9px;color:#5a6b85;text-align:center}
.label-host{width:-moz-fit-content;width:fit-content;border-radius:10px;overflow:hidden;border:1px solid #e3e9f2;box-shadow:0 10px 30px rgba(15,23,42,.12)}
`;function Ce(e){return`@font-face{font-family:InterVariable;src:url(${e}) format('woff2-variations');font-weight:100 900;font-display:swap}`}const ce=()=>typeof chrome<"u"&&chrome.runtime?.getURL?chrome.runtime.getURL("fonts/InterVariable.woff2"):"/fonts/InterVariable.woff2",Ae=()=>Ce(ce());let H=null;async function gt(){if(H!==null)return H;try{const e=await(await fetch(ce())).arrayBuffer(),t=new Uint8Array(e);let a="";for(let i=0;i<t.length;i+=32768)a+=String.fromCharCode(...t.subarray(i,i+32768));H="data:font/woff2;base64,"+btoa(a)}catch{H=""}return H}function Pe(e,t,a){const i=new Map(a.map(b=>[b.id,b])),s=t.labelFields.map(b=>i.get(b)).filter(Boolean),n=b=>(e.customerData[b]||"").trim(),r=b=>s.find(je=>b.test(je.name)),o=s.find(b=>/name|customer/i.test(b.name)),d=s.find(b=>b.type==="phone")||r(/phone|mobile|whatsapp/i),l=s.find(b=>b.type==="textarea"&&/address/i.test(b.name))||r(/address|street/i),c=r(/city|town/i),p=r(/state|province/i),h=r(/pin|zip|postal/i),w=s.filter(b=>![o,d,l,c,p,h].includes(b)&&n(b.id)),m=o?n(o.id):"",g=l?n(l.id).split(/\r?\n/).map(b=>b.trim()).filter(Boolean):[],f=[c&&n(c.id),p&&n(p.id)].filter(b=>!!b).map(b=>u(b)).join(", "),x=h?n(h.id):"",A=[f,x].filter(Boolean).join(" - "),ue=[t.phone,t.website].filter(b=>!!b).map(b=>u(b)).join("  ·  "),Re=new Date(e.createdAt).toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"}),E=t.labelExtras,De=e.items.map(b=>`<tr><td>${u(b.name)}${b.sku?` <span class="l-lab">(${u(b.sku)})</span>`:""}</td>${E.quantity?`<td class="r">${b.qty}</td>`:""}${E.amount?`<td class="r">${C(b.price*b.qty)}</td>`:""}</tr>`).join("");return`<div class="label ${t.labelSize==="a6"?"a6":""}">
  <div class="l-top">
    <div class="l-brand">${t.logo?`<img class="l-logo" src="${t.logo}" alt="">`:""}<div><div class="l-biz">${u(t.businessName)}</div>${ue?`<div class="l-sub">${ue}</div>`:""}</div></div>
    <div class="l-onum">${E.orderNumber?`<div class="l-on">${u(e.orderNumber)}</div>`:""}<div class="l-od">${u(Re)}</div></div>
  </div>
  <div class="l-rule"></div>
  <div><span class="l-chip">DELIVER TO</span></div>
  <div class="l-addr">
    ${m?`<div class="l-cname">${u(m)}</div>`:""}
    ${d&&n(d.id)?`<div><span class="l-lab">Mobile:</span> ${u(n(d.id))}</div>`:""}
    ${g.map(b=>`<div>${b}</div>`).join("")}
    ${A?`<div>${A}</div>`:""}
    ${w.map(b=>`<div><span class="l-lab">${u(b.name)}:</span> ${u(n(b.id))}</div>`).join("")}
  </div>
  <div class="l-bottom">
    ${E.products&&e.items.length>0?`<table class="l-items"><thead><tr><th>Product</th>${E.quantity?'<th class="r">Qty</th>':""}${E.amount?'<th class="r">Amount</th>':""}</tr></thead><tbody>${De}</tbody></table>`:""}
    <div class="l-totrow">
      ${E.payment?`<span class="l-pay b-${u(e.paymentStatus.toLowerCase())}">${u(e.paymentStatus.toUpperCase())}</span>`:"<span></span>"}
      ${E.amount?`<span class="l-amt">Total <b>${C(e.total)}</b></span>`:""}
    </div>
    ${E.gst&&t.gst?`<div class="l-gst">GSTIN: ${u(t.gst)}</div>`:""}
    ${E.barcode?`<div class="l-bar">${ft(e.orderNumber)}<div class="l-bct">${u(e.orderNumber)}</div></div>`:""}
    <div class="l-foot">${u(t.footer||"Thank you for your order!")}</div>
  </div>
</div>`}function Oe(e,t,a,i){const s=document.createElement("div");s.className="label-host";const n=s.attachShadow({mode:"open"});n.innerHTML=`<style>${Ae()}${le}</style>${Pe(t,a,i)}`,e.innerHTML="",e.appendChild(s)}async function yt(e,t,a){const i=await gt(),s=t.labelSize==="a6"?"105mm 148mm":"4in 6in";return`<!doctype html><html><head><meta charset="utf-8"><title>${u(e.orderNumber)} — Label</title><style>${Ce(i||ce())}${le}
body{margin:0;background:#eef1f6;display:flex;align-items:flex-start;justify-content:center;padding:16px}
.toolbar{position:fixed;top:12px;right:14px;display:flex;gap:8px}
.toolbar button{font:600 13px InterVariable,Inter,system-ui,sans-serif;padding:8px 16px;border-radius:8px;border:1px solid #cbd5e1;background:#fff;cursor:pointer}
.toolbar button:hover{background:#f8fafc}
.toolbar button.pri{background:#F66916;border-color:#F66916;color:#fff}
.toolbar button.pri:hover{background:#e05a0e}
@media print{.toolbar{display:none}body{background:#fff;padding:0}}
@page{size:${s};margin:0}
</style></head><body>
<div class="toolbar"><button class="pri" onclick="window.print()">Print Label</button></div>
${Pe(e,t,a)}
</body></html>`}async function Ie(e,t,a){const i=await yt(e,t,a);let s=null;try{s=window.open("","_blank")}catch{}if(s){s.document.open(),s.document.write(i),s.document.close();const r=s;(r.document.fonts?.ready||Promise.resolve()).then(()=>setTimeout(()=>r.print(),60));return}const n=document.createElement("iframe");n.setAttribute("aria-hidden","true"),n.style.cssText="position:fixed;right:0;bottom:0;width:1px;height:1px;opacity:0;border:0;",n.srcdoc=i,document.body.appendChild(n),setTimeout(()=>{try{n.contentWindow?.focus(),n.contentWindow?.print()}catch{}},600),setTimeout(()=>n.remove(),12e4)}async function Me(e,t,a){const i=document.createElement("div");i.style.cssText="position:fixed;left:-9999px;top:0;",document.body.appendChild(i);try{Oe(i,e,t,a);const s=i.querySelector(".label");if(!s)throw new Error("Label preview is not ready.");const{jpeg:n,w:r,h:o}=await wt(s),[d,l]=t.labelSize==="a6"?[297.64,419.53]:[288,432],c=$t(d,l,n,r,o),p=URL.createObjectURL(c),h=document.createElement("a");h.href=p,h.download=`${e.orderNumber}-label.pdf`,document.body.appendChild(h),h.click(),h.remove(),setTimeout(()=>URL.revokeObjectURL(p),1e4)}finally{i.remove()}}async function wt(e){const t=e.getBoundingClientRect(),a=3,i=Math.max(1,Math.round(t.width*a)),s=Math.max(1,Math.round(t.height*a)),n=e.cloneNode(!0),r=e.querySelector("svg.barcode");if(r){const m=r.getBoundingClientRect(),g=n.querySelector("svg.barcode"),f=document.createElement("img");f.src="data:image/svg+xml;charset=utf-8,"+encodeURIComponent(new XMLSerializer().serializeToString(r)),f.style.width=m.width+"px",f.style.height=m.height+"px",f.style.display="block",g&&g.replaceWith(f)}const o=`<!DOCTYPE html><html><head><meta charset="utf-8"><style>${Ae()}${le}body{margin:0;background:#fff}</style></head><body>${new XMLSerializer().serializeToString(n)}</body></html>`,d=await new Promise((m,g)=>{const f=new Image;f.onload=()=>m(f),f.onerror=()=>g(new Error("Label download failed. Please try again.")),f.src="data:text/html;charset=utf-8,"+encodeURIComponent(o)}),l=document.createElement("canvas");l.width=i,l.height=s;const c=l.getContext("2d");if(!c)throw new Error("Label download failed. Please try again.");c.fillStyle="#fff",c.fillRect(0,0,i,s),c.drawImage(d,0,0,i,s);const p=l.toDataURL("image/jpeg",.94),h=atob(p.slice(p.indexOf(",")+1)),w=new Uint8Array(h.length);for(let m=0;m<h.length;m++)w[m]=h.charCodeAt(m);return{jpeg:w,w:i,h:s}}function $t(e,t,a,i,s){const n=[],r=[];let o=0;const d=m=>{n.push(m),o+=m.length},l=m=>{n.push(m),o+=m.length},c=m=>{r.push(o),d(m)};d(`%PDF-1.4
`),c(`1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
`),c(`2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
`),c(`3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${e} ${t}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>
endobj
`);const p=`q ${e.toFixed(2)} 0 0 ${t.toFixed(2)} 0 0 cm /Im0 Do Q`;r.push(o),d(`4 0 obj
<< /Type /XObject /Subtype /Image /Width ${i} /Height ${s} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${a.length} >>
stream
`),l(a),d(`
endstream
endobj
`),r.push(o),d(`5 0 obj
<< /Length ${p.length} >>
stream
${p}
endstream
endobj
`);const h=o;let w=`xref
0 6
0000000000 65535 f 
`;for(const m of r)w+=String(m).padStart(10,"0")+` 00000 n 
`;return d(w),d(`trailer
<< /Size 6 /Root 1 0 R >>
startxref
${h}
%%EOF`),new Blob(n,{type:"application/pdf"})}async function ie(e){e.labelPrinted||(e.labelPrinted=!0,e.updatedAt=new Date().toISOString(),await ae(e))}let te="";const ve=e=>e.items.map(t=>t.qty>1?`${t.name} ×${t.qty}`:t.name).join(", ");function xt(e,t){const a=z(),i=te.trim().toLowerCase(),n=(i?a.filter(o=>[o.orderNumber,se(o),me(o)].some(d=>d.toLowerCase().includes(i))):a).slice(0,50),r=y();return{html:`<div class="page-head">
        <div><h2 class="page-title">Orders</h2><div class="page-sub">${a.length} order${a.length===1?"":"s"} saved${r.sheetId?" · synced to Google Sheets":" · saved on this device"}</div></div>
        <div class="head-actions">
          <button class="btn primary" data-act="new">+ New Order</button>
          ${`<button class="btn" data-act="tab" title="Open all orders in a full browser tab">All Orders ${k.external}</button>`}
        </div>
      </div>
      <div class="toolbar">
        <input type="search" placeholder="Search order no., customer, phone…" data-search value="${u(te)}">
        <span class="count">${n.length} recent shown</span>
      </div>
      ${n.length===0?`<div class="card"><div class="empty">${i?"No orders match your search.":"No orders yet."}<br><button class="btn primary" data-act="new">+ New Order</button></div></div>`:`<div class="tblwrap"><table class="tbl">
        <thead><tr><th>Order Number</th><th>Customer</th><th>Phone</th><th>Products</th><th class="num">Amount</th><th>Payment</th><th>Date</th><th>Label</th><th></th></tr></thead>
        <tbody>
          ${n.map(o=>`<tr>
            <td class="strong nowrap">${u(o.orderNumber)}</td>
            <td class="ellip">${u(se(o))}</td>
            <td class="nowrap muted">${u(me(o))}</td>
            <td class="ellip muted" title="${u(ve(o))}">${u(ve(o))}</td>
            <td class="num strong nowrap">${C(o.total)}</td>
            <td><span class="badge ${o.paymentStatus}">${o.paymentStatus}</span></td>
            <td class="nowrap muted">${_e(o.createdAt)}</td>
            <td><span class="badge ${o.labelPrinted?"ok":"warn"}">${o.labelPrinted?"Printed":"Pending"}</span></td>
            <td><div class="rowbtns">
              <button class="btn small" data-act="label" data-id="${o.id}" title="Preview label">Label</button>
              <button class="btn small" data-act="edit" data-id="${o.id}" title="Edit order">${k.edit}</button>
              <button class="btn small" data-act="print" data-id="${o.id}" title="Print label">${k.print}</button>
              <button class="btn small" data-act="download" data-id="${o.id}" title="Download label PDF">${k.download}</button>
            </div></td>
          </tr>`).join("")}
        </tbody></table></div>`}`,bind(o){const d=o.querySelector("[data-search]");d?.addEventListener("input",()=>{te=d.value,e.rerender();const l=o.querySelector("[data-search]");l.focus(),l.setSelectionRange(l.value.length,l.value.length)}),o.querySelector('[data-act="new"]')?.addEventListener("click",()=>{e.go("new")}),o.querySelector('[data-act="tab"]')?.addEventListener("click",()=>window.open(chrome.runtime.getURL("orders.html"))),o.querySelectorAll("[data-id]").forEach(l=>l.addEventListener("click",()=>{const c=l.dataset.act,p=l.dataset.id,h=z().find(w=>w.id===p);h&&(c==="label"?e.go("label",p):c==="edit"?e.go("new",p):c==="print"?Ie(h,y(),$()).then(()=>ie(h)).then(()=>{v("Label sent to printer.","ok"),e.rerender()}).catch(w=>v(D(w),"err")):c==="download"&&Me(h,y(),$()).then(()=>ie(h)).then(()=>{v(`${h.orderNumber}-label.pdf downloaded.`,"ok"),e.rerender()}).catch(w=>v(D(w),"err")))}))}}}function St(e){const t=P();return{html:`<div class="page-head">
        <div><h2 class="page-title">Products</h2><div class="page-sub">Select these while creating an order</div></div>
        <div class="head-actions"><button class="btn primary" data-act="add">+ Add Product</button></div>
      </div>
      ${t.length===0?'<div class="card"><div class="empty">No products yet.<br><button class="btn primary" data-act="add">+ Add Product</button></div></div>':`<div class="tblwrap"><table class="tbl">
        <thead><tr><th>Name</th><th>SKU</th><th class="num">Price</th><th>Active</th><th></th></tr></thead>
        <tbody>${t.map(a=>`<tr>
          <td class="strong">${u(a.name)}</td>
          <td class="muted">${u(a.sku)}</td>
          <td class="num strong nowrap">${C(a.price)}</td>
          <td><label class="switch"><input type="checkbox" data-toggle="${a.id}" ${a.active?"checked":""}><i></i></label></td>
          <td><div class="rowbtns">
            <button class="btn small" data-edit="${a.id}">Edit</button>
            <button class="btn small ghost-danger" data-del="${a.id}">Delete</button>
          </div></td>
        </tr>`).join("")}</tbody></table></div>`}`,bind(a){a.querySelectorAll('[data-act="add"]').forEach(i=>i.addEventListener("click",()=>void ge(null,e))),a.querySelectorAll("[data-toggle]").forEach(i=>i.addEventListener("change",async()=>{const s=i.dataset.toggle,n=i.checked;await B(P().map(r=>r.id===s?{...r,active:n}:r))})),a.querySelectorAll("[data-edit]").forEach(i=>i.addEventListener("click",()=>{const s=P().find(n=>n.id===i.dataset.edit);s&&ge(s,e)})),a.querySelectorAll("[data-del]").forEach(i=>i.addEventListener("click",async()=>{const s=P().find(r=>r.id===i.dataset.del);!s||!await qe("Delete product?",`<b>${u(s.name)}</b> will be removed from the product list. Existing orders are not affected.`,"Delete")||(await B(P().filter(r=>r.id!==s.id)),v("Product deleted."),e.rerender())}))}}}async function ge(e,t){V(`<h3>${e?"Edit Product":"Add Product"}</h3>
     <div class="fgrid">
       <div class="field span2"><label class="f">Name <span class="req">*</span></label><input type="text" data-n value="${u(e?.name||"")}"></div>
       <div class="field"><label class="f">SKU</label><input type="text" data-s value="${u(e?.sku||"")}"></div>
       <div class="field"><label class="f">Price (₹)</label><input type="number" step="any" min="0" data-p value="${e?.price??0}"></div>
     </div>
     <label class="checkrow"><input type="checkbox" data-a ${e?.active??!0?"checked":""}> Active (selectable in orders)</label>
     <div class="row"><button class="btn" data-x>Cancel</button><button class="btn primary" data-save>Save</button></div>`,(a,i)=>{a.querySelector("[data-x]").addEventListener("click",i),a.querySelector("[data-save]").addEventListener("click",async()=>{const s=a.querySelector("[data-n]").value.trim(),n=a.querySelector("[data-s]").value.trim(),r=Math.max(0,Number(a.querySelector("[data-p]").value)||0),o=a.querySelector("[data-a]").checked;if(!s){a.querySelector("[data-n]").classList.add("invalid"),v("Product name is required.","err");return}const d=P();e?await B(d.map(l=>l.id===e.id?{...l,name:s,sku:n,price:r,active:o}:l)):await B([...d,{id:oe("p_"),name:s,sku:n,price:r,active:o}]),i(),v("Product saved.","ok"),t.rerender()})})}function kt(e){const t=$();return{html:`<div class="page-head">
        <div><h2 class="page-title">Custom Fields</h2><div class="page-sub">Each field becomes a spreadsheet column — every order fills one row</div></div>
        <div class="head-actions"><button class="btn primary" data-act="add">+ Add Field</button></div>
      </div>
      <div class="card">
        ${t.length===0?'<div class="empty">No fields yet. Add fields like Customer Name, Phone, Address, City…<br><button class="btn primary" data-act="add">+ Add Field</button></div>':`<div>${t.map((a,i)=>`<div class="list-row">
              <span class="muted nowrap" style="font-size:11px">${i+1}.</span>
              <div class="grow"><span class="name">${u(a.name)}</span>${a.required?' <span class="req" style="color:var(--danger);font-weight:800">*</span>':""}</div>
              <span class="type-badge">${a.type}</span>
              <label class="switch" title="Required"><input type="checkbox" data-req="${a.id}" ${a.required?"checked":""}><i></i></label>
              <button class="btn small icon" data-up="${a.id}" ${i===0?"disabled":""} title="Move up">↑</button>
              <button class="btn small icon" data-down="${a.id}" ${i===t.length-1?"disabled":""} title="Move down">↓</button>
              <button class="btn small" data-edit="${a.id}">Edit</button>
              <button class="btn small ghost-danger" data-del="${a.id}">Delete</button>
            </div>`).join("")}</div>`}
        <div class="hint">Reorder with ↑ ↓ — the order here is the order in the order form and on the label.</div>
      </div>`,bind(a){a.querySelector('[data-act="add"]')?.addEventListener("click",()=>void ye(null,e)),a.querySelectorAll("[data-req]").forEach(s=>s.addEventListener("change",async()=>{const n=s.dataset.req,r=s.checked;await M($().map(o=>o.id===n?{...o,required:r}:o))}));const i=async(s,n)=>{const r=$(),o=r.findIndex(l=>l.id===s),d=o+n;o<0||d<0||d>=r.length||([r[o],r[d]]=[r[d],r[o]],await M(r.map((l,c)=>({...l,order:c}))),e.rerender())};a.querySelectorAll("[data-up]").forEach(s=>s.addEventListener("click",()=>void i(s.dataset.up,-1))),a.querySelectorAll("[data-down]").forEach(s=>s.addEventListener("click",()=>void i(s.dataset.down,1))),a.querySelectorAll("[data-edit]").forEach(s=>s.addEventListener("click",()=>{const n=$().find(r=>r.id===s.dataset.edit);n&&ye(n,e)})),a.querySelectorAll("[data-del]").forEach(s=>s.addEventListener("click",async()=>{const n=$().find(d=>d.id===s.dataset.del);if(!n||!await qe("Delete field?",`<b>${u(n.name)}</b> will be removed from the order form. Existing orders keep their data, and the spreadsheet column is never deleted.`,"Delete"))return;const o=$().filter(d=>d.id!==n.id);await M(o.map((d,l)=>({...d,order:l}))),v("Field deleted."),e.rerender()}))}}}async function ye(e,t){V(`<h3>${e?"Edit Field":"Add Field"}</h3>
     <div class="fgrid">
       <div class="field span2"><label class="f">Field name <span class="req">*</span></label><input type="text" data-n value="${u(e?.name||"")}" placeholder="e.g. Customer Name"></div>
       <div class="field"><label class="f">Type</label><select data-t>${Fe.map(([a,i])=>`<option value="${a}" ${e?.type===a?"selected":""}>${i}</option>`).join("")}</select></div>
       <div class="field"><label class="f">Required</label><label class="checkrow" style="padding:6px 0 0"><input type="checkbox" data-r ${e?.required?"checked":""}> Must be filled</label></div>
       <div class="field span2" data-optwrap style="display:${e?.type==="dropdown"?"block":"none"}"><label class="f">Dropdown options <span class="muted">(one per line)</span></label><textarea rows="3" data-o>${u((e?.options||[]).join(`
`))}</textarea></div>
     </div>
     <div class="hint">Field names become spreadsheet column headers. Existing orders are never affected by changes here.</div>
     <div class="row"><button class="btn" data-x>Cancel</button><button class="btn primary" data-save>Save Field</button></div>`,(a,i)=>{const s=a.querySelector("[data-t]");s.addEventListener("change",()=>{a.querySelector("[data-optwrap]").style.display=s.value==="dropdown"?"block":"none"}),a.querySelector("[data-x]").addEventListener("click",i),a.querySelector("[data-save]").addEventListener("click",async()=>{const n=a.querySelector("[data-n]"),r=n.value.trim(),o=s.value,d=a.querySelector("[data-r]").checked,l=a.querySelector("[data-o]").value.split(`
`).map(h=>h.trim()).filter(Boolean);if(!r){n.classList.add("invalid"),v("Field name is required.","err");return}if(o==="dropdown"&&l.length===0){v("Add at least one dropdown option.","err");return}if($().find(h=>h.name.trim().toLowerCase()===r.toLowerCase()&&h.id!==e?.id)){n.classList.add("invalid"),v("A field with this name already exists.","err");return}const p=$();e?await M(p.map(h=>h.id===e.id?{...h,name:r,type:o,required:d,options:o==="dropdown"?l:void 0}:h)):await M([...p,{id:oe("f_"),name:r,type:o,required:d,options:o==="dropdown"?l:void 0,order:p.length}]),i(),v("Field saved.","ok"),t.rerender()})})}const F={signedIn:!1};function Lt(e){const t=y(),a=$(),i=Y(),s=!!t.sheetId,n=a.map(l=>`<label class="checkrow"><input type="checkbox" data-lf="${l.id}" ${t.labelFields.includes(l.id)?"checked":""}> ${u(l.name)}</label>`).join(""),o=[["orderNumber","Order Number"],["products","Products"],["quantity","Quantity"],["payment","Payment Status"],["amount","Amount"],["gst","Business GST"],["barcode","Barcode"]].map(([l,c])=>`<label class="checkrow"><input type="checkbox" data-ex="${l}" ${t.labelExtras[l]?"checked":""}> ${c}</label>`).join(""),d=s?`<div class="card-sub" style="margin-top:12px">Column mapping — fields reuse matching columns automatically. Map a field to a different existing column if needed.</div>
       ${a.length===0?'<div class="muted" style="font-size:12px">No custom fields to map.</div>':a.map(l=>{const c=t.customMap[l.id]||"";return`<div class="map-row"><div class="strong">${u(l.name)}</div><select data-map="${l.id}"><option value="">Auto${c?"":" (matched)"}</option>${i.map(p=>`<option value="${u(p)}" ${c===p?"selected":""}>${u(p)}</option>`).join("")}</select></div>`}).join("")}`:"";return{html:`<div class="page-head">
        <div><h2 class="page-title">Settings</h2><div class="page-sub">Changes are saved automatically</div></div>
      </div>

      <div class="card">
        <div class="card-title">Business</div>
        <div class="set-grid">
          <div class="field"><label class="f">Business Name</label><input type="text" data-k="businessName" value="${u(t.businessName)}"></div>
          <div class="field"><label class="f">Phone</label><input type="text" data-k="phone" value="${u(t.phone)}"></div>
          <div class="field"><label class="f">Website</label><input type="text" data-k="website" value="${u(t.website)}"></div>
          <div class="field"><label class="f">GST</label><input type="text" data-k="gst" value="${u(t.gst)}"></div>
          <div class="field span2"><label class="f">Address</label><textarea rows="2" data-k="address">${u(t.address)}</textarea></div>
          <div class="field span2"><label class="f">Label Footer</label><input type="text" data-k="footer" value="${u(t.footer)}" placeholder="Thank you for your order!"></div>
          <div class="field span2"><label class="f">Logo</label>
            <div class="logo-row">
              ${t.logo?`<img src="${t.logo}" alt="logo">`:""}
              <button class="btn small" data-act="logo">${t.logo?"Change Logo":"Upload Logo"}</button>
              ${t.logo?'<button class="btn small ghost-danger" data-act="logorm">Remove</button>':""}
              <input type="file" accept="image/*" data-logo hidden>
            </div>
            <div class="hint">Shown on the shipping label. PNG/JPG, up to ~300 KB.</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Google Sheets</div>
        <div class="toolbar" style="margin-bottom:8px">
          <span class="dot ${F.signedIn?"on":""}" data-gdot></span>
          <span class="count" data-gstatus>${s?`Spreadsheet connected: ${t.sheetName||"…"}`:F.signedIn?"Google account connected":"Not connected"}</span>
          <span class="spacer"></span>
          <button class="btn small" data-act="gdisconnect" ${F.signedIn||s?"":"disabled"}>Disconnect</button>
        </div>
        <div class="set-grid">
          <div class="field span2"><label class="f">Spreadsheet URL or ID</label><input type="text" data-sheetref value="${u(t.sheetId)}" placeholder="https://docs.google.com/spreadsheets/d/…"></div>
          <div class="field"><label class="f">Worksheet</label><select data-ws ${s?"":"disabled"}><option value="${u(t.sheetName)}">${u(t.sheetName||"—")}</option></select></div>
          <div class="field"><label class="f">&nbsp;</label><button class="btn" data-act="use" style="width:100%">${s?"Re-read Connection":"Connect Spreadsheet"}</button></div>
        </div>
        <div class="field" style="margin-top:4px"><label class="f">Google OAuth Client ID</label><input type="text" data-k="clientId" value="${u(t.clientId)}" placeholder="xxxxxxxx.apps.googleusercontent.com"></div>
        <details class="help">
          <summary>One-time setup: how to get a Client ID (free, ~2 minutes)</summary>
          <ol>
            <li>Open <b>console.cloud.google.com</b> → create/select a project.</li>
            <li><b>APIs &amp; Services → Library</b> → enable <b>Google Sheets API</b>.</li>
            <li><b>OAuth consent screen</b> → External → add yourself as a <b>test user</b>.</li>
            <li><b>Credentials → Create credentials → OAuth client ID</b> → type <b>Web application</b>.</li>
            <li>Add this <b>Authorized redirect URI</b>: <code>${u(chrome?.identity?.getRedirectURL?chrome.identity.getRedirectURL():"chrome-extension://EXTENSION_ID.chromiumapp.org/")}</code></li>
            <li>Copy the <b>Client ID</b> and paste it above, then click <b>Connect Spreadsheet</b>.</li>
          </ol>
        </details>
        ${d}
      </div>

      <div class="card">
        <div class="card-title">Orders</div>
        <div class="set-grid">
          <div class="field"><label class="f">Order Prefix</label><input type="text" data-k="orderPrefix" value="${u(t.orderPrefix)}"></div>
          <div class="field"><label class="f">Starting Number</label><input type="number" min="1" step="1" data-k="nextNumber" value="${t.nextNumber}"></div>
        </div>
        <div class="hint">New orders get <b>${u(t.orderPrefix)}${t.nextNumber}</b>. You can always type a manual order number.</div>
      </div>

      <div class="card">
        <div class="card-title">Label</div>
        <div class="set-grid">
          <div class="field"><label class="f">Label Size</label>
            <select data-k="labelSize">
              <option value="4x6" ${t.labelSize==="4x6"?"selected":""}>4 × 6 inch (default)</option>
              <option value="a6" ${t.labelSize==="a6"?"selected":""}>A6 (105 × 148 mm)</option>
            </select>
          </div>
        </div>
        <div class="card-sub" style="margin-top:12px">Customer fields shown on the label</div>
        ${a.length===0?'<div class="muted" style="font-size:12px">No custom fields yet.</div>':`<div style="columns:2;gap:24px">${n}</div>`}
        <div class="card-sub" style="margin-top:12px">Label sections</div>
        <div style="columns:2;gap:24px">${o}</div>
      </div>

      <div class="card">
        <div class="card-title">Backup</div>
        <div class="toolbar">
          <button class="btn" data-act="export">Export Orders</button>
          <button class="btn" data-act="import">Import Settings</button>
          <span class="count">Exports include orders, fields, products and settings as JSON.</span>
        </div>
        <input type="file" accept="application/json" data-importfile hidden>
      </div>`,async bind(l){const c=y();l.querySelectorAll("[data-k]").forEach(m=>{const g=m.dataset.k;m.addEventListener("change",async()=>{let x=m.value;g==="nextNumber"&&(x=Math.max(1,Math.floor(Number(x)||1))),await S({...y(),[g]:x}),v("Saved.")})});const p=l.querySelector("[data-logo]");l.querySelector('[data-act="logo"]')?.addEventListener("click",()=>p.click()),p?.addEventListener("change",()=>{const m=p.files?.[0];if(!m)return;if(m.size>400*1024){v("Logo is too large — please use an image under 400 KB.","err"),p.value="";return}const g=new FileReader;g.onload=async()=>{await S({...y(),logo:String(g.result)}),v("Logo saved.","ok"),e.rerender()},g.readAsDataURL(m)}),l.querySelector('[data-act="logorm"]')?.addEventListener("click",async()=>{await S({...y(),logo:""}),e.rerender()}),Se().then(m=>{F.signedIn=m;const g=l.querySelector("[data-gdot]"),f=l.querySelector("[data-gstatus]");g&&(g.className="dot "+(m?"on":"")),f&&!y().sheetId&&(f.textContent=m?"Google account connected":"Not connected")}).catch(()=>{}),l.querySelector('[data-act="use"]')?.addEventListener("click",()=>void Et(e,l)),l.querySelector('[data-act="gdisconnect"]')?.addEventListener("click",()=>void Wt(e));const h=l.querySelector("[data-ws]");h?.addEventListener("change",()=>void Nt(e,h.value)),l.querySelectorAll("[data-map]").forEach(m=>m.addEventListener("change",async()=>{const g=m.dataset.map,f=m.value,x={...y().customMap};f?x[g]=f:delete x[g],await S({...y(),customMap:x}),v("Column mapping saved.","ok")})),l.querySelectorAll("[data-lf]").forEach(m=>m.addEventListener("change",async()=>{const g=m.dataset.lf,f=m.checked,x=$().filter(A=>A.id===g?f:c.labelFields.includes(A.id)).map(A=>A.id);await S({...y(),labelFields:x})})),l.querySelectorAll("[data-ex]").forEach(m=>m.addEventListener("change",async()=>{const g=m.dataset.ex,f=m.checked,x={...y().labelExtras,[g]:f};await S({...y(),labelExtras:x})})),l.querySelector('[data-act="export"]')?.addEventListener("click",()=>{Xe(),v("Backup exported.","ok")});const w=l.querySelector("[data-importfile]");l.querySelector('[data-act="import"]')?.addEventListener("click",()=>w.click()),w?.addEventListener("change",()=>{const m=w.files?.[0];m&&Ze(m).then(()=>{v("Settings imported.","ok"),e.rerender()}).catch(g=>v("Import failed: "+(g instanceof Error?g.message:"invalid file"),"err"))})}}}async function Et(e,t){const a=y(),i=t.querySelector("[data-sheetref]"),s=i.value.trim();if(!a.clientId.trim()){v("Add your Google OAuth Client ID first (see the steps below the field).","err");return}if(!s){i.classList.add("invalid"),v("Paste your Google Sheets link or spreadsheet ID.","err");return}const n=ut(s);try{await S({...y(),clientId:a.clientId.trim()}),await tt();const r=await nt(n);if(r.sheets.length===0)throw new Error("This spreadsheet has no worksheets.");const o=r.sheets[0],d=await de(n,o);await S({...y(),sheetId:n,sheetName:o}),Z(d),F.signedIn=!0,v(`Connected. ${d.length} columns ready (${Ee.length} standard + your fields).`,"ok"),e.rerender()}catch(r){v(D(r),"err")}}async function Nt(e,t){const a=y();if(!(!a.sheetId||!t))try{const i=await de(a.sheetId,t);await S({...y(),sheetName:t}),Z(i),v(`Worksheet switched to "${t}".`,"ok"),e.rerender()}catch(i){v(D(i),"err")}}async function Wt(e){try{await at()}catch{}await S({...y(),sheetId:"",sheetName:""}),Z([]),F.signedIn=!1,v("Disconnected from Google Sheets."),e.rerender()}function qt(e,t,a){return{html:`<div class="labelview-bar">
      <button class="btn" data-act="back">← Back</button>
      <div class="title">Label <span class="ordnum">${u(e.orderNumber)}</span></div>
      <div class="spacer"></div>
      <button class="btn" data-act="download">⬇ Download Label</button>
      <button class="btn primary" data-act="print">🖨 Print Label</button>
    </div>
    <div class="label-stage" data-stage></div>`,bind(i){const s=y(),n=$();Oe(i.querySelector("[data-stage]"),e,s,n);const r=async(o,d)=>{try{await o(),await ie(e),v(d,"ok"),a?.()}catch(l){v(D(l),"err")}};i.querySelector('[data-act="back"]').addEventListener("click",t),i.querySelector('[data-act="print"]').addEventListener("click",()=>void r(()=>Ie(e,s,n),"Label sent to printer.")),i.querySelector('[data-act="download"]').addEventListener("click",()=>void r(()=>Me(e,s,n),"Label downloaded as PDF."))}}}const I=document.getElementById("app"),Ct=[["dashboard","Dashboard",k.dash],["new","New Order",k.plus],["orders","Orders",k.list],["products","Products",k.box],["fields","Custom Fields",k.sliders],["settings","Settings",k.gear]];let R="dashboard",q=null;const Q={get route(){return R},get id(){return q},go(e,t=null){R=e,q=t??null;const a=e==="new"?q?`#edit=${q}`:"#new":e==="label"&&q?`#label=${q}`:"";try{history.replaceState(null,"",a||location.pathname)}catch{}X()},rerender(){X()}},At={dashboard:it,new:mt,orders:e=>xt(e),products:St,fields:kt,settings:Lt};function Pt(){if(R==="label"){const e=q?$e(q):void 0;if(e)return qt(e,()=>Q.go("orders"),()=>X());R="orders",q=null}return At[R](Q)}function X(){const e=Pt();I.innerHTML=`
    <header class="top">
      <div class="brand">${k.tag} Order Label Manager</div>
      <div class="spacer"></div>
      <button class="conn" data-conn title="Google Sheets connection status — click to open Settings"><span class="dot" data-gdot></span><span data-gtxt>Google</span></button>
      <button class="btn small" data-opentab title="Open all orders in a full browser tab">Orders ${k.external}</button>
    </header>
    <nav class="tabs">${Ct.map(([a,i,s])=>`<button data-route="${a}" class="${R===a?"active":""}">${s} ${i}</button>`).join("")}</nav>
    <main class="content"></main>`;const t=I.querySelector("main.content");t.innerHTML=e.html,I.querySelectorAll("[data-route]").forEach(a=>a.addEventListener("click",()=>Q.go(a.dataset.route))),I.querySelector("[data-opentab]")?.addEventListener("click",()=>window.open(chrome.runtime.getURL("orders.html"))),I.querySelector("[data-conn]")?.addEventListener("click",()=>Q.go("settings")),Se().then(a=>{const i=I.querySelector("[data-gdot]"),s=I.querySelector("[data-gtxt]");i&&(i.className="dot "+(a?"on":"")),s&&(s.textContent=a?"Google connected":"Google")}).catch(()=>{}),e.bind?.(t)}function Ot(){const e=location.hash.replace(/^#/,""),[t,a]=e.split("=");return t==="edit"&&a?{route:"new",id:a}:t==="label"&&a?{route:"label",id:a}:t==="new"?{route:"new",id:null}:{route:"dashboard",id:null}}function It(){return new Promise(e=>{try{chrome.windows.getCurrent(t=>e(t.type==="normal"))}catch{e(!1)}})}async function Mt(){await Qe();const e=Ot();R=e.route,q=e.id,document.documentElement.classList.toggle("as-page",await It()),X()}Mt();
