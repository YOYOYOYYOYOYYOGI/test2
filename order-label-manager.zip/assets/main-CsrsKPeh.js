import{g as V,a as $,e as c,m as N,b as A,t as h,c as D,P as te,n as B,i as ae,d as se,f as de,h as y,s as ne,j as H,k as R,u as z,l as Y,o as ie,p as J,q as le,r as j,v as Q,w as I,F as re,x as ce,y as k,z as X,A as oe,B as ue,C as pe,D as ve,E as be,G as F,H as Z,I as me,S as he,J as ye,K as fe,L as x,M as ge,N as $e}from"./label-view-CbfgsESy.js";let S=null,P=null;function ee(){S=null,P="\0reset"}function _(){return{id:null,orderNumber:B(),customerData:{},items:[],paymentStatus:"COD"}}function we(t,s){const e=t.required?' <span class="req">*</span>':"",l=c(t.id);switch(t.type){case"textarea":return`<div class="field span2"><label class="f">${c(t.name)}${e}</label><textarea rows="2" data-fid="${l}">${c(s)}</textarea></div>`;case"dropdown":{const i=(t.options||[]).map(d=>`<option ${d===s?"selected":""}>${c(d)}</option>`).join("");return`<div class="field"><label class="f">${c(t.name)}${e}</label><select data-fid="${l}"><option value=""></option>${i}</select></div>`}case"checkbox":return`<div class="field"><label class="f">${c(t.name)}${e}</label><label class="checkrow" style="padding:6px 0 0"><input type="checkbox" data-fid="${l}" ${s==="Yes"?"checked":""}> Yes</label></div>`;default:{const i=t.type==="number"?"number":t.type==="phone"?"tel":t.type==="email"?"email":t.type==="date"?"date":"text";return`<div class="field"><label class="f">${c(t.name)}${e}</label><input type="${i}" data-fid="${l}" value="${c(s)}"${t.type==="number"?' step="any"':""}></div>`}}}function Se(t){if(!S||P!==t.id){if(t.id){const d=V(t.id);S=d?{id:d.id,orderNumber:d.orderNumber,customerData:{...d.customerData},items:d.items.map(a=>({...a})),paymentStatus:d.paymentStatus,sheetRow:d.sheetRow,createdAt:d.createdAt,labelPrinted:d.labelPrinted}:_()}else S=_();P=t.id}const s=S,e=$(),l=s.items.reduce((d,a)=>d+a.price*a.qty,0),i=s.items.map((d,a)=>`<tr>
        <td><div class="strong">${c(d.name)}</div>${d.sku?`<div class="muted" style="font-size:11px">${c(d.sku)}</div>`:""}</td>
        <td class="num"><input class="price-input" type="number" step="any" min="0" data-price="${a}" value="${d.price}"></td>
        <td class="num"><input class="qty-input" type="number" min="1" step="1" data-qty="${a}" value="${d.qty}"></td>
        <td class="num strong" data-line="${a}">${N(d.price*d.qty)}</td>
        <td class="num"><button class="btn small ghost-danger" data-rm="${a}" title="Remove">✕</button></td>
      </tr>`).join("");return{html:`<div class="page-head">
        <div>
          <h2 class="page-title">${s.id?"Edit Order":"New Order"}</h2>
          <div class="page-sub">Order <span class="ordnum">${c(s.orderNumber)}</span>${s.sheetRow?` · updates spreadsheet row ${s.sheetRow}`:""}</div>
        </div>
        <div class="head-actions"><div><label class="f">Order Number</label><input type="text" class="mini-input" data-onum value="${c(s.orderNumber)}" title="You can set a manual order number"></div></div>
      </div>
      <div class="card">
        <div class="card-title">Customer Details</div>
        ${e.length===0?'<div class="muted">No custom fields yet — create them in <b>Custom Fields</b>. They become your spreadsheet columns.</div>':`<div class="fgrid">${e.map(d=>we(d,s.customerData[d.id]||"")).join("")}</div>`}
      </div>
      <div class="card">
        <div class="card-title">Products</div>
        ${s.items.length===0?'<div class="muted" style="margin-bottom:10px">No products added yet.</div>':`<div class="tblwrap" style="border:0;margin-bottom:10px"><table class="tbl items-tbl"><thead><tr><th>Product</th><th class="num">Price (₹)</th><th class="num">Qty</th><th class="num">Total</th><th></th></tr></thead><tbody>${i}</tbody></table></div>`}
        <button class="btn" data-act="addprod">+ Add Product</button>
      </div>
      <div class="card">
        <div class="savebar">
          <div class="paywrap">Payment
            <select data-pay style="width:150px">${te.map(d=>`<option ${d===s.paymentStatus?"selected":""}>${d}</option>`).join("")}</select>
          </div>
          <div class="spacer"></div>
          <div class="totline">Total&nbsp; <b data-total>${N(l)}</b></div>
        </div>
      </div>
      <div class="form-foot">
        <button class="btn" data-act="cancel">Cancel</button>
        <button class="btn primary" data-act="save">${s.id?"Update Order":"Save Order"}</button>
      </div>`,bind(d){const a=S;d.querySelectorAll("[data-fid]").forEach(r=>{const p=r.dataset.fid,n=r.tagName==="SELECT"||r.type==="checkbox"?"change":"input";r.addEventListener(n,()=>{const o=r;a.customerData[p]=o.type==="checkbox"?o.checked?"Yes":"":o.value,o.classList.remove("invalid")})}),d.querySelector("[data-onum]")?.addEventListener("input",r=>{a.orderNumber=r.target.value,d.querySelector(".ordnum").textContent=a.orderNumber}),d.querySelector("[data-pay]")?.addEventListener("change",r=>{a.paymentStatus=r.target.value});const u=r=>{const p=a.items[r],n=d.querySelector(`[data-line="${r}"]`);n&&(n.textContent=N(p.price*p.qty));const o=d.querySelector("[data-total]");o&&(o.textContent=N(a.items.reduce((m,w)=>m+w.price*w.qty,0)))};d.querySelectorAll("[data-qty]").forEach(r=>r.addEventListener("input",()=>{const p=Number(r.dataset.qty);a.items[p].qty=Math.max(1,Math.floor(Number(r.value)||1)),u(p)})),d.querySelectorAll("[data-price]").forEach(r=>r.addEventListener("input",()=>{const p=Number(r.dataset.price);a.items[p].price=Math.max(0,Number(r.value)||0),u(p)})),d.querySelectorAll("[data-rm]").forEach(r=>r.addEventListener("click",()=>{a.items.splice(Number(r.dataset.rm),1),t.rerender()})),d.querySelector('[data-act="addprod"]')?.addEventListener("click",()=>{const r=A().filter(p=>p.active);if(r.length===0){h("No active products. Add some in the Products page first.","err");return}D(`<h3>Add Product</h3>
           <input type="text" placeholder="Search products…" data-search style="margin-bottom:8px">
           <div class="plist" data-list></div>
           <div class="row"><button class="btn" data-close>Close</button></div>`,(p,n)=>{const o=p.querySelector("[data-list]"),m=p.querySelector("[data-search]"),w=()=>{const E=m.value.trim().toLowerCase(),b=r.filter(v=>!E||v.name.toLowerCase().includes(E)||v.sku.toLowerCase().includes(E));o.innerHTML=b.length===0?'<div class="muted" style="padding:10px">No products found.</div>':b.map(v=>{const g=a.items.some(f=>f.productId===v.id);return`<button data-pid="${v.id}" ${g?"disabled":""}><span class="strong">${c(v.name)}</span><span class="muted">${c(v.sku)}</span><span class="p-price">${N(v.price)}</span></button>`}).join("")};w(),m.addEventListener("input",w),m.focus(),o.addEventListener("click",E=>{const b=E.target.closest("[data-pid]");if(!b||b.hasAttribute("disabled"))return;const v=r.find(g=>g.id===b.dataset.pid);a.items.push({productId:v.id,name:v.name,sku:v.sku,price:v.price,qty:1}),n(),t.rerender()}),p.querySelector("[data-close]").addEventListener("click",n)})}),d.querySelector('[data-act="cancel"]')?.addEventListener("click",()=>{S=null,P=null,t.go("orders")}),d.querySelector('[data-act="save"]')?.addEventListener("click",()=>void ke(t,d))}}}async function ke(t,s){const e=S,l=$(),i=[];e.orderNumber.trim()||i.push("Order number is required.");for(const n of l){const o=(e.customerData[n.id]||"").trim(),m=s.querySelector(`[data-fid="${n.id}"]`);n.required&&!o?(i.push(`${n.name} is required.`),m?.classList.add("invalid")):o&&n.type==="phone"&&!ae(o)?(i.push(`${n.name}: enter a valid phone number.`),m?.classList.add("invalid")):o&&n.type==="email"&&!se(o)?(i.push(`${n.name}: enter a valid email address.`),m?.classList.add("invalid")):o&&n.type==="number"&&Number.isNaN(Number(o))&&(i.push(`${n.name} must be a number.`),m?.classList.add("invalid"))}e.items.length===0&&i.push("Add at least one product.");for(const n of e.items)(!(n.qty>=1)||!Number.isInteger(n.qty))&&i.push(`Quantity for ${n.name} must be a whole number (at least 1).`),n.price>=0||i.push(`Price for ${n.name} is invalid.`);if(i.length>0){h(i[0],"err");return}const d=de(e.orderNumber);if(d&&d.id!==e.id){D(`<h3>Order already exists.</h3>
       <p class="muted" style="margin:0"><b>${c(e.orderNumber)}</b> already exists on this device.</p>
       <div class="row" style="justify-content:flex-start">
         <button class="btn" data-open>Open Order</button>
         <button class="btn" data-edit>Edit Order</button>
         <button class="btn" data-x>Cancel</button>
       </div>`,(n,o)=>{n.querySelector("[data-open]").addEventListener("click",()=>{S=null,P=null,o(),t.go("label",d.id)}),n.querySelector("[data-edit]").addEventListener("click",()=>{S=null,P=null,o(),t.go("new",d.id)}),n.querySelector("[data-x]").addEventListener("click",o)});return}if(!e.id&&y().sheetId)try{if(await ne(e.orderNumber.trim())){D(`<h3>Order already exists.</h3>
           <p class="muted" style="margin:0"><b>${c(e.orderNumber)}</b> is already used in your spreadsheet.</p>
           <div class="row" style="justify-content:flex-start">
             <button class="btn primary" data-next>Use Next Number</button>
             <button class="btn" data-x>Cancel</button>
           </div>`,(n,o)=>{n.querySelector("[data-next]").addEventListener("click",async()=>{o(),await H(),e.orderNumber=B();const m=s.querySelector("[data-onum]");m&&(m.value=e.orderNumber);const w=s.querySelector(".ordnum");w&&(w.textContent=e.orderNumber),h(`Switched to ${e.orderNumber}.`)}),n.querySelector("[data-x]").addEventListener("click",o)});return}}catch(n){h(R(n),"err");return}const a=new Date().toISOString(),u={id:e.id||z("o_"),orderNumber:e.orderNumber.trim(),customerData:{...e.customerData},items:e.items.map(n=>({...n})),paymentStatus:e.paymentStatus,total:e.items.reduce((n,o)=>n+o.price*o.qty,0),createdAt:e.createdAt||a,updatedAt:a,labelPrinted:e.labelPrinted||!1,sheetRow:e.sheetRow},r=!e.id;await Y(u);let p="";if(y().sheetId)try{u.sheetRow=await ie(u),await Y(u)}catch(n){p=R(n)}r&&e.orderNumber===B()&&await H(),S=null,P=null,h(r?"Order saved successfully.":"Order updated successfully.","ok"),p&&h("Saved on this device. Google Sheets: "+p,"err"),t.go("orders")}function qe(t){const s=J(),e=new Date().toDateString(),l=a=>s.filter(a).length,i=[["Today's Orders",l(a=>new Date(a.createdAt).toDateString()===e)],["Pending Labels",l(a=>!a.labelPrinted)],["Paid Orders",l(a=>a.paymentStatus==="Paid")],["COD Orders",l(a=>a.paymentStatus==="COD")]],d=s.slice(0,5);return{html:`<div class="page-head">
        <div><h2 class="page-title">Dashboard</h2><div class="page-sub">Overview of your orders</div></div>
        <div class="head-actions">
          <button class="btn primary" data-act="new">+ New Order</button>
          <button class="btn" data-act="orders">Orders</button>
          <button class="btn" data-act="settings">Settings</button>
        </div>
      </div>
      <div class="stats">${i.map(([a,u])=>`<div class="stat"><div class="v">${u}</div><div class="l">${a}</div></div>`).join("")}</div>
      <div class="card">
        <div class="card-title">Recent Orders</div>
        ${d.length===0?'<div class="empty">No orders yet.<br><button class="btn primary" data-act="new">+ New Order</button></div>':`<div class="tblwrap" style="border:0"><table class="tbl"><thead><tr><th>Order</th><th>Customer</th><th class="num">Amount</th><th>Payment</th><th></th></tr></thead><tbody>${d.map(a=>`<tr>
                    <td class="strong nowrap">${c(a.orderNumber)}</td>
                    <td class="ellip">${c(le(a))}</td>
                    <td class="num strong nowrap">${N(a.total)}</td>
                    <td><span class="badge ${a.paymentStatus}">${a.paymentStatus}</span></td>
                    <td class="num"><button class="btn small" data-label="${a.id}">Label</button></td>
                  </tr>`).join("")}</tbody></table></div>`}
      </div>`,bind(a){a.querySelectorAll('[data-act="new"]').forEach(u=>u.addEventListener("click",()=>{ee(),t.go("new")})),a.querySelector('[data-act="orders"]')?.addEventListener("click",()=>t.go("orders")),a.querySelector('[data-act="settings"]')?.addEventListener("click",()=>t.go("settings")),a.querySelectorAll("[data-label]").forEach(u=>u.addEventListener("click",()=>t.go("label",u.dataset.label)))}}}function Ee(t){const s=A();return{html:`<div class="page-head">
        <div><h2 class="page-title">Products</h2><div class="page-sub">Select these while creating an order</div></div>
        <div class="head-actions"><button class="btn primary" data-act="add">+ Add Product</button></div>
      </div>
      ${s.length===0?'<div class="card"><div class="empty">No products yet.<br><button class="btn primary" data-act="add">+ Add Product</button></div></div>':`<div class="tblwrap"><table class="tbl">
        <thead><tr><th>Name</th><th>SKU</th><th class="num">Price</th><th>Active</th><th></th></tr></thead>
        <tbody>${s.map(e=>`<tr>
          <td class="strong">${c(e.name)}</td>
          <td class="muted">${c(e.sku)}</td>
          <td class="num strong nowrap">${N(e.price)}</td>
          <td><label class="switch"><input type="checkbox" data-toggle="${e.id}" ${e.active?"checked":""}><i></i></label></td>
          <td><div class="rowbtns">
            <button class="btn small" data-edit="${e.id}">Edit</button>
            <button class="btn small ghost-danger" data-del="${e.id}">Delete</button>
          </div></td>
        </tr>`).join("")}</tbody></table></div>`}`,bind(e){e.querySelectorAll('[data-act="add"]').forEach(l=>l.addEventListener("click",()=>void K(null,t))),e.querySelectorAll("[data-toggle]").forEach(l=>l.addEventListener("change",async()=>{const i=l.dataset.toggle,d=l.checked;await j(A().map(a=>a.id===i?{...a,active:d}:a))})),e.querySelectorAll("[data-edit]").forEach(l=>l.addEventListener("click",()=>{const i=A().find(d=>d.id===l.dataset.edit);i&&K(i,t)})),e.querySelectorAll("[data-del]").forEach(l=>l.addEventListener("click",async()=>{const i=A().find(a=>a.id===l.dataset.del);!i||!await Q("Delete product?",`<b>${c(i.name)}</b> will be removed from the product list. Existing orders are not affected.`,"Delete")||(await j(A().filter(a=>a.id!==i.id)),h("Product deleted."),t.rerender())}))}}}async function K(t,s){D(`<h3>${t?"Edit Product":"Add Product"}</h3>
     <div class="fgrid">
       <div class="field span2"><label class="f">Name <span class="req">*</span></label><input type="text" data-n value="${c(t?.name||"")}"></div>
       <div class="field"><label class="f">SKU</label><input type="text" data-s value="${c(t?.sku||"")}"></div>
       <div class="field"><label class="f">Price (₹)</label><input type="number" step="any" min="0" data-p value="${t?.price??0}"></div>
     </div>
     <label class="checkrow"><input type="checkbox" data-a ${t?.active??!0?"checked":""}> Active (selectable in orders)</label>
     <div class="row"><button class="btn" data-x>Cancel</button><button class="btn primary" data-save>Save</button></div>`,(e,l)=>{e.querySelector("[data-x]").addEventListener("click",l),e.querySelector("[data-save]").addEventListener("click",async()=>{const i=e.querySelector("[data-n]").value.trim(),d=e.querySelector("[data-s]").value.trim(),a=Math.max(0,Number(e.querySelector("[data-p]").value)||0),u=e.querySelector("[data-a]").checked;if(!i){e.querySelector("[data-n]").classList.add("invalid"),h("Product name is required.","err");return}const r=A();t?await j(r.map(p=>p.id===t.id?{...p,name:i,sku:d,price:a,active:u}:p)):await j([...r,{id:z("p_"),name:i,sku:d,price:a,active:u}]),l(),h("Product saved.","ok"),s.rerender()})})}function xe(t){const s=$();return{html:`<div class="page-head">
        <div><h2 class="page-title">Custom Fields</h2><div class="page-sub">Each field becomes a spreadsheet column — every order fills one row</div></div>
        <div class="head-actions"><button class="btn primary" data-act="add">+ Add Field</button></div>
      </div>
      <div class="card">
        ${s.length===0?'<div class="empty">No fields yet. Add fields like Customer Name, Phone, Address, City…<br><button class="btn primary" data-act="add">+ Add Field</button></div>':`<div>${s.map((e,l)=>`<div class="list-row">
              <span class="muted nowrap" style="font-size:11px">${l+1}.</span>
              <div class="grow"><span class="name">${c(e.name)}</span>${e.required?' <span class="req" style="color:var(--danger);font-weight:800">*</span>':""}</div>
              <span class="type-badge">${e.type}</span>
              <label class="switch" title="Required"><input type="checkbox" data-req="${e.id}" ${e.required?"checked":""}><i></i></label>
              <button class="btn small icon" data-up="${e.id}" ${l===0?"disabled":""} title="Move up">↑</button>
              <button class="btn small icon" data-down="${e.id}" ${l===s.length-1?"disabled":""} title="Move down">↓</button>
              <button class="btn small" data-edit="${e.id}">Edit</button>
              <button class="btn small ghost-danger" data-del="${e.id}">Delete</button>
            </div>`).join("")}</div>`}
        <div class="hint">Reorder with ↑ ↓ — the order here is the order in the order form and on the label.</div>
      </div>`,bind(e){e.querySelector('[data-act="add"]')?.addEventListener("click",()=>void W(null,t)),e.querySelectorAll("[data-req]").forEach(i=>i.addEventListener("change",async()=>{const d=i.dataset.req,a=i.checked;await I($().map(u=>u.id===d?{...u,required:a}:u))}));const l=async(i,d)=>{const a=$(),u=a.findIndex(p=>p.id===i),r=u+d;u<0||r<0||r>=a.length||([a[u],a[r]]=[a[r],a[u]],await I(a.map((p,n)=>({...p,order:n}))),t.rerender())};e.querySelectorAll("[data-up]").forEach(i=>i.addEventListener("click",()=>void l(i.dataset.up,-1))),e.querySelectorAll("[data-down]").forEach(i=>i.addEventListener("click",()=>void l(i.dataset.down,1))),e.querySelectorAll("[data-edit]").forEach(i=>i.addEventListener("click",()=>{const d=$().find(a=>a.id===i.dataset.edit);d&&W(d,t)})),e.querySelectorAll("[data-del]").forEach(i=>i.addEventListener("click",async()=>{const d=$().find(r=>r.id===i.dataset.del);if(!d||!await Q("Delete field?",`<b>${c(d.name)}</b> will be removed from the order form. Existing orders keep their data, and the spreadsheet column is never deleted.`,"Delete"))return;const u=$().filter(r=>r.id!==d.id);await I(u.map((r,p)=>({...r,order:p}))),h("Field deleted."),t.rerender()}))}}}async function W(t,s){D(`<h3>${t?"Edit Field":"Add Field"}</h3>
     <div class="fgrid">
       <div class="field span2"><label class="f">Field name <span class="req">*</span></label><input type="text" data-n value="${c(t?.name||"")}" placeholder="e.g. Customer Name"></div>
       <div class="field"><label class="f">Type</label><select data-t>${re.map(([e,l])=>`<option value="${e}" ${t?.type===e?"selected":""}>${l}</option>`).join("")}</select></div>
       <div class="field"><label class="f">Required</label><label class="checkrow" style="padding:6px 0 0"><input type="checkbox" data-r ${t?.required?"checked":""}> Must be filled</label></div>
       <div class="field span2" data-optwrap style="display:${t?.type==="dropdown"?"block":"none"}"><label class="f">Dropdown options <span class="muted">(one per line)</span></label><textarea rows="3" data-o>${c((t?.options||[]).join(`
`))}</textarea></div>
     </div>
     <div class="hint">Field names become spreadsheet column headers. Existing orders are never affected by changes here.</div>
     <div class="row"><button class="btn" data-x>Cancel</button><button class="btn primary" data-save>Save Field</button></div>`,(e,l)=>{const i=e.querySelector("[data-t]");i.addEventListener("change",()=>{e.querySelector("[data-optwrap]").style.display=i.value==="dropdown"?"block":"none"}),e.querySelector("[data-x]").addEventListener("click",l),e.querySelector("[data-save]").addEventListener("click",async()=>{const d=e.querySelector("[data-n]"),a=d.value.trim(),u=i.value,r=e.querySelector("[data-r]").checked,p=e.querySelector("[data-o]").value.split(`
`).map(m=>m.trim()).filter(Boolean);if(!a){d.classList.add("invalid"),h("Field name is required.","err");return}if(u==="dropdown"&&p.length===0){h("Add at least one dropdown option.","err");return}if($().find(m=>m.name.trim().toLowerCase()===a.toLowerCase()&&m.id!==t?.id)){d.classList.add("invalid"),h("A field with this name already exists.","err");return}const o=$();t?await I(o.map(m=>m.id===t.id?{...m,name:a,type:u,required:r,options:u==="dropdown"?p:void 0}:m)):await I([...o,{id:z("f_"),name:a,type:u,required:r,options:u==="dropdown"?p:void 0,order:o.length}]),l(),h("Field saved.","ok"),s.rerender()})})}const C={signedIn:!1};function Le(t){const s=y(),e=$(),l=ce(),i=!!s.sheetId,d=n=>s.labelFields===null?!0:s.labelFields.includes(n),a=e.map(n=>`<label class="checkrow"><input type="checkbox" data-lf="${n.id}" ${d(n.id)?"checked":""}> ${c(n.name)}</label>`).join(""),r=[["orderNumber","Order Number"],["products","Products"],["quantity","Quantity"],["payment","Payment Status"],["amount","Amount"],["gst","Business GST"],["barcode","Barcode"]].map(([n,o])=>`<label class="checkrow"><input type="checkbox" data-ex="${n}" ${s.labelExtras[n]?"checked":""}> ${o}</label>`).join(""),p=i?`<div class="card-sub" style="margin-top:12px">Column mapping — fields reuse matching columns automatically. Map a field to a different existing column if needed.</div>
       ${e.length===0?'<div class="muted" style="font-size:12px">No custom fields to map.</div>':e.map(n=>{const o=s.customMap[n.id]||"";return`<div class="map-row"><div class="strong">${c(n.name)}</div><select data-map="${n.id}"><option value="">Auto${o?"":" (matched)"}</option>${l.map(m=>`<option value="${c(m)}" ${o===m?"selected":""}>${c(m)}</option>`).join("")}</select></div>`}).join("")}`:"";return{html:`<div class="page-head">
        <div><h2 class="page-title">Settings</h2><div class="page-sub">Changes are saved automatically</div></div>
      </div>

      <div class="card">
        <div class="card-title">Business</div>
        <div class="set-grid">
          <div class="field"><label class="f">Business Name</label><input type="text" data-k="businessName" value="${c(s.businessName)}"></div>
          <div class="field"><label class="f">Phone</label><input type="text" data-k="phone" value="${c(s.phone)}"></div>
          <div class="field"><label class="f">Website</label><input type="text" data-k="website" value="${c(s.website)}"></div>
          <div class="field"><label class="f">GST</label><input type="text" data-k="gst" value="${c(s.gst)}"></div>
          <div class="field span2"><label class="f">Address</label><textarea rows="2" data-k="address">${c(s.address)}</textarea></div>
          <div class="field span2"><label class="f">Label Footer</label><input type="text" data-k="footer" value="${c(s.footer)}" placeholder="Thank you for your order!"></div>
          <div class="field span2"><label class="f">Logo</label>
            <div class="logo-row">
              ${s.logo?`<img src="${s.logo}" alt="logo">`:""}
              <button class="btn small" data-act="logo">${s.logo?"Change Logo":"Upload Logo"}</button>
              ${s.logo?'<button class="btn small ghost-danger" data-act="logorm">Remove</button>':""}
              <input type="file" accept="image/*" data-logo hidden>
            </div>
            <div class="hint">Shown on the shipping label. PNG/JPG, up to ~300 KB.</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Google Sheets</div>
        <div class="toolbar" style="margin-bottom:8px">
          <span class="dot ${C.signedIn?"on":""}" data-gdot></span>
          <span class="count" data-gstatus>${i?`Spreadsheet connected: ${s.sheetName||"…"}`:C.signedIn?"Google account connected":"Not connected"}</span>
          <span class="spacer"></span>
          <button class="btn small" data-act="gdisconnect" ${C.signedIn||i?"":"disabled"}>Disconnect</button>
        </div>
        <div class="set-grid">
          <div class="field span2"><label class="f">Spreadsheet URL or ID</label><input type="text" data-sheetref value="${c(s.sheetId)}" placeholder="https://docs.google.com/spreadsheets/d/…"></div>
          <div class="field"><label class="f">Worksheet</label><select data-ws ${i?"":"disabled"}><option value="${c(s.sheetName)}">${c(s.sheetName||"—")}</option></select></div>
          <div class="field"><label class="f">&nbsp;</label><button class="btn" data-act="use" style="width:100%">${i?"Re-read Connection":"Connect Spreadsheet"}</button></div>
        </div>
        <div class="field" style="margin-top:4px"><label class="f">Google OAuth Client ID</label><input type="text" data-k="clientId" value="${c(s.clientId)}" placeholder="xxxxxxxx.apps.googleusercontent.com"></div>
        <details class="help">
          <summary>One-time setup: how to get a Client ID (free, ~2 minutes)</summary>
          <ol>
            <li>Open <b>console.cloud.google.com</b> → create/select a project.</li>
            <li><b>APIs &amp; Services → Library</b> → enable <b>Google Sheets API</b>.</li>
            <li><b>OAuth consent screen</b> → External → add yourself as a <b>test user</b>.</li>
            <li><b>Credentials → Create credentials → OAuth client ID</b> → type <b>Web application</b>.</li>
            <li>Add this <b>Authorized redirect URI</b>: <code>${c(chrome?.identity?.getRedirectURL?chrome.identity.getRedirectURL():"chrome-extension://EXTENSION_ID.chromiumapp.org/")}</code></li>
            <li>Copy the <b>Client ID</b> and paste it above, then click <b>Connect Spreadsheet</b>.</li>
          </ol>
        </details>
        ${p}
      </div>

      <div class="card">
        <div class="card-title">Orders</div>
        <div class="set-grid">
          <div class="field"><label class="f">Order Prefix</label><input type="text" data-k="orderPrefix" value="${c(s.orderPrefix)}"></div>
          <div class="field"><label class="f">Starting Number</label><input type="number" min="1" step="1" data-k="nextNumber" value="${s.nextNumber}"></div>
        </div>
        <div class="hint">New orders get <b>${c(s.orderPrefix)}${s.nextNumber}</b>. You can always type a manual order number.</div>
      </div>

      <div class="card">
        <div class="card-title">Label</div>
        <div class="set-grid">
          <div class="field"><label class="f">Label Size</label>
            <select data-k="labelSize">
              <option value="4x6" ${s.labelSize==="4x6"?"selected":""}>4 × 6 inch (default)</option>
              <option value="a6" ${s.labelSize==="a6"?"selected":""}>A6 (105 × 148 mm)</option>
            </select>
          </div>
          <div class="field"><label class="f">Text Size</label>
            <select data-k="labelFontScale">
              <option value="0.9" ${s.labelFontScale===.9?"selected":""}>Small</option>
              <option value="1" ${s.labelFontScale===1?"selected":""}>Normal</option>
              <option value="1.1" ${s.labelFontScale===1.1?"selected":""}>Large</option>
              <option value="1.25" ${s.labelFontScale===1.25?"selected":""}>Extra Large</option>
            </select>
          </div>
        </div>
        <div class="card-sub" style="margin-top:12px">Customer fields shown on the label</div>
        ${e.length===0?'<div class="muted" style="font-size:12px">No custom fields yet.</div>':`<div style="columns:2;gap:24px">${a}</div>`}
        <div class="card-sub" style="margin-top:12px">Label sections</div>
        <div style="columns:2;gap:24px">${r}</div>
      </div>

      <div class="card">
        <div class="card-title">Backup</div>
        <div class="toolbar">
          <button class="btn" data-act="export">Export Orders</button>
          <button class="btn" data-act="import">Import Settings</button>
          <span class="count">Exports include orders, fields, products and settings as JSON.</span>
        </div>
        <input type="file" accept="application/json" data-importfile hidden>
      </div>`,async bind(n){const o=y();n.querySelectorAll("[data-k]").forEach(b=>{const v=b.dataset.k;b.addEventListener("change",async()=>{let f=b.value;v==="nextNumber"&&(f=Math.max(1,Math.floor(Number(f)||1))),v==="labelFontScale"&&(f=Number(f)||1),await k({...y(),[v]:f}),h("Saved.")})});const m=n.querySelector("[data-logo]");n.querySelector('[data-act="logo"]')?.addEventListener("click",()=>m.click()),m?.addEventListener("change",()=>{const b=m.files?.[0];if(!b)return;if(b.size>400*1024){h("Logo is too large — please use an image under 400 KB.","err"),m.value="";return}const v=new FileReader;v.onload=async()=>{await k({...y(),logo:String(v.result)}),h("Logo saved.","ok"),t.rerender()},v.readAsDataURL(b)}),n.querySelector('[data-act="logorm"]')?.addEventListener("click",async()=>{await k({...y(),logo:""}),t.rerender()}),X().then(b=>{C.signedIn=b;const v=n.querySelector("[data-gdot]"),g=n.querySelector("[data-gstatus]");v&&(v.className="dot "+(b?"on":"")),g&&!y().sheetId&&(g.textContent=b?"Google account connected":"Not connected")}).catch(()=>{}),n.querySelector('[data-act="use"]')?.addEventListener("click",()=>void Ne(t,n)),n.querySelector('[data-act="gdisconnect"]')?.addEventListener("click",()=>void Pe(t));const w=n.querySelector("[data-ws]");w?.addEventListener("change",()=>void Ae(t,w.value)),n.querySelectorAll("[data-map]").forEach(b=>b.addEventListener("change",async()=>{const v=b.dataset.map,g=b.value,f={...y().customMap};g?f[v]=g:delete f[v],await k({...y(),customMap:f}),h("Column mapping saved.","ok")})),n.querySelectorAll("[data-lf]").forEach(b=>b.addEventListener("change",async()=>{const v=b.dataset.lf,g=b.checked,f=$().map(G=>G.id),U=(o.labelFields===null?[...f]:[...o.labelFields]).filter(G=>G!==v);g&&U.push(v),await k({...y(),labelFields:U})})),n.querySelectorAll("[data-ex]").forEach(b=>b.addEventListener("change",async()=>{const v=b.dataset.ex,g=b.checked,f={...y().labelExtras,[v]:g};await k({...y(),labelExtras:f})})),n.querySelector('[data-act="export"]')?.addEventListener("click",()=>{oe(),h("Backup exported.","ok")});const E=n.querySelector("[data-importfile]");n.querySelector('[data-act="import"]')?.addEventListener("click",()=>E.click()),E?.addEventListener("change",()=>{const b=E.files?.[0];b&&ue(b).then(()=>{h("Settings imported.","ok"),t.rerender()}).catch(v=>h("Import failed: "+(v instanceof Error?v.message:"invalid file"),"err"))})}}}async function Ne(t,s){const e=y(),l=s.querySelector("[data-sheetref]"),i=l.value.trim();if(!e.clientId.trim()){h("Add your Google OAuth Client ID first (see the steps below the field).","err");return}if(!i){l.classList.add("invalid"),h("Paste your Google Sheets link or spreadsheet ID.","err");return}const d=pe(i);try{await k({...y(),clientId:e.clientId.trim()}),await ve();const a=await be(d);if(a.sheets.length===0)throw new Error("This spreadsheet has no worksheets.");const u=a.sheets[0];F([]);const r=await Z(d,u);await k({...y(),sheetId:d,sheetName:u}),F(r),await me(J().map(p=>({...p,sheetRow:void 0}))),C.signedIn=!0,h(`Connected. ${r.length} columns ready (${he.length} standard + your fields).`,"ok"),t.rerender()}catch(a){h(R(a),"err")}}async function Ae(t,s){const e=y();if(!(!e.sheetId||!s))try{F([]);const l=await Z(e.sheetId,s);await k({...y(),sheetName:s}),F(l),h(`Worksheet switched to "${s}".`,"ok"),t.rerender()}catch(l){h(R(l),"err")}}async function Pe(t){try{await ye()}catch{}await k({...y(),sheetId:"",sheetName:""}),F([]),C.signedIn=!1,h("Disconnected from Google Sheets."),t.rerender()}const L=document.getElementById("app"),Oe=[["dashboard","Dashboard",x.dash],["new","New Order",x.plus],["orders","Orders",x.list],["products","Products",x.box],["fields","Custom Fields",x.sliders],["settings","Settings",x.gear]];let O="dashboard",q=null;const M={get route(){return O},get id(){return q},go(t,s=null){O=t,q=s??null;const e=t==="new"?q?`#edit=${q}`:"#new":t==="label"&&q?`#label=${q}`:"";try{history.replaceState(null,"",e||location.pathname)}catch{}T()},rerender(){T()}},Ce={dashboard:qe,new:Se,orders:t=>$e(t,!1),products:Ee,fields:xe,settings:Le};function Ie(){if(O==="label"){const t=q?V(q):void 0;if(t)return ge(t,()=>M.go("orders"),()=>T());O="orders",q=null}return Ce[O](M)}function T(){const t=Ie();L.innerHTML=`
    <header class="top">
      <div class="brand">${x.tag} Order Label Manager</div>
      <div class="spacer"></div>
      <button class="conn" data-conn title="Google Sheets connection status — click to open Settings"><span class="dot" data-gdot></span><span data-gtxt>Google</span></button>
      <button class="btn small" data-opentab title="Open all orders in a full browser tab">Orders ${x.external}</button>
    </header>
    <nav class="tabs">${Oe.map(([e,l,i])=>`<button data-route="${e}" class="${O===e?"active":""}">${i} ${l}</button>`).join("")}</nav>
    <main class="content"></main>`;const s=L.querySelector("main.content");s.innerHTML=t.html,L.querySelectorAll("[data-route]").forEach(e=>e.addEventListener("click",()=>{const l=e.dataset.route;l==="new"&&ee(),M.go(l)})),L.querySelector("[data-opentab]")?.addEventListener("click",()=>window.open(chrome.runtime.getURL("orders.html"))),L.querySelector("[data-conn]")?.addEventListener("click",()=>M.go("settings")),X().then(e=>{const l=L.querySelector("[data-gdot]"),i=L.querySelector("[data-gtxt]");l&&(l.className="dot "+(e?"on":"")),i&&(i.textContent=e?"Google connected":"Google")}).catch(()=>{}),t.bind?.(s)}function De(){const t=location.hash.replace(/^#/,""),[s,e]=t.split("=");return s==="edit"&&e?{route:"new",id:e}:s==="label"&&e?{route:"label",id:e}:s==="new"?{route:"new",id:null}:{route:"dashboard",id:null}}function Fe(){return new Promise(t=>{try{chrome.windows.getCurrent(s=>t(s.type==="normal"))}catch{t(!1)}})}async function Re(){await fe();const t=De();O=t.route,q=t.id,document.documentElement.classList.toggle("as-page",await Fe()),T()}Re();
