(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))o(a);new MutationObserver(a=>{for(const r of a)if(r.type==="childList")for(const d of r.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&o(d)}).observe(document,{childList:!0,subtree:!0});function n(a){const r={};return a.integrity&&(r.integrity=a.integrity),a.referrerPolicy&&(r.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?r.credentials="include":a.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function o(a){if(a.ep)return;a.ep=!0;const r=n(a);fetch(a.href,r)}})();const ot={businessName:"My Business",logo:"",phone:"",address:"",website:"",gst:"",footer:"",orderPrefix:"ORD-",nextNumber:1001,labelSize:"4x6",labelFields:null,labelExtras:{orderNumber:!0,products:!0,quantity:!0,payment:!0,amount:!0,gst:!1,barcode:!0},clientId:"",sheetId:"",sheetName:"",customMap:{}},yt=[["text","Text"],["number","Number"],["phone","Phone"],["email","Email"],["textarea","Textarea"],["date","Date"],["dropdown","Dropdown"],["checkbox","Checkbox"]],wt=["Paid","COD","Pending","Failed"],vt="https://www.googleapis.com/auth/spreadsheets";let rt=0;const xt=(t="")=>t+Date.now().toString(36)+(rt++).toString(36)+Math.random().toString(36).slice(2,8),A=t=>"₹"+t.toLocaleString("en-IN"),Wt=()=>{const t=new Date;return t.getFullYear()+"-"+String(t.getMonth()+1).padStart(2,"0")+"-"+String(t.getDate()).padStart(2,"0")},st=t=>t?t.slice(0,10):"",$t=t=>/^[+\d][\d\s-]{5,19}$/.test(t.trim()),St=t=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(t.trim()),m=t=>t.replace(/[&<>"']/g,e=>`&#${e.charCodeAt(0)};`),k=new Map;let E=null;const B=typeof chrome<"u"&&!!chrome.storage?.local;function it(t){return B?(E||(E=new Promise(e=>chrome.storage.local.get(null,n=>{for(const[o,a]of Object.entries(n||{}))k.set(o,a);e()}))),E):Promise.resolve()}function $(t,e){return k.has(t)?k.get(t):e}async function S(t,e){k.set(t,e),B&&await chrome.storage.local.set({[t]:e})}async function dt(t,e,n){const o=e($(t,n));return await S(t,o),o}const y={fields:"fields",products:"products",orders:"orders",settings:"settings",headers:"sheetHeaders"},W=()=>$(y.fields,[]).slice().sort((t,e)=>t.order-e.order),V=()=>$(y.products,[]),C=()=>$(y.orders,[]),x=()=>({...ot,...$(y.settings,{})}),Lt=()=>$(y.headers,[]),_=t=>S(y.fields,t),H=t=>S(y.products,t),G=t=>S(y.settings,t),Mt=t=>S(y.headers,t);async function lt(t){await dt(y.orders,e=>{const n=e.findIndex(o=>o.id===t.id);return n>=0?e[n]=t:e.unshift(t),e},[])}function Pt(t){return C().find(e=>e.id===t)}function Ct(t){const e=t.trim().toLowerCase();return C().find(n=>n.orderNumber.trim().toLowerCase()===e)}function Nt(){const t=x();return t.orderPrefix+t.nextNumber}async function kt(){const t=x();t.nextNumber=Math.max(t.nextNumber+1,1),await G(t)}function F(t){const e=W().find(n=>/name/i.test(n.name));return e&&t.customerData[e.id]||""}function I(t){const e=W().find(n=>n.type==="phone"||/phone|mobile|whatsapp/i.test(n.name));return e&&t.customerData[e.id]||""}async function Et(){await it(),!$("seeded",!1)&&(await S("seeded",!0),W().length===0&&await _([{id:"f_name",name:"Customer Name",type:"text",required:!0,order:0},{id:"f_phone",name:"Phone",type:"phone",required:!0,order:1},{id:"f_address",name:"Address",type:"textarea",required:!1,order:2},{id:"f_city",name:"City",type:"text",required:!1,order:3},{id:"f_state",name:"State",type:"text",required:!1,order:4},{id:"f_pincode",name:"Pincode",type:"number",required:!1,order:5}]),V().length===0&&await H([{id:"p_night",name:"Night Cream",sku:"NC-01",price:499,active:!0},{id:"p_serum",name:"Face Serum",sku:"FS-02",price:699,active:!0},{id:"p_day",name:"Day Cream",sku:"DC-03",price:599,active:!0}]))}function Ot(){const t={exportedAt:new Date().toISOString(),fields:W(),products:V(),orders:C(),settings:x()},e=URL.createObjectURL(new Blob([JSON.stringify(t,null,2)],{type:"application/json"})),n=document.createElement("a");n.href=e,n.download="order-label-manager-backup.json",n.click(),setTimeout(()=>URL.revokeObjectURL(e),5e3)}function At(t){return t.text().then(async e=>{const n=JSON.parse(e);Array.isArray(n.fields)&&await _(n.fields),Array.isArray(n.products)&&await H(n.products),Array.isArray(n.orders)&&await S(y.orders,n.orders),n.settings&&await G({...x(),...n.settings})})}const v=t=>`<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${t}</svg>`,N={tag:'<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.41 11.58l-9-9A2 2 0 0 0 11 2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 .59 1.42l9 9a2 2 0 0 0 2.82 0l7-7a2 2 0 0 0 0-2.84zM7.5 9.5A1.75 1.75 0 1 1 9.25 7.75 1.75 1.75 0 0 1 7.5 9.5z"/></svg>',dash:v('<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>'),plus:v('<path d="M12 5v14M5 12h14"/>'),list:v('<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>'),box:v('<path d="M21 8l-9-5-9 5v8l9 5 9-5V8z"/><path d="M3 8l9 5 9-5M12 13v8"/>'),sliders:v('<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>'),gear:v('<circle cx="12" cy="12" r="3.2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1"/>'),print:v('<path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8" rx="1"/>'),download:v('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>'),edit:v('<path d="M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/>'),external:v('<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"/>')},D=t=>t instanceof Error?t.message:String(t);function M(t,e=""){let n=document.getElementById("toasts");n||(n=document.createElement("div"),n.id="toasts",document.body.appendChild(n));const o=document.createElement("div");o.className="toast "+e,o.textContent=t,n.appendChild(o),setTimeout(()=>{o.style.transition="opacity .25s",o.style.opacity="0",setTimeout(()=>o.remove(),260)},e==="err"?5200:2600)}function ct(t,e){const n=document.createElement("div");n.className="modal-wrap",n.innerHTML=`<div class="modal">${t}</div>`;const o=()=>n.remove();n.addEventListener("mousedown",r=>{r.target===n&&o()}),document.body.appendChild(n);const a=n.querySelector(".modal");return e?.(a,o),{close:o,el:a}}function Dt(t,e,n,o=!0){return new Promise(a=>{ct(`<h3>${t}</h3><p class="muted" style="margin:0 0 4px">${e}</p>
       <div class="row"><button class="btn" data-x>Cancel</button><button class="btn ${o?"danger":"primary"}" data-ok>${n}</button></div>`,(r,d)=>{r.querySelector("[data-x]").addEventListener("click",()=>{d(),a(!1)}),r.querySelector("[data-ok]").addEventListener("click",()=>{d(),a(!0)})})})}const pt={0:"nnnWWnWnn",1:"WnnWnnnnW",2:"nnWWnnnnW",3:"WnWWnnnnn",4:"nnnWWnnnW",5:"WnnWWnnnn",6:"nnWWWnnnn",7:"nnnWnnWnW",8:"WnnWnnWnn",9:"nnWWnnWnn",A:"WnnnnWnnW",B:"nnWnnWnnW",C:"WnWnnWnnn",D:"nnnnWWnnW",E:"WnnnWWnnn",F:"nnWnWWnnn",G:"nnnnnWWnW",H:"WnnnnWWnn",I:"nnWnnWWnn",J:"nnnnWWWnn",K:"WnnnnnnWW",L:"nnWnnnnWW",M:"WnWnnnnWn",N:"nnnnWnnWW",O:"WnnnWnnWn",P:"nnWnWnnWn",Q:"nnnnnnWWW",R:"WnnnnnWWn",S:"nnWnnnWWn",T:"nnnnWnWWn",U:"WWnnnnnnW",V:"nWWnnnnnW",W:"WWWnnnnnn",X:"nWnnWnnnW",Y:"WWnnWnnnn",Z:"nWWnWnnnn","-":"nWnnnnWnW",".":"WWnnnnWnn"," ":"nWWnnnWnn",$:"nWnWnWnnn","/":"nWnWnnnWn","+":"nWnnnWnWn","%":"nnnWnWnWn","*":"nWnnWnWnn"};function ut(t,e=40,n=2,o=4){const a=t.toUpperCase().replace(/[^0-9A-Z\-. $/+%]/g,"");if(!a)return"";let r=0,d="";const s="*"+a+"*";for(const c of s){const l=pt[c];if(l){for(let u=0;u<9;u++){const p=l[u]==="W"?n*3:n;u%2===0&&(d+=`<rect x="${r}" y="0" width="${p}" height="${e}" fill="#000"/>`),r+=p}r+=o}}return`<svg class="barcode" viewBox="0 0 ${r-o} ${e}" width="${r-o}" height="${e}" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="barcode ${mt(a)}">${d}</svg>`}function mt(t){return t.replace(/[&<>"]/g,e=>`&#${e.charCodeAt(0)};`)}const j=`
.label{width:384px;height:576px;background:#fff;color:#0F172A;padding:20px 22px;display:flex;flex-direction:column;box-sizing:border-box;overflow:hidden;font-family:InterVariable,Inter,system-ui,-apple-system,sans-serif}
.label.a6{width:397px;height:559px;padding:16px 18px}
.l-top{display:flex;justify-content:space-between;align-items:flex-start;gap:8px}
.l-brand{display:flex;gap:9px;align-items:center;min-width:0}
.l-logo{width:42px;height:42px;object-fit:contain;border-radius:8px;flex:none}
.l-biz{font-size:16.5px;font-weight:800;letter-spacing:-.01em;line-height:1.15;word-break:break-word}
.l-sub{font-size:9.5px;color:#5a6b85;margin-top:2px}
.l-onum{text-align:right;flex:none}
.l-on{font-size:15px;font-weight:800;color:#F66916;white-space:nowrap}
.l-od{font-size:9.5px;color:#5a6b85;margin-top:2px}
.l-rule{height:2.5px;background:#0F172A;border-radius:2px;margin:10px 0}
.l-chip{display:inline-block;font-size:8.5px;font-weight:800;letter-spacing:.12em;background:#F1F5F9;color:#334155;padding:3px 8px;border-radius:4px}
.l-addr{margin-top:7px;font-size:11.5px;line-height:1.5}
.l-cname{font-size:16px;font-weight:800;margin-bottom:2px}
.l-lab{color:#5a6b85;font-weight:600}
.l-items{width:100%;border-collapse:collapse;margin-top:12px}
.l-items th{font-size:8.5px;text-transform:uppercase;letter-spacing:.08em;color:#5a6b85;text-align:left;padding:4px 0;border-bottom:1px solid #e3e9f2;font-weight:700}
.l-items td{font-size:11px;padding:5px 0;border-bottom:1px solid #eef2f7}
.l-items .r,.l-items th.r{text-align:right}
.l-bottom{margin-top:auto}
.l-totrow{display:flex;justify-content:space-between;align-items:center;gap:10px;padding-top:10px}
.l-pay{display:inline-block;font-size:10px;font-weight:800;letter-spacing:.06em;border:1.5px solid currentColor;border-radius:5px;padding:2px 8px}
.l-pay.b-paid{color:#15803d}.l-pay.b-cod{color:#c2540a}.l-pay.b-pending{color:#a16207}.l-pay.b-failed{color:#b91c1c}
.l-amt{font-size:12px;color:#334155}.l-amt b{font-size:14.5px;color:#0F172A}
.l-gst{font-size:9.5px;color:#5a6b85;margin-top:6px}
.l-bar{margin-top:10px;display:flex;flex-direction:column;align-items:center;gap:3px}
.barcode{max-width:272px;height:36px}
.label.a6 .barcode{height:30px}
.l-bct{font-size:10px;letter-spacing:.18em;font-weight:600}
.l-foot{margin-top:10px;border-top:1px solid #e3e9f2;padding-top:7px;font-size:9px;color:#5a6b85;text-align:center}
.label-host{width:-moz-fit-content;width:fit-content;border-radius:10px;overflow:hidden;border:1px solid #e3e9f2;box-shadow:0 10px 30px rgba(15,23,42,.12)}
`;function X(t){return`@font-face{font-family:InterVariable;src:url(${t}) format('woff2-variations');font-weight:100 900;font-display:swap}`}const z=()=>typeof chrome<"u"&&chrome.runtime?.getURL?chrome.runtime.getURL("fonts/InterVariable.woff2"):"/fonts/InterVariable.woff2",Y=()=>X(z());let P=null;async function ht(){if(P!==null)return P;try{const t=await(await fetch(z())).arrayBuffer(),e=new Uint8Array(t);let n="";for(let o=0;o<e.length;o+=32768)n+=String.fromCharCode(...e.subarray(o,o+32768));P="data:font/woff2;base64,"+btoa(n)}catch{P=""}return P}function K(t,e,n){const o=new Map(n.map(i=>[i.id,i])),a=e.labelFields===null?n:e.labelFields.map(i=>o.get(i)).filter(Boolean),r=i=>(t.customerData[i]||"").trim(),d=i=>a.find(at=>i.test(at.name)),s=a.find(i=>/name|customer/i.test(i.name)),c=a.find(i=>i.type==="phone")||d(/phone|mobile|whatsapp/i),l=a.find(i=>i.type==="textarea"&&/address/i.test(i.name))||d(/address|street/i),u=d(/city|town/i),b=d(/state|province/i),p=d(/pin|zip|postal/i),f=a.filter(i=>![s,c,l,u,b,p].includes(i)&&r(i.id)),h=s?r(s.id):"",L=l?r(l.id).split(/\r?\n/).map(i=>i.trim()).filter(Boolean):[],g=[u&&r(u.id),b&&r(b.id)].filter(i=>!!i).map(i=>m(i)).join(", "),tt=p?r(p.id):"",R=[g,tt].filter(Boolean).join(" - "),q=[e.phone,e.website].filter(i=>!!i).map(i=>m(i)).join("  ·  "),et=new Date(t.createdAt).toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"}),w=e.labelExtras,nt=t.items.map(i=>`<tr><td>${m(i.name)}${i.sku?` <span class="l-lab">(${m(i.sku)})</span>`:""}</td>${w.quantity?`<td class="r">${i.qty}</td>`:""}${w.amount?`<td class="r">${A(i.price*i.qty)}</td>`:""}</tr>`).join("");return`<div class="label ${e.labelSize==="a6"?"a6":""}">
  <div class="l-top">
    <div class="l-brand">${e.logo?`<img class="l-logo" src="${e.logo}" alt="">`:""}<div><div class="l-biz">${m(e.businessName)}</div>${q?`<div class="l-sub">${q}</div>`:""}</div></div>
    <div class="l-onum">${w.orderNumber?`<div class="l-on">${m(t.orderNumber)}</div>`:""}<div class="l-od">${m(et)}</div></div>
  </div>
  <div class="l-rule"></div>
  <div><span class="l-chip">DELIVER TO</span></div>
  <div class="l-addr">
    ${h?`<div class="l-cname">${m(h)}</div>`:""}
    ${c&&r(c.id)?`<div><span class="l-lab">Mobile:</span> ${m(r(c.id))}</div>`:""}
    ${L.map(i=>`<div>${i}</div>`).join("")}
    ${R?`<div>${R}</div>`:""}
    ${f.map(i=>`<div><span class="l-lab">${m(i.name)}:</span> ${m(r(i.id))}</div>`).join("")}
  </div>
  <div class="l-bottom">
    ${w.products&&t.items.length>0?`<table class="l-items"><thead><tr><th>Product</th>${w.quantity?'<th class="r">Qty</th>':""}${w.amount?'<th class="r">Amount</th>':""}</tr></thead><tbody>${nt}</tbody></table>`:""}
    <div class="l-totrow">
      ${w.payment?`<span class="l-pay b-${m(t.paymentStatus.toLowerCase())}">${m(t.paymentStatus.toUpperCase())}</span>`:"<span></span>"}
      ${w.amount?`<span class="l-amt">Total <b>${A(t.total)}</b></span>`:""}
    </div>
    ${w.gst&&e.gst?`<div class="l-gst">GSTIN: ${m(e.gst)}</div>`:""}
    ${w.barcode?`<div class="l-bar">${ut(t.orderNumber)}<div class="l-bct">${m(t.orderNumber)}</div></div>`:""}
    <div class="l-foot">${m(e.footer||"Thank you for your order!")}</div>
  </div>
</div>`}function J(t,e,n,o){const a=document.createElement("div");a.className="label-host";const r=a.attachShadow({mode:"open"});return r.innerHTML=`<style>${Y()}${j}</style>${K(e,n,o)}`,t.innerHTML="",t.appendChild(a),{el:r.querySelector(".label")}}async function bt(t,e,n){const o=await ht(),a=e.labelSize==="a6"?"105mm 148mm":"4in 6in";return`<!doctype html><html><head><meta charset="utf-8"><title>${m(t.orderNumber)} — Label</title><style>${X(o||z())}${j}
body{margin:0;background:#eef1f6;display:flex;align-items:flex-start;justify-content:center;padding:16px}
.toolbar{position:fixed;top:12px;right:14px;display:flex;gap:8px}
.toolbar button{font:600 13px InterVariable,Inter,system-ui,sans-serif;padding:8px 16px;border-radius:8px;border:1px solid #cbd5e1;background:#fff;cursor:pointer}
.toolbar button:hover{background:#f8fafc}
.toolbar button.pri{background:#F66916;border-color:#F66916;color:#fff}
.toolbar button.pri:hover{background:#e05a0e}
@media print{.toolbar{display:none}body{background:#fff;padding:0}}
@page{size:${a};margin:0}
</style></head><body>
<div class="toolbar"><button class="pri" onclick="window.print()">Print Label</button></div>
${K(t,e,n)}
</body></html>`}async function Q(t,e,n){const o=await bt(t,e,n);let a=null;try{a=window.open("","_blank")}catch{}if(a){a.document.open(),a.document.write(o),a.document.close();const d=a;(d.document.fonts?.ready||Promise.resolve()).then(()=>setTimeout(()=>d.print(),60));return}const r=document.createElement("iframe");r.setAttribute("aria-hidden","true"),r.style.cssText="position:fixed;right:0;bottom:0;width:1px;height:1px;opacity:0;border:0;",r.srcdoc=o,document.body.appendChild(r),setTimeout(()=>{try{r.contentWindow?.focus(),r.contentWindow?.print()}catch{}},600),setTimeout(()=>r.remove(),12e4)}async function Z(t,e,n){const o=document.createElement("div");o.style.cssText="position:fixed;left:-9999px;top:0;",document.body.appendChild(o);try{const{el:a}=J(o,t,e,n);if(!a)throw new Error("Label preview is not ready.");const{jpeg:r,w:d,h:s}=await ft(a),[c,l]=e.labelSize==="a6"?[297.64,419.53]:[288,432],u=gt(c,l,r,d,s),b=URL.createObjectURL(u),p=document.createElement("a");p.href=b,p.download=`${t.orderNumber}-label.pdf`,document.body.appendChild(p),p.click(),p.remove(),setTimeout(()=>URL.revokeObjectURL(b),1e4)}finally{o.remove()}}async function ft(t){const e=t.getBoundingClientRect(),n=3,o=Math.max(1,Math.round(e.width*n)),a=Math.max(1,Math.round(e.height*n)),r=t.cloneNode(!0),d=t.querySelector("svg.barcode");if(d){const h=d.getBoundingClientRect(),L=r.querySelector("svg.barcode"),g=document.createElement("img");g.src="data:image/svg+xml;charset=utf-8,"+encodeURIComponent(new XMLSerializer().serializeToString(d)),g.style.width=h.width+"px",g.style.height=h.height+"px",g.style.display="block",L&&L.replaceWith(g)}const s=`<!DOCTYPE html><html><head><meta charset="utf-8"><style>${Y()}${j}body{margin:0;background:#fff}</style></head><body>${new XMLSerializer().serializeToString(r)}</body></html>`,c=await new Promise((h,L)=>{const g=new Image;g.onload=()=>h(g),g.onerror=()=>L(new Error("Label download failed. Please try again.")),g.src="data:text/html;charset=utf-8,"+encodeURIComponent(s)}),l=document.createElement("canvas");l.width=o,l.height=a;const u=l.getContext("2d");if(!u)throw new Error("Label download failed. Please try again.");u.fillStyle="#fff",u.fillRect(0,0,o,a),u.drawImage(c,0,0,o,a);const b=l.toDataURL("image/jpeg",.94),p=atob(b.slice(b.indexOf(",")+1)),f=new Uint8Array(p.length);for(let h=0;h<p.length;h++)f[h]=p.charCodeAt(h);return{jpeg:f,w:o,h:a}}function gt(t,e,n,o,a){const r=[],d=[];let s=0;const c=h=>{r.push(h),s+=h.length},l=h=>{r.push(h),s+=h.length},u=h=>{d.push(s),c(h)};c(`%PDF-1.4
`),u(`1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
`),u(`2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
`),u(`3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${t} ${e}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>
endobj
`);const b=`q ${t.toFixed(2)} 0 0 ${e.toFixed(2)} 0 0 cm /Im0 Do Q`;d.push(s),c(`4 0 obj
<< /Type /XObject /Subtype /Image /Width ${o} /Height ${a} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${n.length} >>
stream
`),l(n),c(`
endstream
endobj
`),d.push(s),c(`5 0 obj
<< /Length ${b.length} >>
stream
${b}
endstream
endobj
`);const p=s;let f=`xref
0 6
0000000000 65535 f 
`;for(const h of d)f+=String(h).padStart(10,"0")+` 00000 n 
`;return c(f),c(`trailer
<< /Size 6 /Root 1 0 R >>
startxref
${p}
%%EOF`),new Blob(r,{type:"application/pdf"})}async function T(t){t.labelPrinted||(t.labelPrinted=!0,t.updatedAt=new Date().toISOString(),await lt(t))}let O="";const U=t=>t.items.map(e=>e.qty>1?`${e.name} ×${e.qty}`:e.name).join(", ");function Tt(t,e){const n=C(),o=O.trim().toLowerCase(),a=o?n.filter(s=>[s.orderNumber,F(s),I(s)].some(c=>c.toLowerCase().includes(o))):n,r=e?a:a.slice(0,50),d=x();return{html:`<div class="page-head">
        <div><h2 class="page-title">Orders</h2><div class="page-sub">${n.length} order${n.length===1?"":"s"} saved${d.sheetId?" · synced to Google Sheets":" · saved on this device"}</div></div>
        <div class="head-actions">
          <button class="btn primary" data-act="new">+ New Order</button>
          ${e?"":`<button class="btn" data-act="tab" title="Open all orders in a full browser tab">All Orders ${N.external}</button>`}
        </div>
      </div>
      <div class="toolbar">
        <input type="search" placeholder="Search order no., customer, phone…" data-search value="${m(O)}">
        <span class="count">${r.length}${e?"":" recent"} shown</span>
      </div>
      ${r.length===0?`<div class="card"><div class="empty">${o?"No orders match your search.":"No orders yet."}<br><button class="btn primary" data-act="new">+ New Order</button></div></div>`:`<div class="tblwrap"><table class="tbl">
        <thead><tr><th>Order Number</th><th>Customer</th><th>Phone</th><th>Products</th><th class="num">Amount</th><th>Payment</th><th>Date</th><th>Label</th><th></th></tr></thead>
        <tbody>
          ${r.map(s=>`<tr>
            <td class="strong nowrap">${m(s.orderNumber)}</td>
            <td class="ellip">${m(F(s))}</td>
            <td class="nowrap muted">${m(I(s))}</td>
            <td class="ellip muted" title="${m(U(s))}">${m(U(s))}</td>
            <td class="num strong nowrap">${A(s.total)}</td>
            <td><span class="badge ${s.paymentStatus}">${s.paymentStatus}</span></td>
            <td class="nowrap muted">${st(s.createdAt)}</td>
            <td><span class="badge ${s.labelPrinted?"ok":"warn"}">${s.labelPrinted?"Printed":"Pending"}</span></td>
            <td><div class="rowbtns">
              <button class="btn small" data-act="label" data-id="${s.id}" title="Preview label">Label</button>
              <button class="btn small" data-act="edit" data-id="${s.id}" title="Edit order">${N.edit}</button>
              <button class="btn small" data-act="print" data-id="${s.id}" title="Print label">${N.print}</button>
              <button class="btn small" data-act="download" data-id="${s.id}" title="Download label PDF">${N.download}</button>
            </div></td>
          </tr>`).join("")}
        </tbody></table></div>`}`,bind(s){const c=s.querySelector("[data-search]");c?.addEventListener("input",()=>{O=c.value,t.rerender();const l=document.querySelector("[data-search]");l&&(l.focus(),l.setSelectionRange(l.value.length,l.value.length))}),s.querySelector('[data-act="new"]')?.addEventListener("click",()=>{e?window.open(chrome.runtime.getURL("index.html")+"#new"):t.go("new")}),s.querySelector('[data-act="tab"]')?.addEventListener("click",()=>window.open(chrome.runtime.getURL("orders.html"))),s.querySelectorAll("[data-id]").forEach(l=>l.addEventListener("click",()=>{const u=l.dataset.act,b=l.dataset.id,p=C().find(f=>f.id===b);p&&(u==="label"?t.go("label",b):u==="edit"?e?window.open(chrome.runtime.getURL("index.html")+"#edit="+b):t.go("new",b):u==="print"?Q(p,x(),W()).then(()=>T(p)).then(()=>{M("Label sent to printer.","ok"),t.rerender()}).catch(f=>M(D(f),"err")):u==="download"&&Z(p,x(),W()).then(()=>T(p)).then(()=>{M(`${p.orderNumber}-label.pdf downloaded.`,"ok"),t.rerender()}).catch(f=>M(D(f),"err")))}))}}}function jt(t,e,n){return{html:`<div class="labelview-bar">
      <button class="btn" data-act="back">← Back</button>
      <div class="title">Label <span class="ordnum">${m(t.orderNumber)}</span></div>
      <div class="spacer"></div>
      <button class="btn" data-act="download">⬇ Download Label</button>
      <button class="btn primary" data-act="print">🖨 Print Label</button>
    </div>
    <div class="label-stage" data-stage></div>`,bind(o){const a=x(),r=W();J(o.querySelector("[data-stage]"),t,a,r);const d=async(s,c)=>{try{await s(),await T(t),M(c,"ok"),n?.()}catch(l){M(D(l),"err")}};o.querySelector('[data-act="back"]').addEventListener("click",e),o.querySelector('[data-act="print"]').addEventListener("click",()=>void d(()=>Q(t,a,r),"Label sent to printer.")),o.querySelector('[data-act="download"]').addEventListener("click",()=>void d(()=>Z(t,a,r),"Label downloaded as PDF."))}}}export{At as A,Et as B,jt as C,Tt as D,yt as F,N as I,wt as P,vt as S,Lt as a,W as b,V as c,Pt as d,m as e,ct as f,x as g,St as h,$t as i,Ct as j,kt as k,D as l,A as m,Nt as n,lt as o,C as p,Wt as q,F as r,Mt as s,M as t,xt as u,H as v,Dt as w,_ as x,G as y,Ot as z};
