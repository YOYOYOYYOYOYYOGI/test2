(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))r(a);new MutationObserver(a=>{for(const o of a)if(o.type==="childList")for(const d of o.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&r(d)}).observe(document,{childList:!0,subtree:!0});function n(a){const o={};return a.integrity&&(o.integrity=a.integrity),a.referrerPolicy&&(o.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?o.credentials="include":a.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function r(a){if(a.ep)return;a.ep=!0;const o=n(a);fetch(a.href,o)}})();const ot={businessName:"My Business",logo:"",phone:"",address:"",website:"",gst:"",footer:"",orderPrefix:"ORD-",nextNumber:1001,labelSize:"4x6",labelFields:[],labelExtras:{orderNumber:!0,products:!0,quantity:!0,payment:!0,amount:!0,gst:!1,barcode:!0},clientId:"",sheetId:"",sheetName:"",customMap:{}},yt=[["text","Text"],["number","Number"],["phone","Phone"],["email","Email"],["textarea","Textarea"],["date","Date"],["dropdown","Dropdown"],["checkbox","Checkbox"]],wt=["Paid","COD","Pending","Failed"],xt="https://www.googleapis.com/auth/spreadsheets";let rt=0;const vt=(t="")=>t+Date.now().toString(36)+(rt++).toString(36)+Math.random().toString(36).slice(2,8),A=t=>"₹"+t.toLocaleString("en-IN"),Wt=()=>{const t=new Date;return t.getFullYear()+"-"+String(t.getMonth()+1).padStart(2,"0")+"-"+String(t.getDate()).padStart(2,"0")},st=t=>t?t.slice(0,10):"",$t=t=>/^[+\d][\d\s-]{5,19}$/.test(t.trim()),St=t=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(t.trim()),p=t=>t.replace(/[&<>"']/g,e=>`&#${e.charCodeAt(0)};`),k=new Map;let E=null;const B=typeof chrome<"u"&&!!chrome.storage?.local;function it(t){return B?(E||(E=new Promise(e=>chrome.storage.local.get(null,n=>{for(const[r,a]of Object.entries(n||{}))k.set(r,a);e()}))),E):Promise.resolve()}function $(t,e){return k.has(t)?k.get(t):e}async function S(t,e){k.set(t,e),B&&await chrome.storage.local.set({[t]:e})}async function dt(t,e,n){const r=e($(t,n));return await S(t,r),r}const y={fields:"fields",products:"products",orders:"orders",settings:"settings",headers:"sheetHeaders"},W=()=>$(y.fields,[]).slice().sort((t,e)=>t.order-e.order),V=()=>$(y.products,[]),C=()=>$(y.orders,[]),v=()=>({...ot,...$(y.settings,{})}),Lt=()=>$(y.headers,[]),_=t=>S(y.fields,t),H=t=>S(y.products,t),G=t=>S(y.settings,t),Mt=t=>S(y.headers,t);async function lt(t){await dt(y.orders,e=>{const n=e.findIndex(r=>r.id===t.id);return n>=0?e[n]=t:e.unshift(t),e},[])}function Pt(t){return C().find(e=>e.id===t)}function Ct(t){const e=t.trim().toLowerCase();return C().find(n=>n.orderNumber.trim().toLowerCase()===e)}function Nt(){const t=v();return t.orderPrefix+t.nextNumber}async function kt(){const t=v();t.nextNumber=Math.max(t.nextNumber+1,1),await G(t)}function F(t){const e=W().find(n=>/name/i.test(n.name));return e&&t.customerData[e.id]||""}function I(t){const e=W().find(n=>n.type==="phone"||/phone|mobile|whatsapp/i.test(n.name));return e&&t.customerData[e.id]||""}async function Et(){await it(),!$("seeded",!1)&&(await S("seeded",!0),W().length===0&&await _([{id:"f_name",name:"Customer Name",type:"text",required:!0,order:0},{id:"f_phone",name:"Phone",type:"phone",required:!0,order:1},{id:"f_address",name:"Address",type:"textarea",required:!1,order:2},{id:"f_city",name:"City",type:"text",required:!1,order:3},{id:"f_state",name:"State",type:"text",required:!1,order:4},{id:"f_pincode",name:"Pincode",type:"number",required:!1,order:5}]),V().length===0&&await H([{id:"p_night",name:"Night Cream",sku:"NC-01",price:499,active:!0},{id:"p_serum",name:"Face Serum",sku:"FS-02",price:699,active:!0},{id:"p_day",name:"Day Cream",sku:"DC-03",price:599,active:!0}]))}function Ot(){const t={exportedAt:new Date().toISOString(),fields:W(),products:V(),orders:C(),settings:v()},e=URL.createObjectURL(new Blob([JSON.stringify(t,null,2)],{type:"application/json"})),n=document.createElement("a");n.href=e,n.download="order-label-manager-backup.json",n.click(),setTimeout(()=>URL.revokeObjectURL(e),5e3)}function At(t){return t.text().then(async e=>{const n=JSON.parse(e);Array.isArray(n.fields)&&await _(n.fields),Array.isArray(n.products)&&await H(n.products),Array.isArray(n.orders)&&await S(y.orders,n.orders),n.settings&&await G({...v(),...n.settings})})}const x=t=>`<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${t}</svg>`,N={tag:'<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.41 11.58l-9-9A2 2 0 0 0 11 2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 .59 1.42l9 9a2 2 0 0 0 2.82 0l7-7a2 2 0 0 0 0-2.84zM7.5 9.5A1.75 1.75 0 1 1 9.25 7.75 1.75 1.75 0 0 1 7.5 9.5z"/></svg>',dash:x('<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>'),plus:x('<path d="M12 5v14M5 12h14"/>'),list:x('<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>'),box:x('<path d="M21 8l-9-5-9 5v8l9 5 9-5V8z"/><path d="M3 8l9 5 9-5M12 13v8"/>'),sliders:x('<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>'),gear:x('<circle cx="12" cy="12" r="3.2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1"/>'),print:x('<path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8" rx="1"/>'),download:x('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>'),edit:x('<path d="M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/>'),external:x('<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"/>')},D=t=>t instanceof Error?t.message:String(t);function M(t,e=""){let n=document.getElementById("toasts");n||(n=document.createElement("div"),n.id="toasts",document.body.appendChild(n));const r=document.createElement("div");r.className="toast "+e,r.textContent=t,n.appendChild(r),setTimeout(()=>{r.style.transition="opacity .25s",r.style.opacity="0",setTimeout(()=>r.remove(),260)},e==="err"?5200:2600)}function ct(t,e){const n=document.createElement("div");n.className="modal-wrap",n.innerHTML=`<div class="modal">${t}</div>`;const r=()=>n.remove();n.addEventListener("mousedown",o=>{o.target===n&&r()}),document.body.appendChild(n);const a=n.querySelector(".modal");return e?.(a,r),{close:r,el:a}}function Dt(t,e,n,r=!0){return new Promise(a=>{ct(`<h3>${t}</h3><p class="muted" style="margin:0 0 4px">${e}</p>
       <div class="row"><button class="btn" data-x>Cancel</button><button class="btn ${r?"danger":"primary"}" data-ok>${n}</button></div>`,(o,d)=>{o.querySelector("[data-x]").addEventListener("click",()=>{d(),a(!1)}),o.querySelector("[data-ok]").addEventListener("click",()=>{d(),a(!0)})})})}const pt={0:"nnnWnWnnW",1:"WnnWnnnnW",2:"nnWWnnnnW",3:"WnWWnnnnn",4:"nnnWWnnnW",5:"WnnWWnnnn",6:"nnWWWnnnn",7:"nnnWnnWWn",8:"WnnWnnWnn",9:"nnWWnnWnn",A:"WnnnnWnnW",B:"nnWnnWnnW",C:"WnWnnWnnn",D:"nnnnWWnnW",E:"WnnnWWnnn",F:"nnWnWWnnn",G:"nnnnnWWnW",H:"WnnnnWWnn",I:"nnWnnWWnn",J:"nnnnWWnWn",K:"WnnnnnnWW",L:"nnWnnnnWW",M:"WnWnnnnWn",N:"nnnnWnnWW",O:"WnnnWnnWn",P:"nnWnWnnWn",Q:"nnnnnnWWW",R:"WnnnnnWWn",S:"nnWnnnWWn",T:"nnnnnWWWn",U:"WWnnnnnnW",V:"nWWnnnnnW",W:"WWWnnnnnn",X:"nWnnWnnnW",Y:"WWnnWnnnn",Z:"nWWWnnnnn","-":"nWnnnnWnW",".":"WWnnnnWnn"," ":"nWWnnnWnn",$:"nWnWnWnnn","/":"nWnWnnnWn","+":"nWnnnWnWn","%":"nnnWnWnWn","*":"nWnnnWnWn"};function ut(t,e=40,n=2,r=4){const a=t.toUpperCase().replace(/[^0-9A-Z\-. $/+%]/g,"");if(!a)return"";let o=0,d="";const s="*"+a+"*";for(let l=0;l<s.length;l++){const m=pt[s[l]];if(m){for(let h=0;h<9;h++){const f=m[h]==="W"?n*3:n;h%2===0&&(d+=`<rect x="${o}" y="0" width="${f}" height="${e}" fill="#000"/>`),o+=f}o+=r}}const c=n*3;return d+=`<rect x="${o}" y="0" width="${c}" height="${e}" fill="#000"/>`,o+=c,`<svg class="barcode" viewBox="0 0 ${o} ${e}" width="${o}" height="${e}" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="barcode ${mt(a)}">${d}</svg>`}function mt(t){return t.replace(/[&<>"]/g,e=>`&#${e.charCodeAt(0)};`)}const j=`
.label{width:384px;height:576px;background:#fff;color:#0F172A;padding:20px 22px;display:flex;flex-direction:column;box-sizing:border-box;overflow:hidden;font-family:InterVariable,Inter,system-ui,-apple-system,sans-serif}
.label.a6{width:397px;height:559px;padding:16px 18px}
.l-top{display:flex;justify-content:space-between;align-items:flex-start;gap:8px}
.l-brand{display:flex;gap:9px;align-items:center;min-width:0}
.l-logo{width:42px;height:42px;object-fit:contain;border-radius:8px;flex:none}
.l-biz{font-size:16.5px;font-weight:800;letter-spacing:-.01em;line-height:1.15;word-break:break-word}
.l-sub{font-size:9.5px;color:#5a6b85;margin-top:2px}
.l-onum{text-align:right;flex:none}
.l-on{font-size:15px;font-weight:800;color:#F66916;white-space:nowrap}
.l-od{font-size:9.5px;color:#5a6b85;margin-top:2px}
.l-rule{height:2.5px;background:#0F172A;border-radius:2px;margin:10px 0}
.l-chip{display:inline-block;font-size:8.5px;font-weight:800;letter-spacing:.12em;background:#F1F5F9;color:#334155;padding:3px 8px;border-radius:4px}
.l-addr{margin-top:7px;font-size:11.5px;line-height:1.5}
.l-cname{font-size:16px;font-weight:800;margin-bottom:2px}
.l-lab{color:#5a6b85;font-weight:600}
.l-items{width:100%;border-collapse:collapse;margin-top:12px}
.l-items th{font-size:8.5px;text-transform:uppercase;letter-spacing:.08em;color:#5a6b85;text-align:left;padding:4px 0;border-bottom:1px solid #e3e9f2;font-weight:700}
.l-items td{font-size:11px;padding:5px 0;border-bottom:1px solid #eef2f7}
.l-items .r,.l-items th.r{text-align:right}
.l-bottom{margin-top:auto}
.l-totrow{display:flex;justify-content:space-between;align-items:center;gap:10px;padding-top:10px}
.l-pay{display:inline-block;font-size:10px;font-weight:800;letter-spacing:.06em;border:1.5px solid currentColor;border-radius:5px;padding:2px 8px}
.l-pay.b-paid{color:#15803d}.l-pay.b-cod{color:#c2540a}.l-pay.b-pending{color:#a16207}.l-pay.b-failed{color:#b91c1c}
.l-amt{font-size:12px;color:#334155}.l-amt b{font-size:14.5px;color:#0F172A}
.l-gst{font-size:9.5px;color:#5a6b85;margin-top:6px}
.l-bar{margin-top:10px;display:flex;flex-direction:column;align-items:center;gap:3px}
.barcode{max-width:272px;height:36px}
.label.a6 .barcode{height:30px}
.l-bct{font-size:10px;letter-spacing:.18em;font-weight:600}
.l-foot{margin-top:10px;border-top:1px solid #e3e9f2;padding-top:7px;font-size:9px;color:#5a6b85;text-align:center}
.label-host{width:-moz-fit-content;width:fit-content;border-radius:10px;overflow:hidden;border:1px solid #e3e9f2;box-shadow:0 10px 30px rgba(15,23,42,.12)}
`;function X(t){return`@font-face{font-family:InterVariable;src:url(${t}) format('woff2-variations');font-weight:100 900;font-display:swap}`}const z=()=>typeof chrome<"u"&&chrome.runtime?.getURL?chrome.runtime.getURL("fonts/InterVariable.woff2"):"/fonts/InterVariable.woff2",Y=()=>X(z());let P=null;async function ht(){if(P!==null)return P;try{const t=await(await fetch(z())).arrayBuffer(),e=new Uint8Array(t);let n="";for(let r=0;r<e.length;r+=32768)n+=String.fromCharCode(...e.subarray(r,r+32768));P="data:font/woff2;base64,"+btoa(n)}catch{P=""}return P}function K(t,e,n){const r=new Map(n.map(i=>[i.id,i])),a=e.labelFields.map(i=>r.get(i)).filter(Boolean),o=i=>(t.customerData[i]||"").trim(),d=i=>a.find(at=>i.test(at.name)),s=a.find(i=>/name|customer/i.test(i.name)),c=a.find(i=>i.type==="phone")||d(/phone|mobile|whatsapp/i),l=a.find(i=>i.type==="textarea"&&/address/i.test(i.name))||d(/address|street/i),m=d(/city|town/i),h=d(/state|province/i),u=d(/pin|zip|postal/i),f=a.filter(i=>![s,c,l,m,h,u].includes(i)&&o(i.id)),b=s?o(s.id):"",L=l?o(l.id).split(/\r?\n/).map(i=>i.trim()).filter(Boolean):[],g=[m&&o(m.id),h&&o(h.id)].filter(i=>!!i).map(i=>p(i)).join(", "),tt=u?o(u.id):"",R=[g,tt].filter(Boolean).join(" - "),q=[e.phone,e.website].filter(i=>!!i).map(i=>p(i)).join("  ·  "),et=new Date(t.createdAt).toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"}),w=e.labelExtras,nt=t.items.map(i=>`<tr><td>${p(i.name)}${i.sku?` <span class="l-lab">(${p(i.sku)})</span>`:""}</td>${w.quantity?`<td class="r">${i.qty}</td>`:""}${w.amount?`<td class="r">${A(i.price*i.qty)}</td>`:""}</tr>`).join("");return`<div class="label ${e.labelSize==="a6"?"a6":""}">
  <div class="l-top">
    <div class="l-brand">${e.logo?`<img class="l-logo" src="${e.logo}" alt="">`:""}<div><div class="l-biz">${p(e.businessName)}</div>${q?`<div class="l-sub">${q}</div>`:""}</div></div>
    <div class="l-onum">${w.orderNumber?`<div class="l-on">${p(t.orderNumber)}</div>`:""}<div class="l-od">${p(et)}</div></div>
  </div>
  <div class="l-rule"></div>
  <div><span class="l-chip">DELIVER TO</span></div>
  <div class="l-addr">
    ${b?`<div class="l-cname">${p(b)}</div>`:""}
    ${c&&o(c.id)?`<div><span class="l-lab">Mobile:</span> ${p(o(c.id))}</div>`:""}
    ${L.map(i=>`<div>${i}</div>`).join("")}
    ${R?`<div>${R}</div>`:""}
    ${f.map(i=>`<div><span class="l-lab">${p(i.name)}:</span> ${p(o(i.id))}</div>`).join("")}
  </div>
  <div class="l-bottom">
    ${w.products&&t.items.length>0?`<table class="l-items"><thead><tr><th>Product</th>${w.quantity?'<th class="r">Qty</th>':""}${w.amount?'<th class="r">Amount</th>':""}</tr></thead><tbody>${nt}</tbody></table>`:""}
    <div class="l-totrow">
      ${w.payment?`<span class="l-pay b-${p(t.paymentStatus.toLowerCase())}">${p(t.paymentStatus.toUpperCase())}</span>`:"<span></span>"}
      ${w.amount?`<span class="l-amt">Total <b>${A(t.total)}</b></span>`:""}
    </div>
    ${w.gst&&e.gst?`<div class="l-gst">GSTIN: ${p(e.gst)}</div>`:""}
    ${w.barcode?`<div class="l-bar">${ut(t.orderNumber)}<div class="l-bct">${p(t.orderNumber)}</div></div>`:""}
    <div class="l-foot">${p(e.footer||"Thank you for your order!")}</div>
  </div>
</div>`}function J(t,e,n,r){const a=document.createElement("div");a.className="label-host";const o=a.attachShadow({mode:"open"});o.innerHTML=`<style>${Y()}${j}</style>${K(e,n,r)}`,t.innerHTML="",t.appendChild(a)}async function bt(t,e,n){const r=await ht(),a=e.labelSize==="a6"?"105mm 148mm":"4in 6in";return`<!doctype html><html><head><meta charset="utf-8"><title>${p(t.orderNumber)} — Label</title><style>${X(r||z())}${j}
body{margin:0;background:#eef1f6;display:flex;align-items:flex-start;justify-content:center;padding:16px}
.toolbar{position:fixed;top:12px;right:14px;display:flex;gap:8px}
.toolbar button{font:600 13px InterVariable,Inter,system-ui,sans-serif;padding:8px 16px;border-radius:8px;border:1px solid #cbd5e1;background:#fff;cursor:pointer}
.toolbar button:hover{background:#f8fafc}
.toolbar button.pri{background:#F66916;border-color:#F66916;color:#fff}
.toolbar button.pri:hover{background:#e05a0e}
@media print{.toolbar{display:none}body{background:#fff;padding:0}}
@page{size:${a};margin:0}
</style></head><body>
<div class="toolbar"><button class="pri" onclick="window.print()">Print Label</button></div>
${K(t,e,n)}
</body></html>`}async function Q(t,e,n){const r=await bt(t,e,n);let a=null;try{a=window.open("","_blank")}catch{}if(a){a.document.open(),a.document.write(r),a.document.close();const d=a;(d.document.fonts?.ready||Promise.resolve()).then(()=>setTimeout(()=>d.print(),60));return}const o=document.createElement("iframe");o.setAttribute("aria-hidden","true"),o.style.cssText="position:fixed;right:0;bottom:0;width:1px;height:1px;opacity:0;border:0;",o.srcdoc=r,document.body.appendChild(o),setTimeout(()=>{try{o.contentWindow?.focus(),o.contentWindow?.print()}catch{}},600),setTimeout(()=>o.remove(),12e4)}async function Z(t,e,n){const r=document.createElement("div");r.style.cssText="position:fixed;left:-9999px;top:0;",document.body.appendChild(r);try{J(r,t,e,n);const a=r.querySelector(".label");if(!a)throw new Error("Label preview is not ready.");const{jpeg:o,w:d,h:s}=await ft(a),[c,l]=e.labelSize==="a6"?[297.64,419.53]:[288,432],m=gt(c,l,o,d,s),h=URL.createObjectURL(m),u=document.createElement("a");u.href=h,u.download=`${t.orderNumber}-label.pdf`,document.body.appendChild(u),u.click(),u.remove(),setTimeout(()=>URL.revokeObjectURL(h),1e4)}finally{r.remove()}}async function ft(t){const e=t.getBoundingClientRect(),n=3,r=Math.max(1,Math.round(e.width*n)),a=Math.max(1,Math.round(e.height*n)),o=t.cloneNode(!0),d=t.querySelector("svg.barcode");if(d){const b=d.getBoundingClientRect(),L=o.querySelector("svg.barcode"),g=document.createElement("img");g.src="data:image/svg+xml;charset=utf-8,"+encodeURIComponent(new XMLSerializer().serializeToString(d)),g.style.width=b.width+"px",g.style.height=b.height+"px",g.style.display="block",L&&L.replaceWith(g)}const s=`<!DOCTYPE html><html><head><meta charset="utf-8"><style>${Y()}${j}body{margin:0;background:#fff}</style></head><body>${new XMLSerializer().serializeToString(o)}</body></html>`,c=await new Promise((b,L)=>{const g=new Image;g.onload=()=>b(g),g.onerror=()=>L(new Error("Label download failed. Please try again.")),g.src="data:text/html;charset=utf-8,"+encodeURIComponent(s)}),l=document.createElement("canvas");l.width=r,l.height=a;const m=l.getContext("2d");if(!m)throw new Error("Label download failed. Please try again.");m.fillStyle="#fff",m.fillRect(0,0,r,a),m.drawImage(c,0,0,r,a);const h=l.toDataURL("image/jpeg",.94),u=atob(h.slice(h.indexOf(",")+1)),f=new Uint8Array(u.length);for(let b=0;b<u.length;b++)f[b]=u.charCodeAt(b);return{jpeg:f,w:r,h:a}}function gt(t,e,n,r,a){const o=[],d=[];let s=0;const c=b=>{o.push(b),s+=b.length},l=b=>{o.push(b),s+=b.length},m=b=>{d.push(s),c(b)};c(`%PDF-1.4
`),m(`1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
`),m(`2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
`),m(`3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${t} ${e}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>
endobj
`);const h=`q ${t.toFixed(2)} 0 0 ${e.toFixed(2)} 0 0 cm /Im0 Do Q`;d.push(s),c(`4 0 obj
<< /Type /XObject /Subtype /Image /Width ${r} /Height ${a} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${n.length} >>
stream
`),l(n),c(`
endstream
endobj
`),d.push(s),c(`5 0 obj
<< /Length ${h.length} >>
stream
${h}
endstream
endobj
`);const u=s;let f=`xref
0 6
0000000000 65535 f 
`;for(const b of d)f+=String(b).padStart(10,"0")+` 00000 n 
`;return c(f),c(`trailer
<< /Size 6 /Root 1 0 R >>
startxref
${u}
%%EOF`),new Blob(o,{type:"application/pdf"})}async function T(t){t.labelPrinted||(t.labelPrinted=!0,t.updatedAt=new Date().toISOString(),await lt(t))}let O="";const U=t=>t.items.map(e=>e.qty>1?`${e.name} ×${e.qty}`:e.name).join(", ");function Tt(t,e){const n=C(),r=O.trim().toLowerCase(),a=r?n.filter(s=>[s.orderNumber,F(s),I(s)].some(c=>c.toLowerCase().includes(r))):n,o=e?a:a.slice(0,50),d=v();return{html:`<div class="page-head">
        <div><h2 class="page-title">Orders</h2><div class="page-sub">${n.length} order${n.length===1?"":"s"} saved${d.sheetId?" · synced to Google Sheets":" · saved on this device"}</div></div>
        <div class="head-actions">
          <button class="btn primary" data-act="new">+ New Order</button>
          ${e?"":`<button class="btn" data-act="tab" title="Open all orders in a full browser tab">All Orders ${N.external}</button>`}
        </div>
      </div>
      <div class="toolbar">
        <input type="search" placeholder="Search order no., customer, phone…" data-search value="${p(O)}">
        <span class="count">${o.length}${e?"":" recent"} shown</span>
      </div>
      ${o.length===0?`<div class="card"><div class="empty">${r?"No orders match your search.":"No orders yet."}<br><button class="btn primary" data-act="new">+ New Order</button></div></div>`:`<div class="tblwrap"><table class="tbl">
        <thead><tr><th>Order Number</th><th>Customer</th><th>Phone</th><th>Products</th><th class="num">Amount</th><th>Payment</th><th>Date</th><th>Label</th><th></th></tr></thead>
        <tbody>
          ${o.map(s=>`<tr>
            <td class="strong nowrap">${p(s.orderNumber)}</td>
            <td class="ellip">${p(F(s))}</td>
            <td class="nowrap muted">${p(I(s))}</td>
            <td class="ellip muted" title="${p(U(s))}">${p(U(s))}</td>
            <td class="num strong nowrap">${A(s.total)}</td>
            <td><span class="badge ${s.paymentStatus}">${s.paymentStatus}</span></td>
            <td class="nowrap muted">${st(s.createdAt)}</td>
            <td><span class="badge ${s.labelPrinted?"ok":"warn"}">${s.labelPrinted?"Printed":"Pending"}</span></td>
            <td><div class="rowbtns">
              <button class="btn small" data-act="label" data-id="${s.id}" title="Preview label">Label</button>
              <button class="btn small" data-act="edit" data-id="${s.id}" title="Edit order">${N.edit}</button>
              <button class="btn small" data-act="print" data-id="${s.id}" title="Print label">${N.print}</button>
              <button class="btn small" data-act="download" data-id="${s.id}" title="Download label PDF">${N.download}</button>
            </div></td>
          </tr>`).join("")}
        </tbody></table></div>`}`,bind(s){const c=s.querySelector("[data-search]");c?.addEventListener("input",()=>{O=c.value,t.rerender();const l=s.querySelector("[data-search]");l.focus(),l.setSelectionRange(l.value.length,l.value.length)}),s.querySelector('[data-act="new"]')?.addEventListener("click",()=>{e?window.open(chrome.runtime.getURL("index.html")+"#new"):t.go("new")}),s.querySelector('[data-act="tab"]')?.addEventListener("click",()=>window.open(chrome.runtime.getURL("orders.html"))),s.querySelectorAll("[data-id]").forEach(l=>l.addEventListener("click",()=>{const m=l.dataset.act,h=l.dataset.id,u=C().find(f=>f.id===h);u&&(m==="label"?t.go("label",h):m==="edit"?e?window.open(chrome.runtime.getURL("index.html")+"#edit="+h):t.go("new",h):m==="print"?Q(u,v(),W()).then(()=>T(u)).then(()=>{M("Label sent to printer.","ok"),t.rerender()}).catch(f=>M(D(f),"err")):m==="download"&&Z(u,v(),W()).then(()=>T(u)).then(()=>{M(`${u.orderNumber}-label.pdf downloaded.`,"ok"),t.rerender()}).catch(f=>M(D(f),"err")))}))}}}function jt(t,e,n){return{html:`<div class="labelview-bar">
      <button class="btn" data-act="back">← Back</button>
      <div class="title">Label <span class="ordnum">${p(t.orderNumber)}</span></div>
      <div class="spacer"></div>
      <button class="btn" data-act="download">⬇ Download Label</button>
      <button class="btn primary" data-act="print">🖨 Print Label</button>
    </div>
    <div class="label-stage" data-stage></div>`,bind(r){const a=v(),o=W();J(r.querySelector("[data-stage]"),t,a,o);const d=async(s,c)=>{try{await s(),await T(t),M(c,"ok"),n?.()}catch(l){M(D(l),"err")}};r.querySelector('[data-act="back"]').addEventListener("click",e),r.querySelector('[data-act="print"]').addEventListener("click",()=>void d(()=>Q(t,a,o),"Label sent to printer.")),r.querySelector('[data-act="download"]').addEventListener("click",()=>void d(()=>Z(t,a,o),"Label downloaded as PDF."))}}}export{At as A,Et as B,jt as C,Tt as D,yt as F,N as I,wt as P,xt as S,C as a,Lt as b,F as c,W as d,p as e,Pt as f,v as g,V as h,M as i,ct as j,$t as k,St as l,A as m,Nt as n,Ct as o,kt as p,D as q,lt as r,Mt as s,Wt as t,vt as u,H as v,Dt as w,_ as x,G as y,Ot as z};
