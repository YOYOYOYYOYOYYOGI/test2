import{g as f,S as he,a as F,b as g,c as N,s as W,d as de,e as c,m as A,t as b,f as T,P as ve,n as Y,i as be,h as fe,j as ye,k as Z,l as G,u as J,o as X,p as ge,q as we,r as $e,v as M,w as re,x as j,F as Se,y as k,z as ke,A as Ee,B as qe,I as L,C as Le,D as Ne}from"./label-view-B9KY9tt6.js";const ie=typeof chrome<"u"&&!!chrome.identity?.launchWebAuthFlow;let x=null;const xe=()=>ie&&!!f().clientId;function oe(){return xe()?B(!1).then(()=>!0).catch(()=>!1):Promise.resolve(!1)}async function Ce(){if(!ie)throw new Error("Chrome identity API is not available.");await B(!0)}async function Ae(){x&&fetch("https://oauth2.googleapis.com/revoke?token="+encodeURIComponent(x.token)).catch(()=>{}),x=null}function ee(t,a){return"https://accounts.google.com/o/oauth2/v2/auth?"+new URLSearchParams({client_id:t,response_type:"token",redirect_uri:chrome.identity.getRedirectURL(),scope:he,prompt:a}).toString()}function te(t,a){return new Promise((e,r)=>{chrome.identity.launchWebAuthFlow({url:t,interactive:!a},d=>{const n=chrome.runtime.lastError,s=l=>r(new Error(a?"silent-fail":l));if(n||!d)return s("Google sign-in failed or was cancelled.");try{const l=new URLSearchParams(new URL(d).hash.replace(/^#/,"")),o=l.get("access_token"),p=Number(l.get("expires_in")||"3600");if(!o)return s("Google sign-in failed.");x={token:o,exp:Date.now()+Math.max(60,p-120)*1e3},e(o)}catch{s("Google sign-in failed.")}})})}async function B(t){if(x&&x.exp>Date.now())return x.token;const a=f().clientId;if(!a)throw new Error("Google Sheets is not set up yet. Add your OAuth Client ID in Settings.");try{return await te(ee(a,"none"),!0)}catch{if(!t)throw new Error("Not signed in to Google.");return te(ee(a,"select_account"),!1)}}async function R(t,a){let e="";try{e=(await t.json())?.error?.message||""}catch{}return t.status===401||t.status===403?new Error(`Google access was rejected while ${a}. Try reconnecting your account in Settings.`):t.status===404?new Error(`Spreadsheet or worksheet not found while ${a}. Check the connection in Settings.`):t.status>=500?new Error(`Google Sheets is temporarily unavailable while ${a}. Please try again.`):new Error(e||`Google Sheets request failed while ${a} (error ${t.status}).`)}async function D(t,a,e=!0){let r;try{r=await B(e)}catch(n){throw new Error(n instanceof Error&&n.message!=="silent-fail"?n.message:"Not signed in to Google. Connect your account in Settings.")}let d=await fetch(t,{...a,headers:{...a?.headers||{},Authorization:"Bearer "+r}});return d.status===401&&(x=null,r=await B(e),d=await fetch(t,{...a,headers:{...a?.headers||{},Authorization:"Bearer "+r}})),d}async function Ie(t){let a;try{a=await D(`https://sheets.googleapis.com/v4/spreadsheets/${t}?fields=sheets.properties.title`)}catch{throw new Error("Network problem while opening the spreadsheet. Check your internet connection.")}if(!a.ok)throw await R(a,"opening the spreadsheet");return{sheets:((await a.json()).sheets||[]).map(r=>r.properties.title)}}async function le(t,a){const e=await D(`https://sheets.googleapis.com/v4/spreadsheets/${t}/values/${encodeURIComponent(U(a,"1:1"))}`);if(!e.ok)throw await R(e,"reading headers");return((await e.json()).values?.[0]||[]).map(d=>String(d).trim())}async function Oe(t,a,e,r){const d=e.map(s=>s.trim().toLowerCase()),n=r.filter(s=>!d.includes(s.trim().toLowerCase()));if(n.length>0){const s=U(a,`${Q(e.length)}1:${Q(e.length+n.length-1)}1`),l=await D(`https://sheets.googleapis.com/v4/spreadsheets/${t}/values/${encodeURIComponent(s)}?valueInputOption=RAW`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({values:[n]})});if(!l.ok)throw await R(l,"creating columns")}return[...e,...n]}async function ce(t,a,e,r){const d=await D(`https://sheets.googleapis.com/v4/spreadsheets/${t}/values/${encodeURIComponent(U(a,`${e}:${e}`))}`);if(!d.ok)throw await R(d,"looking up the order number");const s=(await d.json()).values||[],l=r.trim().toLowerCase();for(let o=0;o<s.length;o++)if(String(s[o][0]||"").trim().toLowerCase()===l)return{row:o+1,last:s.length};return{row:0,last:s.length}}async function Pe(t,a,e,r){if(e>0){const l=U(a,`A${e}:${Q(r.length-1)}${e}`),o=await D(`https://sheets.googleapis.com/v4/spreadsheets/${t}/values/${encodeURIComponent(l)}?valueInputOption=USER_ENTERED`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({values:[r]})});if(!o.ok)throw await R(o,"updating the order row");return e}const d=await D(`https://sheets.googleapis.com/v4/spreadsheets/${t}/values/${encodeURIComponent(U(a,"A:A"))}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({values:[r]})});if(!d.ok)throw await R(d,"adding the order row");const n=await d.json(),s=/![A-Z]+(\d+)/.exec(String(n.updates?.updatedRange||""));return s?Number(s[1]):0}function U(t,a){return"'"+t.replace(/'/g,"''")+"'!"+a}function Q(t){let a="",e=t+1;for(;e>0;){const r=(e-1)%26;a=String.fromCharCode(65+r)+a,e=Math.floor((e-1)/26)}return a}const ue=["Order Number","Order Date","Payment Status","Amount"];function pe(t,a){const r=a.map(d=>d.trim().toLowerCase()).indexOf(t.trim().toLowerCase());return r>=0?a[r]:""}function Re(t,a,e,r){return r[t]||pe(a,e)}function me(t){return pe("Order Number",t)}async function K(t,a){const e=f();let r=F();r.length===0&&(r=await le(t,a));const d=r.map(l=>l.trim().toLowerCase()),n=[];for(const l of ue)d.includes(l.toLowerCase())||n.push(l);for(const l of g())e.customMap?.[l.id]||d.includes(l.name.trim().toLowerCase())||n.push(l.name);for(const l of N()){const o=`${l.name} Qty`;d.includes(o.toLowerCase())||n.push(o)}const s=n.length>0?await Oe(t,a,r,n):r;return(s!==r||F().length===0)&&W(s),s}function De(t,a,e={}){const r=a.map(s=>s.trim().toLowerCase()),d=new Array(a.length).fill(""),n=(s,l)=>{if(!s)return;const o=r.indexOf(s.trim().toLowerCase());o>=0&&(d[o]=l)};n("Order Number",t.orderNumber),n("Order Date",t.createdAt.slice(0,10)),n("Payment Status",t.paymentStatus),n("Amount",String(t.total)),n("Products",t.items.map(s=>s.qty>1?`${s.name} x ${s.qty}`:s.name).join(", ")),n("Quantity",String(t.items.reduce((s,l)=>s+l.qty,0))),n("SKU",t.items.map(s=>s.sku).filter(Boolean).join(", "));for(const s of t.items)n(`${s.name} Qty`,String(s.qty));for(const s of g())n(Re(s.id,s.name,a,e),t.customerData[s.id]||"");return d}async function je(t){const a=f();if(!a.sheetId||!a.sheetName)return 0;const e=await K(a.sheetId,a.sheetName),r=a.customMap||{};let d=t.sheetRow||0;if(d===0){const l=me(e);l&&(d=(await ce(a.sheetId,a.sheetName,l,t.orderNumber)).row)}const n=De(t,e,r),s=await Pe(a.sheetId,a.sheetName,d,n);return t.sheetRow=s||d,t.sheetRow}async function Fe(t){const a=f();if(!a.sheetId||!a.sheetName)return!1;const e=F().length>0?F():await le(a.sheetId,a.sheetName),r=me(e);return r?(await ce(a.sheetId,a.sheetName,r,t)).row>0:!1}function Te(t){const a=t.trim();if(!a)return"";const e=/docs\.google\.com\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/.exec(a);return e?e[1]:a}let S=null,I=null;function Ue(){S=null,I="\0reset"}function ae(){return{id:null,orderNumber:Y(),customerData:{},items:[],paymentStatus:"COD"}}function Ge(t,a){const e=t.required?' <span class="req">*</span>':"",r=c(t.id);switch(t.type){case"textarea":return`<div class="field span2"><label class="f">${c(t.name)}${e}</label><textarea rows="2" data-fid="${r}">${c(a)}</textarea></div>`;case"dropdown":{const d=(t.options||[]).map(n=>`<option ${n===a?"selected":""}>${c(n)}</option>`).join("");return`<div class="field"><label class="f">${c(t.name)}${e}</label><select data-fid="${r}"><option value=""></option>${d}</select></div>`}case"checkbox":return`<div class="field"><label class="f">${c(t.name)}${e}</label><label class="checkrow" style="padding:6px 0 0"><input type="checkbox" data-fid="${r}" ${a==="Yes"?"checked":""}> Yes</label></div>`;default:{const d=t.type==="number"?"number":t.type==="phone"?"tel":t.type==="email"?"email":t.type==="date"?"date":"text";return`<div class="field"><label class="f">${c(t.name)}${e}</label><input type="${d}" data-fid="${r}" value="${c(a)}"${t.type==="number"?' step="any"':""}></div>`}}}function Me(t){if(!S||I!==t.id){if(t.id){const n=de(t.id);S=n?{id:n.id,orderNumber:n.orderNumber,customerData:{...n.customerData},items:n.items.map(s=>({...s})),paymentStatus:n.paymentStatus,sheetRow:n.sheetRow,createdAt:n.createdAt,labelPrinted:n.labelPrinted}:ae()}else S=ae();I=t.id}const a=S,e=g(),r=a.items.reduce((n,s)=>n+s.price*s.qty,0),d=a.items.map((n,s)=>`<tr>
        <td><div class="strong">${c(n.name)}</div>${n.sku?`<div class="muted" style="font-size:11px">${c(n.sku)}</div>`:""}</td>
        <td class="num"><input class="price-input" type="number" step="any" min="0" data-price="${s}" value="${n.price}"></td>
        <td class="num"><input class="qty-input" type="number" min="1" step="1" data-qty="${s}" value="${n.qty}"></td>
        <td class="num strong" data-line="${s}">${A(n.price*n.qty)}</td>
        <td class="num"><button class="btn small ghost-danger" data-rm="${s}" title="Remove">✕</button></td>
      </tr>`).join("");return{html:`<div class="page-head">
        <div>
          <h2 class="page-title">${a.id?"Edit Order":"New Order"}</h2>
          <div class="page-sub">Order <span class="ordnum">${c(a.orderNumber)}</span>${a.sheetRow?` · updates spreadsheet row ${a.sheetRow}`:""}</div>
        </div>
        <div class="head-actions"><div><label class="f">Order Number</label><input type="text" class="mini-input" data-onum value="${c(a.orderNumber)}" title="You can set a manual order number"></div></div>
      </div>
      <div class="card">
        <div class="card-title">Customer Details</div>
        ${e.length===0?'<div class="muted">No custom fields yet — create them in <b>Custom Fields</b>. They become your spreadsheet columns.</div>':`<div class="fgrid">${e.map(n=>Ge(n,a.customerData[n.id]||"")).join("")}</div>`}
      </div>
      <div class="card">
        <div class="card-title">Products</div>
        ${a.items.length===0?'<div class="muted" style="margin-bottom:10px">No products added yet.</div>':`<div class="tblwrap" style="border:0;margin-bottom:10px"><table class="tbl items-tbl"><thead><tr><th>Product</th><th class="num">Price (₹)</th><th class="num">Qty</th><th class="num">Total</th><th></th></tr></thead><tbody>${d}</tbody></table></div>`}
        <button class="btn" data-act="addprod">+ Add Product</button>
      </div>
      <div class="card">
        <div class="savebar">
          <div class="paywrap">Payment
            <select data-pay style="width:150px">${ve.map(n=>`<option ${n===a.paymentStatus?"selected":""}>${n}</option>`).join("")}</select>
          </div>
          <div class="spacer"></div>
          <div class="totline">Total&nbsp; <b data-total>${A(r)}</b></div>
        </div>
      </div>
      <div class="form-foot">
        <button class="btn" data-act="cancel">Cancel</button>
        <button class="btn primary" data-act="save">${a.id?"Update Order":"Save Order"}</button>
      </div>`,bind(n){const s=S;n.querySelectorAll("[data-fid]").forEach(o=>{const p=o.dataset.fid,i=o.tagName==="SELECT"||o.type==="checkbox"?"change":"input";o.addEventListener(i,()=>{const u=o;s.customerData[p]=u.type==="checkbox"?u.checked?"Yes":"":u.value,u.classList.remove("invalid")})}),n.querySelector("[data-onum]")?.addEventListener("input",o=>{s.orderNumber=o.target.value,n.querySelector(".ordnum").textContent=s.orderNumber}),n.querySelector("[data-pay]")?.addEventListener("change",o=>{s.paymentStatus=o.target.value});const l=o=>{const p=s.items[o],i=n.querySelector(`[data-line="${o}"]`);i&&(i.textContent=A(p.price*p.qty));const u=n.querySelector("[data-total]");u&&(u.textContent=A(s.items.reduce((v,$)=>v+$.price*$.qty,0)))};n.querySelectorAll("[data-qty]").forEach(o=>o.addEventListener("input",()=>{const p=Number(o.dataset.qty);s.items[p].qty=Math.max(1,Math.floor(Number(o.value)||1)),l(p)})),n.querySelectorAll("[data-price]").forEach(o=>o.addEventListener("input",()=>{const p=Number(o.dataset.price);s.items[p].price=Math.max(0,Number(o.value)||0),l(p)})),n.querySelectorAll("[data-rm]").forEach(o=>o.addEventListener("click",()=>{s.items.splice(Number(o.dataset.rm),1),t.rerender()})),n.querySelector('[data-act="addprod"]')?.addEventListener("click",()=>{const o=N().filter(p=>p.active);if(o.length===0){b("No active products. Add some in the Products page first.","err");return}T(`<h3>Add Product</h3>
           <input type="text" placeholder="Search products…" data-search style="margin-bottom:8px">
           <div class="plist" data-list></div>
           <div class="row"><button class="btn" data-close>Close</button></div>`,(p,i)=>{const u=p.querySelector("[data-list]"),v=p.querySelector("[data-search]"),$=()=>{const q=v.value.trim().toLowerCase(),h=o.filter(m=>!q||m.name.toLowerCase().includes(q)||m.sku.toLowerCase().includes(q));u.innerHTML=h.length===0?'<div class="muted" style="padding:10px">No products found.</div>':h.map(m=>{const y=s.items.some(w=>w.productId===m.id);return`<button data-pid="${m.id}" ${y?"disabled":""}><span class="strong">${c(m.name)}</span><span class="muted">${c(m.sku)}</span><span class="p-price">${A(m.price)}</span></button>`}).join("")};$(),v.addEventListener("input",$),v.focus(),u.addEventListener("click",q=>{const h=q.target.closest("[data-pid]");if(!h||h.hasAttribute("disabled"))return;const m=o.find(y=>y.id===h.dataset.pid);s.items.push({productId:m.id,name:m.name,sku:m.sku,price:m.price,qty:1}),i(),t.rerender()}),p.querySelector("[data-close]").addEventListener("click",i)})}),n.querySelector('[data-act="cancel"]')?.addEventListener("click",()=>{S=null,I=null,t.go("orders")}),n.querySelector('[data-act="save"]')?.addEventListener("click",()=>void Be(t,n))}}}async function Be(t,a){const e=S,r=g(),d=[];e.orderNumber.trim()||d.push("Order number is required.");for(const i of r){const u=(e.customerData[i.id]||"").trim(),v=a.querySelector(`[data-fid="${i.id}"]`);i.required&&!u?(d.push(`${i.name} is required.`),v?.classList.add("invalid")):u&&i.type==="phone"&&!be(u)?(d.push(`${i.name}: enter a valid phone number.`),v?.classList.add("invalid")):u&&i.type==="email"&&!fe(u)?(d.push(`${i.name}: enter a valid email address.`),v?.classList.add("invalid")):u&&i.type==="number"&&Number.isNaN(Number(u))&&(d.push(`${i.name} must be a number.`),v?.classList.add("invalid"))}e.items.length===0&&d.push("Add at least one product.");for(const i of e.items)(!(i.qty>=1)||!Number.isInteger(i.qty))&&d.push(`Quantity for ${i.name} must be a whole number (at least 1).`),i.price>=0||d.push(`Price for ${i.name} is invalid.`);if(d.length>0){b(d[0],"err");return}const n=ye(e.orderNumber);if(n&&n.id!==e.id){T(`<h3>Order already exists.</h3>
       <p class="muted" style="margin:0"><b>${c(e.orderNumber)}</b> already exists on this device.</p>
       <div class="row" style="justify-content:flex-start">
         <button class="btn" data-open>Open Order</button>
         <button class="btn" data-edit>Edit Order</button>
         <button class="btn" data-x>Cancel</button>
       </div>`,(i,u)=>{i.querySelector("[data-open]").addEventListener("click",()=>{S=null,I=null,u(),t.go("label",n.id)}),i.querySelector("[data-edit]").addEventListener("click",()=>{S=null,I=null,u(),t.go("new",n.id)}),i.querySelector("[data-x]").addEventListener("click",u)});return}if(!e.id&&f().sheetId)try{if(await Fe(e.orderNumber.trim())){T(`<h3>Order already exists.</h3>
           <p class="muted" style="margin:0"><b>${c(e.orderNumber)}</b> is already used in your spreadsheet.</p>
           <div class="row" style="justify-content:flex-start">
             <button class="btn primary" data-next>Use Next Number</button>
             <button class="btn" data-x>Cancel</button>
           </div>`,(i,u)=>{i.querySelector("[data-next]").addEventListener("click",async()=>{u(),await Z(),e.orderNumber=Y();const v=a.querySelector("[data-onum]");v&&(v.value=e.orderNumber);const $=a.querySelector(".ordnum");$&&($.textContent=e.orderNumber),b(`Switched to ${e.orderNumber}.`)}),i.querySelector("[data-x]").addEventListener("click",u)});return}}catch(i){b(G(i),"err");return}const s=new Date().toISOString(),l={id:e.id||J("o_"),orderNumber:e.orderNumber.trim(),customerData:{...e.customerData},items:e.items.map(i=>({...i})),paymentStatus:e.paymentStatus,total:e.items.reduce((i,u)=>i+u.price*u.qty,0),createdAt:e.createdAt||s,updatedAt:s,labelPrinted:e.labelPrinted||!1,sheetRow:e.sheetRow},o=!e.id;await X(l);let p="";if(f().sheetId)try{l.sheetRow=await je(l),await X(l)}catch(i){p=G(i)}o&&e.orderNumber===Y()&&await Z(),S=null,I=null,b(o?"Order saved successfully.":"Order updated successfully.","ok"),p&&b("Saved on this device. Google Sheets: "+p,"err"),t.go("orders")}function _e(t){const a=ge(),e=we(),r=s=>a.filter(s).length,d=[["Today's Orders",r(s=>s.createdAt.slice(0,10)===e)],["Pending Labels",r(s=>!s.labelPrinted)],["Paid Orders",r(s=>s.paymentStatus==="Paid")],["COD Orders",r(s=>s.paymentStatus==="COD")]],n=a.slice(0,5);return{html:`<div class="page-head">
        <div><h2 class="page-title">Dashboard</h2><div class="page-sub">Overview of your orders</div></div>
        <div class="head-actions">
          <button class="btn primary" data-act="new">+ New Order</button>
          <button class="btn" data-act="orders">Orders</button>
          <button class="btn" data-act="settings">Settings</button>
        </div>
      </div>
      <div class="stats">${d.map(([s,l])=>`<div class="stat"><div class="v">${l}</div><div class="l">${s}</div></div>`).join("")}</div>
      <div class="card">
        <div class="card-title">Recent Orders</div>
        ${n.length===0?'<div class="empty">No orders yet.<br><button class="btn primary" data-act="new">+ New Order</button></div>':`<div class="tblwrap" style="border:0"><table class="tbl"><thead><tr><th>Order</th><th>Customer</th><th class="num">Amount</th><th>Payment</th><th></th></tr></thead><tbody>${n.map(s=>`<tr>
                    <td class="strong nowrap">${c(s.orderNumber)}</td>
                    <td class="ellip">${c($e(s))}</td>
                    <td class="num strong nowrap">${A(s.total)}</td>
                    <td><span class="badge ${s.paymentStatus}">${s.paymentStatus}</span></td>
                    <td class="num"><button class="btn small" data-label="${s.id}">Label</button></td>
                  </tr>`).join("")}</tbody></table></div>`}
      </div>`,bind(s){s.querySelectorAll('[data-act="new"]').forEach(l=>l.addEventListener("click",()=>{Ue(),t.go("new")})),s.querySelector('[data-act="orders"]')?.addEventListener("click",()=>t.go("orders")),s.querySelector('[data-act="settings"]')?.addEventListener("click",()=>t.go("settings")),s.querySelectorAll("[data-label]").forEach(l=>l.addEventListener("click",()=>t.go("label",l.dataset.label)))}}}function ze(t){const a=N();return{html:`<div class="page-head">
        <div><h2 class="page-title">Products</h2><div class="page-sub">Select these while creating an order</div></div>
        <div class="head-actions"><button class="btn primary" data-act="add">+ Add Product</button></div>
      </div>
      ${a.length===0?'<div class="card"><div class="empty">No products yet.<br><button class="btn primary" data-act="add">+ Add Product</button></div></div>':`<div class="tblwrap"><table class="tbl">
        <thead><tr><th>Name</th><th>SKU</th><th class="num">Price</th><th>Active</th><th></th></tr></thead>
        <tbody>${a.map(e=>`<tr>
          <td class="strong">${c(e.name)}</td>
          <td class="muted">${c(e.sku)}</td>
          <td class="num strong nowrap">${A(e.price)}</td>
          <td><label class="switch"><input type="checkbox" data-toggle="${e.id}" ${e.active?"checked":""}><i></i></label></td>
          <td><div class="rowbtns">
            <button class="btn small" data-edit="${e.id}">Edit</button>
            <button class="btn small ghost-danger" data-del="${e.id}">Delete</button>
          </div></td>
        </tr>`).join("")}</tbody></table></div>`}`,bind(e){e.querySelectorAll('[data-act="add"]').forEach(r=>r.addEventListener("click",()=>void se(null,t))),e.querySelectorAll("[data-toggle]").forEach(r=>r.addEventListener("change",async()=>{const d=r.dataset.toggle,n=r.checked;await M(N().map(s=>s.id===d?{...s,active:n}:s))})),e.querySelectorAll("[data-edit]").forEach(r=>r.addEventListener("click",()=>{const d=N().find(n=>n.id===r.dataset.edit);d&&se(d,t)})),e.querySelectorAll("[data-del]").forEach(r=>r.addEventListener("click",async()=>{const d=N().find(s=>s.id===r.dataset.del);!d||!await re("Delete product?",`<b>${c(d.name)}</b> will be removed from the product list. Existing orders are not affected.`,"Delete")||(await M(N().filter(s=>s.id!==d.id)),b("Product deleted."),t.rerender())}))}}}async function se(t,a){T(`<h3>${t?"Edit Product":"Add Product"}</h3>
     <div class="fgrid">
       <div class="field span2"><label class="f">Name <span class="req">*</span></label><input type="text" data-n value="${c(t?.name||"")}"></div>
       <div class="field"><label class="f">SKU</label><input type="text" data-s value="${c(t?.sku||"")}"></div>
       <div class="field"><label class="f">Price (₹)</label><input type="number" step="any" min="0" data-p value="${t?.price??0}"></div>
     </div>
     <label class="checkrow"><input type="checkbox" data-a ${t?.active??!0?"checked":""}> Active (selectable in orders)</label>
     <div class="row"><button class="btn" data-x>Cancel</button><button class="btn primary" data-save>Save</button></div>`,(e,r)=>{e.querySelector("[data-x]").addEventListener("click",r),e.querySelector("[data-save]").addEventListener("click",async()=>{const d=e.querySelector("[data-n]").value.trim(),n=e.querySelector("[data-s]").value.trim(),s=Math.max(0,Number(e.querySelector("[data-p]").value)||0),l=e.querySelector("[data-a]").checked;if(!d){e.querySelector("[data-n]").classList.add("invalid"),b("Product name is required.","err");return}const o=N();t?await M(o.map(p=>p.id===t.id?{...p,name:d,sku:n,price:s,active:l}:p)):await M([...o,{id:J("p_"),name:d,sku:n,price:s,active:l}]),r(),b("Product saved.","ok"),a.rerender()})})}function We(t){const a=g();return{html:`<div class="page-head">
        <div><h2 class="page-title">Custom Fields</h2><div class="page-sub">Each field becomes a spreadsheet column — every order fills one row</div></div>
        <div class="head-actions"><button class="btn primary" data-act="add">+ Add Field</button></div>
      </div>
      <div class="card">
        ${a.length===0?'<div class="empty">No fields yet. Add fields like Customer Name, Phone, Address, City…<br><button class="btn primary" data-act="add">+ Add Field</button></div>':`<div>${a.map((e,r)=>`<div class="list-row">
              <span class="muted nowrap" style="font-size:11px">${r+1}.</span>
              <div class="grow"><span class="name">${c(e.name)}</span>${e.required?' <span class="req" style="color:var(--danger);font-weight:800">*</span>':""}</div>
              <span class="type-badge">${e.type}</span>
              <label class="switch" title="Required"><input type="checkbox" data-req="${e.id}" ${e.required?"checked":""}><i></i></label>
              <button class="btn small icon" data-up="${e.id}" ${r===0?"disabled":""} title="Move up">↑</button>
              <button class="btn small icon" data-down="${e.id}" ${r===a.length-1?"disabled":""} title="Move down">↓</button>
              <button class="btn small" data-edit="${e.id}">Edit</button>
              <button class="btn small ghost-danger" data-del="${e.id}">Delete</button>
            </div>`).join("")}</div>`}
        <div class="hint">Reorder with ↑ ↓ — the order here is the order in the order form and on the label.</div>
      </div>`,bind(e){e.querySelector('[data-act="add"]')?.addEventListener("click",()=>void ne(null,t)),e.querySelectorAll("[data-req]").forEach(d=>d.addEventListener("change",async()=>{const n=d.dataset.req,s=d.checked;await j(g().map(l=>l.id===n?{...l,required:s}:l))}));const r=async(d,n)=>{const s=g(),l=s.findIndex(p=>p.id===d),o=l+n;l<0||o<0||o>=s.length||([s[l],s[o]]=[s[o],s[l]],await j(s.map((p,i)=>({...p,order:i}))),t.rerender())};e.querySelectorAll("[data-up]").forEach(d=>d.addEventListener("click",()=>void r(d.dataset.up,-1))),e.querySelectorAll("[data-down]").forEach(d=>d.addEventListener("click",()=>void r(d.dataset.down,1))),e.querySelectorAll("[data-edit]").forEach(d=>d.addEventListener("click",()=>{const n=g().find(s=>s.id===d.dataset.edit);n&&ne(n,t)})),e.querySelectorAll("[data-del]").forEach(d=>d.addEventListener("click",async()=>{const n=g().find(o=>o.id===d.dataset.del);if(!n||!await re("Delete field?",`<b>${c(n.name)}</b> will be removed from the order form. Existing orders keep their data, and the spreadsheet column is never deleted.`,"Delete"))return;const l=g().filter(o=>o.id!==n.id);await j(l.map((o,p)=>({...o,order:p}))),b("Field deleted."),t.rerender()}))}}}async function ne(t,a){T(`<h3>${t?"Edit Field":"Add Field"}</h3>
     <div class="fgrid">
       <div class="field span2"><label class="f">Field name <span class="req">*</span></label><input type="text" data-n value="${c(t?.name||"")}" placeholder="e.g. Customer Name"></div>
       <div class="field"><label class="f">Type</label><select data-t>${Se.map(([e,r])=>`<option value="${e}" ${t?.type===e?"selected":""}>${r}</option>`).join("")}</select></div>
       <div class="field"><label class="f">Required</label><label class="checkrow" style="padding:6px 0 0"><input type="checkbox" data-r ${t?.required?"checked":""}> Must be filled</label></div>
       <div class="field span2" data-optwrap style="display:${t?.type==="dropdown"?"block":"none"}"><label class="f">Dropdown options <span class="muted">(one per line)</span></label><textarea rows="3" data-o>${c((t?.options||[]).join(`
`))}</textarea></div>
     </div>
     <div class="hint">Field names become spreadsheet column headers. Existing orders are never affected by changes here.</div>
     <div class="row"><button class="btn" data-x>Cancel</button><button class="btn primary" data-save>Save Field</button></div>`,(e,r)=>{const d=e.querySelector("[data-t]");d.addEventListener("change",()=>{e.querySelector("[data-optwrap]").style.display=d.value==="dropdown"?"block":"none"}),e.querySelector("[data-x]").addEventListener("click",r),e.querySelector("[data-save]").addEventListener("click",async()=>{const n=e.querySelector("[data-n]"),s=n.value.trim(),l=d.value,o=e.querySelector("[data-r]").checked,p=e.querySelector("[data-o]").value.split(`
`).map(v=>v.trim()).filter(Boolean);if(!s){n.classList.add("invalid"),b("Field name is required.","err");return}if(l==="dropdown"&&p.length===0){b("Add at least one dropdown option.","err");return}if(g().find(v=>v.name.trim().toLowerCase()===s.toLowerCase()&&v.id!==t?.id)){n.classList.add("invalid"),b("A field with this name already exists.","err");return}const u=g();t?await j(u.map(v=>v.id===t.id?{...v,name:s,type:l,required:o,options:l==="dropdown"?p:void 0}:v)):await j([...u,{id:J("f_"),name:s,type:l,required:o,options:l==="dropdown"?p:void 0,order:u.length}]),r(),b("Field saved.","ok"),a.rerender()})})}const P={signedIn:!1};function He(t){const a=f(),e=g(),r=F(),d=!!a.sheetId,n=i=>a.labelFields===null?!0:a.labelFields.includes(i),s=e.map(i=>`<label class="checkrow"><input type="checkbox" data-lf="${i.id}" ${n(i.id)?"checked":""}> ${c(i.name)}</label>`).join(""),o=[["orderNumber","Order Number"],["products","Products"],["quantity","Quantity"],["payment","Payment Status"],["amount","Amount"],["gst","Business GST"],["barcode","Barcode"]].map(([i,u])=>`<label class="checkrow"><input type="checkbox" data-ex="${i}" ${a.labelExtras[i]?"checked":""}> ${u}</label>`).join(""),p=d?`<div class="card-sub" style="margin-top:12px">Column mapping — fields reuse matching columns automatically. Map a field to a different existing column if needed.</div>
       ${e.length===0?'<div class="muted" style="font-size:12px">No custom fields to map.</div>':e.map(i=>{const u=a.customMap[i.id]||"";return`<div class="map-row"><div class="strong">${c(i.name)}</div><select data-map="${i.id}"><option value="">Auto${u?"":" (matched)"}</option>${r.map(v=>`<option value="${c(v)}" ${u===v?"selected":""}>${c(v)}</option>`).join("")}</select></div>`}).join("")}`:"";return{html:`<div class="page-head">
        <div><h2 class="page-title">Settings</h2><div class="page-sub">Changes are saved automatically</div></div>
      </div>

      <div class="card">
        <div class="card-title">Business</div>
        <div class="set-grid">
          <div class="field"><label class="f">Business Name</label><input type="text" data-k="businessName" value="${c(a.businessName)}"></div>
          <div class="field"><label class="f">Phone</label><input type="text" data-k="phone" value="${c(a.phone)}"></div>
          <div class="field"><label class="f">Website</label><input type="text" data-k="website" value="${c(a.website)}"></div>
          <div class="field"><label class="f">GST</label><input type="text" data-k="gst" value="${c(a.gst)}"></div>
          <div class="field span2"><label class="f">Address</label><textarea rows="2" data-k="address">${c(a.address)}</textarea></div>
          <div class="field span2"><label class="f">Label Footer</label><input type="text" data-k="footer" value="${c(a.footer)}" placeholder="Thank you for your order!"></div>
          <div class="field span2"><label class="f">Logo</label>
            <div class="logo-row">
              ${a.logo?`<img src="${a.logo}" alt="logo">`:""}
              <button class="btn small" data-act="logo">${a.logo?"Change Logo":"Upload Logo"}</button>
              ${a.logo?'<button class="btn small ghost-danger" data-act="logorm">Remove</button>':""}
              <input type="file" accept="image/*" data-logo hidden>
            </div>
            <div class="hint">Shown on the shipping label. PNG/JPG, up to ~300 KB.</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Google Sheets</div>
        <div class="toolbar" style="margin-bottom:8px">
          <span class="dot ${P.signedIn?"on":""}" data-gdot></span>
          <span class="count" data-gstatus>${d?`Spreadsheet connected: ${a.sheetName||"…"}`:P.signedIn?"Google account connected":"Not connected"}</span>
          <span class="spacer"></span>
          <button class="btn small" data-act="gdisconnect" ${P.signedIn||d?"":"disabled"}>Disconnect</button>
        </div>
        <div class="set-grid">
          <div class="field span2"><label class="f">Spreadsheet URL or ID</label><input type="text" data-sheetref value="${c(a.sheetId)}" placeholder="https://docs.google.com/spreadsheets/d/…"></div>
          <div class="field"><label class="f">Worksheet</label><select data-ws ${d?"":"disabled"}><option value="${c(a.sheetName)}">${c(a.sheetName||"—")}</option></select></div>
          <div class="field"><label class="f">&nbsp;</label><button class="btn" data-act="use" style="width:100%">${d?"Re-read Connection":"Connect Spreadsheet"}</button></div>
        </div>
        <div class="field" style="margin-top:4px"><label class="f">Google OAuth Client ID</label><input type="text" data-k="clientId" value="${c(a.clientId)}" placeholder="xxxxxxxx.apps.googleusercontent.com"></div>
        <details class="help">
          <summary>One-time setup: how to get a Client ID (free, ~2 minutes)</summary>
          <ol>
            <li>Open <b>console.cloud.google.com</b> → create/select a project.</li>
            <li><b>APIs &amp; Services → Library</b> → enable <b>Google Sheets API</b>.</li>
            <li><b>OAuth consent screen</b> → External → add yourself as a <b>test user</b>.</li>
            <li><b>Credentials → Create credentials → OAuth client ID</b> → type <b>Web application</b>.</li>
            <li>Add this <b>Authorized redirect URI</b>: <code>${c(chrome?.identity?.getRedirectURL?chrome.identity.getRedirectURL():"chrome-extension://EXTENSION_ID.chromiumapp.org/")}</code></li>
            <li>Copy the <b>Client ID</b> and paste it above, then click <b>Connect Spreadsheet</b>.</li>
          </ol>
        </details>
        ${p}
      </div>

      <div class="card">
        <div class="card-title">Orders</div>
        <div class="set-grid">
          <div class="field"><label class="f">Order Prefix</label><input type="text" data-k="orderPrefix" value="${c(a.orderPrefix)}"></div>
          <div class="field"><label class="f">Starting Number</label><input type="number" min="1" step="1" data-k="nextNumber" value="${a.nextNumber}"></div>
        </div>
        <div class="hint">New orders get <b>${c(a.orderPrefix)}${a.nextNumber}</b>. You can always type a manual order number.</div>
      </div>

      <div class="card">
        <div class="card-title">Label</div>
        <div class="set-grid">
          <div class="field"><label class="f">Label Size</label>
            <select data-k="labelSize">
              <option value="4x6" ${a.labelSize==="4x6"?"selected":""}>4 × 6 inch (default)</option>
              <option value="a6" ${a.labelSize==="a6"?"selected":""}>A6 (105 × 148 mm)</option>
            </select>
          </div>
        </div>
        <div class="card-sub" style="margin-top:12px">Customer fields shown on the label</div>
        ${e.length===0?'<div class="muted" style="font-size:12px">No custom fields yet.</div>':`<div style="columns:2;gap:24px">${s}</div>`}
        <div class="card-sub" style="margin-top:12px">Label sections</div>
        <div style="columns:2;gap:24px">${o}</div>
      </div>

      <div class="card">
        <div class="card-title">Backup</div>
        <div class="toolbar">
          <button class="btn" data-act="export">Export Orders</button>
          <button class="btn" data-act="import">Import Settings</button>
          <span class="count">Exports include orders, fields, products and settings as JSON.</span>
        </div>
        <input type="file" accept="application/json" data-importfile hidden>
      </div>`,async bind(i){const u=f();i.querySelectorAll("[data-k]").forEach(h=>{const m=h.dataset.k;h.addEventListener("change",async()=>{let w=h.value;m==="nextNumber"&&(w=Math.max(1,Math.floor(Number(w)||1))),await k({...f(),[m]:w}),b("Saved.")})});const v=i.querySelector("[data-logo]");i.querySelector('[data-act="logo"]')?.addEventListener("click",()=>v.click()),v?.addEventListener("change",()=>{const h=v.files?.[0];if(!h)return;if(h.size>400*1024){b("Logo is too large — please use an image under 400 KB.","err"),v.value="";return}const m=new FileReader;m.onload=async()=>{await k({...f(),logo:String(m.result)}),b("Logo saved.","ok"),t.rerender()},m.readAsDataURL(h)}),i.querySelector('[data-act="logorm"]')?.addEventListener("click",async()=>{await k({...f(),logo:""}),t.rerender()}),oe().then(h=>{P.signedIn=h;const m=i.querySelector("[data-gdot]"),y=i.querySelector("[data-gstatus]");m&&(m.className="dot "+(h?"on":"")),y&&!f().sheetId&&(y.textContent=h?"Google account connected":"Not connected")}).catch(()=>{}),i.querySelector('[data-act="use"]')?.addEventListener("click",()=>void Ye(t,i)),i.querySelector('[data-act="gdisconnect"]')?.addEventListener("click",()=>void Je(t));const $=i.querySelector("[data-ws]");$?.addEventListener("change",()=>void Qe(t,$.value)),i.querySelectorAll("[data-map]").forEach(h=>h.addEventListener("change",async()=>{const m=h.dataset.map,y=h.value,w={...f().customMap};y?w[m]=y:delete w[m],await k({...f(),customMap:w}),b("Column mapping saved.","ok")})),i.querySelectorAll("[data-lf]").forEach(h=>h.addEventListener("change",async()=>{const m=h.dataset.lf,y=h.checked,w=g().map(H=>H.id),V=(u.labelFields===null?[...w]:[...u.labelFields]).filter(H=>H!==m);y&&V.push(m),await k({...f(),labelFields:V})})),i.querySelectorAll("[data-ex]").forEach(h=>h.addEventListener("change",async()=>{const m=h.dataset.ex,y=h.checked,w={...f().labelExtras,[m]:y};await k({...f(),labelExtras:w})})),i.querySelector('[data-act="export"]')?.addEventListener("click",()=>{ke(),b("Backup exported.","ok")});const q=i.querySelector("[data-importfile]");i.querySelector('[data-act="import"]')?.addEventListener("click",()=>q.click()),q?.addEventListener("change",()=>{const h=q.files?.[0];h&&Ee(h).then(()=>{b("Settings imported.","ok"),t.rerender()}).catch(m=>b("Import failed: "+(m instanceof Error?m.message:"invalid file"),"err"))})}}}async function Ye(t,a){const e=f(),r=a.querySelector("[data-sheetref]"),d=r.value.trim();if(!e.clientId.trim()){b("Add your Google OAuth Client ID first (see the steps below the field).","err");return}if(!d){r.classList.add("invalid"),b("Paste your Google Sheets link or spreadsheet ID.","err");return}const n=Te(d);try{await k({...f(),clientId:e.clientId.trim()}),await Ce();const s=await Ie(n);if(s.sheets.length===0)throw new Error("This spreadsheet has no worksheets.");const l=s.sheets[0],o=await K(n,l);await k({...f(),sheetId:n,sheetName:l}),W(o),P.signedIn=!0,b(`Connected. ${o.length} columns ready (${ue.length} standard + your fields).`,"ok"),t.rerender()}catch(s){b(G(s),"err")}}async function Qe(t,a){const e=f();if(!(!e.sheetId||!a))try{const r=await K(e.sheetId,a);await k({...f(),sheetName:a}),W(r),b(`Worksheet switched to "${a}".`,"ok"),t.rerender()}catch(r){b(G(r),"err")}}async function Je(t){try{await Ae()}catch{}await k({...f(),sheetId:"",sheetName:""}),W([]),P.signedIn=!1,b("Disconnected from Google Sheets."),t.rerender()}const C=document.getElementById("app"),Ke=[["dashboard","Dashboard",L.dash],["new","New Order",L.plus],["orders","Orders",L.list],["products","Products",L.box],["fields","Custom Fields",L.sliders],["settings","Settings",L.gear]];let O="dashboard",E=null;const _={get route(){return O},get id(){return E},go(t,a=null){O=t,E=a??null;const e=t==="new"?E?`#edit=${E}`:"#new":t==="label"&&E?`#label=${E}`:"";try{history.replaceState(null,"",e||location.pathname)}catch{}z()},rerender(){z()}},Ve={dashboard:_e,new:Me,orders:t=>Ne(t,!1),products:ze,fields:We,settings:He};function Ze(){if(O==="label"){const t=E?de(E):void 0;if(t)return Le(t,()=>_.go("orders"),()=>z());O="orders",E=null}return Ve[O](_)}function z(){const t=Ze();C.innerHTML=`
    <header class="top">
      <div class="brand">${L.tag} Order Label Manager</div>
      <div class="spacer"></div>
      <button class="conn" data-conn title="Google Sheets connection status — click to open Settings"><span class="dot" data-gdot></span><span data-gtxt>Google</span></button>
      <button class="btn small" data-opentab title="Open all orders in a full browser tab">Orders ${L.external}</button>
    </header>
    <nav class="tabs">${Ke.map(([e,r,d])=>`<button data-route="${e}" class="${O===e?"active":""}">${d} ${r}</button>`).join("")}</nav>
    <main class="content"></main>`;const a=C.querySelector("main.content");a.innerHTML=t.html,C.querySelectorAll("[data-route]").forEach(e=>e.addEventListener("click",()=>_.go(e.dataset.route))),C.querySelector("[data-opentab]")?.addEventListener("click",()=>window.open(chrome.runtime.getURL("orders.html"))),C.querySelector("[data-conn]")?.addEventListener("click",()=>_.go("settings")),oe().then(e=>{const r=C.querySelector("[data-gdot]"),d=C.querySelector("[data-gtxt]");r&&(r.className="dot "+(e?"on":"")),d&&(d.textContent=e?"Google connected":"Google")}).catch(()=>{}),t.bind?.(a)}function Xe(){const t=location.hash.replace(/^#/,""),[a,e]=t.split("=");return a==="edit"&&e?{route:"new",id:e}:a==="label"&&e?{route:"label",id:e}:a==="new"?{route:"new",id:null}:{route:"dashboard",id:null}}function et(){return new Promise(t=>{try{chrome.windows.getCurrent(a=>t(a.type==="normal"))}catch{t(!1)}})}async function tt(){await qe();const t=Xe();O=t.route,E=t.id,document.documentElement.classList.toggle("as-page",await et()),z()}tt();
