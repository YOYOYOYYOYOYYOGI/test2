UGC Video Generator — Chrome Extension + Secure Gateway

LOAD THE EXTENSION
1. Extract this ZIP.
2. Open chrome://extensions.
3. Enable Developer mode.
4. Click Load unpacked.
5. Select this UGC-Video-Generator folder. It contains manifest.json at its root.
6. Open the extension and click Open studio.

LOCAL FEATURES
The extension works without provider keys for local storyboard planning, the Instagram
Hook Generator, product/person image uploads, scene editing, captions and browser WebM
rendering. It never fabricates a cartoon and labels provider-dependent features honestly.

AI FEATURES
The same folder includes the secure Node gateway. From this extracted folder run:
  npm run dev
Then copy .env.example to .env and add server-side credentials. Never put provider
secrets into extension JavaScript or chrome.storage. Configure an image provider for a
photoreal creator when no person image is supplied, a multimodal LLM for product reading
and scene plans, ElevenLabs for narration, and a legally available Replicate-compatible
video model for photoreal scene generation and optional audio/lip-sync.
